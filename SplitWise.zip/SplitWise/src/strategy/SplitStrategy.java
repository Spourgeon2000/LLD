package strategy;

import data.Expense;
import data.Split;

import java.util.List;
import java.util.Map;

public interface SplitStrategy {
    List<Split>  split(Expense expense, Map<Integer, Integer> userToShareMap);
}
