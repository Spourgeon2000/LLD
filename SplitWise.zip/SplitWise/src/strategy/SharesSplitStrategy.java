package strategy;

import data.Expense;
import data.Split;
import data.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SharesSplitStrategy implements SplitStrategy{

    public List<Split> split(Expense expense,Map<Integer, Integer> userToShareMap){
        List<Split> splits = new ArrayList<>();
        Integer totalShare = 0;
        for(Integer share: userToShareMap.values()){
            totalShare += share;
        }
        for(User user: expense.getUsers()){
            Split split = new Split();
            split.setAmount((expense.getAmount()*1.0*userToShareMap.get(user.getUserId()))/totalShare);
            split.setUserId(user.getUserId());
            split.setExpenseId(expense.getExpenseId());
            split.setSplitType(expense.getSplitType());
            splits.add(split);
        }
        return splits;
    }
}
