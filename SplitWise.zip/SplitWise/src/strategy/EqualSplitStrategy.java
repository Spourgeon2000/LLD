package strategy;

import data.Expense;
import data.Split;
import data.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EqualSplitStrategy implements  SplitStrategy {
    public List<Split> split(Expense expense, Map<Integer, Integer> userToShareMap){
        List<Split> splits = new ArrayList<>();
        for(User user: expense.getUsers()){
            Split split = new Split();
            split.setAmount(((expense.getAmount()*1.0)/expense.getUsers().size()));
            split.setUserId(user.getUserId());
            split.setExpenseId(expense.getExpenseId());
            split.setSplitType(expense.getSplitType());
            splits.add(split);
        }
        return splits;
    }
}
