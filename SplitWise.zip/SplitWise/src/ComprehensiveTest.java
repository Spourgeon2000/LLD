import data.SplitType;
import data.User;
import service.ExpenseService;
import service.GroupService;
import service.SimplifyDebtsService;
import service.UserGroupService;
import strategy.EqualSplitStrategy;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * Comprehensive test to verify all requirements
 */
public class ComprehensiveTest {
    public static void main(String[] args) {
        System.out.println("=== COMPREHENSIVE CODE TEST ===\n");
        
        // Get service instances
        ExpenseService expenseService = ExpenseService.getInstance();
        SimplifyDebtsService simplifyDebtsService = SimplifyDebtsService.getInstance();
        UserGroupService userGroupService = UserGroupService.getInstance();
        GroupService groupService = GroupService.getInstance();
        
        // Register observers
        expenseService.registerObserver(simplifyDebtsService);
        expenseService.registerObserver(userGroupService);
        
        // Create users
        User alice = new User();
        alice.setUserId(1);
        alice.setName("Alice");
        
        User bob = new User();
        bob.setUserId(2);
        bob.setName("Bob");
        
        User charlie = new User();
        charlie.setUserId(3);
        charlie.setName("Charlie");
        
        List<User> users = Arrays.asList(alice, bob, charlie);
        
        // Test 1: Create group
        System.out.println("TEST 1: Create Group");
        groupService.createGroup("Trip to Paris", users);
        
        // Test 2: Add expenses
        System.out.println("\nTEST 2: Add Expenses");
        expenseService.setSplitStrategy(new EqualSplitStrategy());
        
        System.out.println("\n--- Expense 1: Alice paid $300 for dinner ---");
        expenseService.addExpense(
            1, "Dinner", 300.0, 1, null, 
            SplitType.EQUAL, users, new HashMap<>()
        );
        
        System.out.println("\n--- Expense 2: Bob paid $150 for movie ---");
        expenseService.addExpense(
            1, "Movie", 150.0, 2, null, 
            SplitType.EQUAL, users, new HashMap<>()
        );
        
        System.out.println("\n--- Expense 3: Charlie paid $90 for taxi ---");
        expenseService.addExpense(
            1, "Taxi", 90.0, 3, null, 
            SplitType.EQUAL, users, new HashMap<>()
        );
        
        // Test 3: List expenses for user
        System.out.println("\nTEST 3: List Expenses for Alice");
        expenseService.listAllExpensesForUser(1);
        
        // Test 4: Show user stats in group
        System.out.println("\nTEST 4: Show User Stats in Group");
        userGroupService.showTotalInvestmentForUserInGroup(1, 1);
        userGroupService.showTotalShareForUserInGroup(1, 1);
        
        // Test 5: Simplify debts
        System.out.println("\nTEST 5: Simplify Debts for Group");
        simplifyDebtsService.simplifyDebtsForGroup(1);
        
        System.out.println("\n=== ALL TESTS COMPLETE ===");
    }
}

