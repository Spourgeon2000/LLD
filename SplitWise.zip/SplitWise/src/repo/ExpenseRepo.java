package repo;

import data.Expense;
import data.IdGenerator;
import data.Split;
import data.SplitType;
import data.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExpenseRepo {
    private static ExpenseRepo instance = null;

    private ExpenseRepo() {
    }

    public static ExpenseRepo getInstance() {
        if (instance == null) {
            instance = new ExpenseRepo();
        }
        return instance;
    }

    Map<Integer, Expense> expenseMap = new HashMap<>();
    Map<Integer, List<Expense>> userIdTExpenseMap = new HashMap<>();
    Map<Integer, List<Expense>> groupIdToExpenseMap = new HashMap<>();

    public Expense addExpense(String name, Double amount, Integer groupId, Integer createdByUserId, SplitType splitType, List<User> users, List<Split> splits) {
        Expense expense = new Expense();
        expense.setName(name);
        expense.setAmount(amount);
        expense.setGroupId(groupId);
        expense.setCreatedByUserId(createdByUserId);
        expense.setSplitType(splitType);
        expense.setUsers(users);
        expense.setSplits(splits);
        expense.setExpenseId(IdGenerator.getNextId());
        expenseMap.put(expense.getExpenseId(), expense);

        // Add to user expenses map
        List<Expense> userExpenses = userIdTExpenseMap.getOrDefault(createdByUserId, new ArrayList<>());
        userExpenses.add(expense);
        userIdTExpenseMap.put(createdByUserId, userExpenses);

        // Add to group expenses map
        List<Expense> groupExpenses = groupIdToExpenseMap.getOrDefault(groupId, new ArrayList<>());
        groupExpenses.add(expense);
        groupIdToExpenseMap.put(groupId, groupExpenses);

        return expense;
    }

    public void addSplits(Integer expenseId, List<Split> splits) {
        expenseMap.get(expenseId).setSplits(splits);
    }

    public List<Expense> getExpensesForUser(Integer userId) {
        return userIdTExpenseMap.getOrDefault(userId, new ArrayList<>());
    }

    public List<Expense> getExpensesForGroup(Integer groupId) {
        return groupIdToExpenseMap.getOrDefault(groupId, new ArrayList<>());
    }
}
