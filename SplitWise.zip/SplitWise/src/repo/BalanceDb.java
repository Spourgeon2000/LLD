package repo;

import data.Balance;
import data.IdGenerator;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class BalanceDb {
    private static BalanceDb instance = null;

    private BalanceDb() {
    }

    public static BalanceDb getInstance() {
        if (instance == null) {
            instance = new BalanceDb();
        }
        return instance;
    }

    Map<Integer, Balance> balanceMap = new HashMap<>();

    public Balance addBalance(Double amount, Integer groupId, Integer fromUserId, Integer toUserId) {
        Balance balance = new Balance();
        balance.setBalanceId(IdGenerator.getNextId());
        balance.setFromUserId(fromUserId);
        balance.setToUserId(toUserId);
        balance.setAmount(amount);
        balance.setSettled(false);
        balance.setGroupId(groupId);
        balanceMap.put(balance.getBalanceId(), balance);
        return balance;
    }

    public void settleBalance(Integer balanceId) {
        balanceMap.get(balanceId).setSettled(true);
    }

    public  Double getOverallBalanceBetweenUsers(Integer fromUserId, Integer toUserId) {
        Double amount = 0.0;
        for (Balance balance : balanceMap.values()) {
            if (Objects.equals(balance.getFromUserId(), fromUserId) && Objects.equals(balance.getToUserId(), toUserId)) {
                amount += balance.getAmount();
            } else if (Objects.equals(balance.getFromUserId(), toUserId) && Objects.equals(balance.getToUserId(), fromUserId)) {
                amount -= balance.getAmount();
            }
        }
        return amount;
    }

    /**
     * Find existing balance record for the combination of groupId, fromUserId, toUserId
     * Returns null if not found
     */
    public Balance findBalance(Integer groupId, Integer fromUserId, Integer toUserId) {
        for (Balance balance : balanceMap.values()) {
            if (Objects.equals(balance.getGroupId(), groupId)
                && Objects.equals(balance.getFromUserId(), fromUserId)
                && Objects.equals(balance.getToUserId(), toUserId)
                && !balance.getSettled()) {  // Only unsettled balances
                return balance;
            }
        }
        return null;
    }

    /**
     * Update or create balance record
     * If combination of (groupId, fromUserId, toUserId) exists, update the amount
     * Otherwise, create new balance record
     */
    public Balance updateOrCreateBalance(Double amount, Integer groupId, Integer fromUserId, Integer toUserId) {
        // Try to find existing balance
        Balance existingBalance = findBalance(groupId, fromUserId, toUserId);

        if (existingBalance != null) {
            // Update existing balance
            existingBalance.setAmount(existingBalance.getAmount() + amount);
            return existingBalance;
        } else {
            // Create new balance
            return addBalance(amount, groupId, fromUserId, toUserId);
        }
    }
}
