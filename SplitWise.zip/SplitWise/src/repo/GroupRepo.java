package repo;

import data.Group;
import data.IdGenerator;
import data.User;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GroupRepo {
    private static GroupRepo instance = null;
    private GroupRepo() {
    }

    public static GroupRepo getInstance() {
        if(instance == null) {
            instance = new GroupRepo();
        }
        return instance;
    }

    Map<Integer, Group> groups = new HashMap<>();

    public Group addGroup(String name, List<User> users) {
        Group group = new Group();
        group.setName(name);
        group.setUsers(users);
        group.setGroupId(IdGenerator.getNextId());
        groups.put(group.getGroupId(), group);
        return group;
    }

    public Group getGroup(Integer groupId) {
        return groups.get(groupId);
    }

    public Map<Integer, Group> getGroups() {
        return groups;
    }

    public void setGroups(Map<Integer, Group> groups) {
        this.groups = groups;
    }



}
