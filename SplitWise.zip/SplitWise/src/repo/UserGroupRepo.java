package repo;

import data.IdGenerator;
import data.UserGroupMapping;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class UserGroupRepo {
    private static UserGroupRepo instance = null;

    private UserGroupRepo() {
    }

    public static UserGroupRepo getInstance() {
        if (instance == null) {
            instance = new UserGroupRepo();
        }
        return instance;
    }

    Map<Integer, UserGroupMapping> userGroupMappingMap = new HashMap<>();

    public Map<Integer, List<Integer>> getUserIdToGroupIds() {
        return userIdToGroupIds;
    }

    public void setUserIdToGroupIds(Map<Integer, List<Integer>> userIdToGroupIds) {
        this.userIdToGroupIds = userIdToGroupIds;
    }

    public Map<Integer, UserGroupMapping> getUserGroupMappingMap() {
        return userGroupMappingMap;
    }

    public void setUserGroupMappingMap(Map<Integer, UserGroupMapping> userGroupMappingMap) {
        this.userGroupMappingMap = userGroupMappingMap;
    }

    public static void setInstance(UserGroupRepo instance) {
        UserGroupRepo.instance = instance;
    }

    Map<Integer, List<Integer>> userIdToGroupIds = new HashMap<>();

    public UserGroupMapping addUserGroupMapping(Integer userId, Integer groupId) {
        UserGroupMapping userGroupMapping = new UserGroupMapping();
        userGroupMapping.setUserId(userId);
        userGroupMapping.setGroupId(groupId);
        userGroupMapping.setUserGroupId(IdGenerator.getNextId());
        userGroupMapping.setAmountInvested(0.0);
        userGroupMapping.setTotalShare(0.0);
        List<Integer> groupIds = userIdToGroupIds.getOrDefault(userId, new ArrayList<>());
        groupIds.add(groupId);
        userIdToGroupIds.put(userId, groupIds);
        userGroupMappingMap.put(userGroupMapping.getUserGroupId(), userGroupMapping);
        return userGroupMapping;
    }

    /**
     * Find existing UserGroupMapping for (userId, groupId) combination
     * Returns null if not found
     */
    public UserGroupMapping findUserGroupMapping(Integer userId, Integer groupId) {
        for (UserGroupMapping mapping : userGroupMappingMap.values()) {
            if (Objects.equals(mapping.getUserId(), userId)
                    && Objects.equals(mapping.getGroupId(), groupId)) {
                return mapping;
            }
        }
        return null;
    }

    /**
     * Update or create UserGroupMapping
     * If (userId, groupId) exists, return existing
     * Otherwise, create new mapping
     */
    public UserGroupMapping updateOrCreateUserGroupMapping(Integer userId, Integer groupId, Double amountInvested, Double totalShare) {
        UserGroupMapping existing = findUserGroupMapping(userId, groupId);

        if (existing != null) {
            // Already exists, return it
            if (amountInvested!=null) {
                existing.setAmountInvested(existing.getAmountInvested() + amountInvested);
            }
            if (totalShare!=null) {
                existing.setTotalShare(existing.getTotalShare() + totalShare);
            }
            return existing;
        } else {
            // Create new mapping
            UserGroupMapping userGroupMapping = addUserGroupMapping(userId, groupId);
            if (amountInvested!=null) {
                userGroupMapping.setAmountInvested(amountInvested);
            }
            if (totalShare!=null) {
                userGroupMapping.setTotalShare(totalShare);
            }
            return userGroupMapping;
        }
    }
}
