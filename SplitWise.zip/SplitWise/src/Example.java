import data.SplitType;
import data.User;
import service.ExpenseService;
import service.SimplifyDebtsService;
import service.UserGroupService;
import strategy.EqualSplitStrategy;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Example demonstrating Observer Pattern usage
 */
public class Example {
    public static void main(String[] args) {
        // Step 1: Get service instances
        ExpenseService expenseService = ExpenseService.getInstance();
        SimplifyDebtsService simplifyDebtsService = SimplifyDebtsService.getInstance();
        UserGroupService userGroupService = UserGroupService.getInstance();
        
        // Step 2: Register SimplifyDebtsService as an observer
        expenseService.registerObserver(simplifyDebtsService);
        expenseService.registerObserver(userGroupService);

        
        System.out.println("=== Observer Pattern Demo ===\n");
        
        // Step 3: Create users
        User user1 = new User();
        user1.setUserId(1);
        user1.setName("Alice");
        
        User user2 = new User();
        user2.setUserId(2);
        user2.setName("Bob");
        
        User user3 = new User();
        user3.setUserId(3);
        user3.setName("Charlie");
        
        List<User> users = Arrays.asList(user1, user2, user3);
        
        // Step 4: Set split strategy
        expenseService.setSplitStrategy(new EqualSplitStrategy());
        
        // Step 5: Add expense - Observer will automatically update balances!
        System.out.println("Adding expense 1...");
        expenseService.addExpense(
            1,                          // groupId
            "Dinner",                   // name
            300.0,                      // amount
            1,                          // createdByUserId (Alice paid)
            null,                       // participantIds
            SplitType.EQUAL,            // splitType
            users,                      // users
            new HashMap<>()             // splitData
        );
        
        System.out.println("\nAdding expense 2...");
        expenseService.addExpense(
            1,                          // groupId
            "Movie",                    // name
            150.0,                      // amount
            2,                          // createdByUserId (Bob paid)
            null,                       // participantIds
            SplitType.EQUAL,            // splitType
            users,                      // users
            new HashMap<>()             // splitData
        );
        
        System.out.println("\n=== Simplifying Debts ===");
        simplifyDebtsService.simplifyDebtsForGroup(1);
        
        System.out.println("\n=== Demo Complete ===");
    }
}

