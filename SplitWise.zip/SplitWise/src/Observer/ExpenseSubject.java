package observer;

import data.Expense;

/**
 * Subject interface for expense events
 * Classes that generate expense events should implement this
 */
public interface ExpenseSubject {
    /**
     * Register an observer
     */
    void registerObserver(observer.ExpenseObserver observer);
    
    /**
     * Unregister an observer
     */
    void unregisterObserver(observer.ExpenseObserver observer);
    
    /**
     * Notify all observers
     */
    void notifyObservers(Expense expense);
}

