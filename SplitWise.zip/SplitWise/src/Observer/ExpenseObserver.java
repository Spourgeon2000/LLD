package observer;

import data.Expense;

/**
 * Observer interface for expense events
 */
public interface ExpenseObserver {
    /**
     * Called when a new expense is added
     */
    void onExpenseAdded(Expense expense);

}

