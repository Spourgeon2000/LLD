package service;

import data.Group;
import data.User;
import repo.GroupRepo;
import repo.UserGroupRepo;

import java.util.List;

public class GroupService {
    private static GroupService instance = null;

    private GroupService() {
    }

    public static GroupService getInstance() {
        if (instance == null) {
            instance = new GroupService();
        }
        return instance;
    }

    private final UserGroupRepo userGroupRepo = UserGroupRepo.getInstance();
    private final GroupRepo groupRepo = GroupRepo.getInstance();

    public void createGroup(String name, List<User> users) {
        Group group = groupRepo.addGroup(name, users);
        System.out.println("Group created with id " + group.getGroupId());
    }

    public void listAllGroupsForUser(Integer userId) {
        System.out.println("Groups for user " + userId);
        userGroupRepo.getUserIdToGroupIds().get(userId).forEach(groupId -> {
            System.out.println(groupRepo.getGroups().get(groupId).getName());
        });
    }

}
