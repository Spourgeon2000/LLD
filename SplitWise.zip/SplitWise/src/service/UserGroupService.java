package service;
import data.Expense;
import data.Split;
import data.User;
import data.UserGroupMapping;
import observer.ExpenseObserver;
import repo.GroupRepo;
import repo.UserGroupRepo;

import java.util.List;

public class UserGroupService  implements ExpenseObserver {
    private static UserGroupService instance = null;
    private UserGroupService() {
    }
    public static UserGroupService getInstance() {
        if (instance == null) {
            instance = new UserGroupService();
        }
        return instance;
    }
    
    UserGroupRepo userGroupRepo = UserGroupRepo.getInstance();
    GroupRepo groupRepo = GroupRepo.getInstance();

    public void showTotalShareForUserInGroup(Integer userId, Integer groupId) {
        List<User> users = groupRepo.getGroup(groupId).getUsers();
        for(User user: users){
            UserGroupMapping userGroupMapping = userGroupRepo.findUserGroupMapping(userId, groupId);
            if (userGroupMapping == null) {
                System.out.println("User " + user.getName() + " is not part of group " + groupId);
                return;
            }
            System.out.println("Total share for user " + user.getName() + " in group " + groupId + " is " + userGroupMapping.getTotalShare());
        }
    }

    public void showTotalInvestmentForUserInGroup(Integer userId, Integer groupId) {
        List<User> users = groupRepo.getGroup(groupId).getUsers();
        for(User user: users){
            UserGroupMapping userGroupMapping = userGroupRepo.findUserGroupMapping(userId, groupId);
            if (userGroupMapping == null) {
                System.out.println("User " + user.getName() + " is not part of group " + groupId);
                return;
            }
            System.out.println("Total share for user " + user.getName() + " in group " + groupId + " is " + userGroupMapping.getAmountInvested());
        }
    }

    @Override
    public void onExpenseAdded(Expense expense) {
        System.out.println("[Observer] Expense added - updating user-group mapping for group " + expense.getGroupId());
        userGroupRepo.updateOrCreateUserGroupMapping(expense.getCreatedByUserId(), expense.getGroupId(), expense.getAmount(), null);
        for(Split split: expense.getSplits()){
            userGroupRepo.updateOrCreateUserGroupMapping(split.getUserId(), expense.getGroupId(), null, split.getAmount());
        }
    }
}
