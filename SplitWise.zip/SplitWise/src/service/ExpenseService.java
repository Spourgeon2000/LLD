package service;

import data.Expense;
import data.Split;
import data.SplitType;
import data.User;
import observer.ExpenseObserver;
import observer.ExpenseSubject;
import repo.ExpenseRepo;
import strategy.EqualSplitStrategy;
import strategy.SplitStrategy;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * ExpenseService implements Subject Pattern
 * Notifies observers when expenses are added/updated/deleted
 */
public class ExpenseService implements ExpenseSubject {
    private static ExpenseService instance = null;

    private SplitStrategy splitStrategy;
    private List<ExpenseObserver> observers;  // Fixed typo

    private ExpenseService() {
        this.splitStrategy = new EqualSplitStrategy();
        this.observers = new ArrayList<>();
    }

    public static ExpenseService getInstance() {
        if (instance == null) {
            instance = new ExpenseService();
        }
        return instance;
    }

    public void setSplitStrategy(SplitStrategy splitStrategy) {
        this.splitStrategy = splitStrategy;
    }

    private final ExpenseRepo expenseRepo = ExpenseRepo.getInstance();

    public void addExpense(Integer groupId, String name, double amount, Integer createdByUserId,
                           List<String> participantIds, SplitType splitType, List<User> users,
                           Map<Integer, Integer> splitData) {
        Expense expense = expenseRepo.addExpense(name, amount, groupId, createdByUserId, splitType, users, new ArrayList<>());
        List<Split> splits = splitStrategy.split(expense, splitData);
        expenseRepo.addSplits(expense.getExpenseId(), splits);
        System.out.println("Expense added with id " + expense.getExpenseId());

        // Notify all observers
        notifyObservers(expense);
    }

    public void listAllExpensesForUser(Integer userId) {
        System.out.println("Expenses for user " + userId);
        expenseRepo.getExpensesForUser(userId).forEach(expense -> {
            System.out.println(expense.getName());
        });
        System.out.println("End of expenses");
    }

    @Override
    public void registerObserver(ExpenseObserver observer) {
        if (!observers.contains(observer)) {
            observers.add(observer);
            System.out.println("[Subject] Observer registered: " + observer.getClass().getSimpleName());
        }
    }

    @Override
    public void unregisterObserver(ExpenseObserver observer) {
        observers.remove(observer);
        System.out.println("[Subject] Observer unregistered: " + observer.getClass().getSimpleName());
    }

    @Override
    public void notifyObservers(Expense expense) {
        for (ExpenseObserver observer : observers) {
            observer.onExpenseAdded(expense);
        }
    }

}
