package service;

import data.Expense;
import data.Split;
import observer.ExpenseObserver;
import repo.BalanceDb;
import repo.ExpenseRepo;

import java.util.*;
import java.util.stream.Collectors;


public class SimplifyDebtsService implements ExpenseObserver {
    private static SimplifyDebtsService instance = null;
    private SimplifyDebtsService() {
    }
    public static SimplifyDebtsService getInstance() {
        if (instance == null) {
            instance = new SimplifyDebtsService();
        }
        return instance;
    }
    private final BalanceDb balanceDb = BalanceDb.getInstance();
    private final ExpenseRepo expenseRepo = ExpenseRepo.getInstance();
    
    public void simplifyDebtsForGroup(Integer groupId) {
        List<Expense> expenses = expenseRepo.getExpensesForGroup(groupId);

        Map<Integer, Double> userBalances = new HashMap<>();

        for (Expense expense : expenses) {
            Integer paidByUserId = expense.getCreatedByUserId();
            Double totalAmount = expense.getAmount();

            userBalances.put(paidByUserId,
                userBalances.getOrDefault(paidByUserId, 0.0) + totalAmount);

            List<Split> splits = expense.getSplits();
            for (Split split : splits) {
                Integer userId = split.getUserId();
                Double splitAmount = split.getAmount();

                userBalances.put(userId,
                    userBalances.getOrDefault(userId, 0.0) - splitAmount);
            }
        }

        List<UserBalance> balanceList = userBalances.entrySet().stream()
            .map(entry -> new UserBalance(entry.getKey(), entry.getValue()))
            .sorted(Comparator.comparingDouble(UserBalance::getBalance))
            .collect(Collectors.toList());

        int left = 0;
        int right = balanceList.size() - 1;

        System.out.println("\n=== Simplified Debts for Group " + groupId + " ===");

        while (left < right) {
            UserBalance debtor = balanceList.get(left);
            UserBalance creditor = balanceList.get(right);

            if (Math.abs(debtor.getBalance()) < 0.01) {
                left++;
                continue;
            }
            if (Math.abs(creditor.getBalance()) < 0.01) {
                right--;
                continue;
            }

            double settlementAmount = Math.min(
                Math.abs(debtor.getBalance()),
                creditor.getBalance()
            );

            balanceDb.updateOrCreateBalance(settlementAmount, groupId, debtor.getUserId(), creditor.getUserId());

            System.out.println("User " + debtor.getUserId() + " pays User " +
                creditor.getUserId() + ": $" + String.format("%.2f", settlementAmount));

            debtor.addBalance(settlementAmount);
            creditor.addBalance(-settlementAmount);

            if (Math.abs(debtor.getBalance()) < 0.01) {
                left++;
            }
            if (Math.abs(creditor.getBalance()) < 0.01) {
                right--;
            }
        }

        System.out.println("=== Settlement Complete ===\n");
    }

    private static class UserBalance {
        private final Integer userId;
        private Double balance;

        public UserBalance(Integer userId, Double balance) {
            this.userId = userId;
            this.balance = balance;
        }

        public Integer getUserId() {
            return userId;
        }

        public Double getBalance() {
            return balance;
        }

        public void addBalance(Double amount) {
            this.balance += amount;
        }
    }

    @Override
    public void onExpenseAdded(Expense expense) {
        System.out.println("[Observer] Expense added - updating balances for group " + expense.getGroupId());
        simplifyDebtsForGroup(expense.getGroupId());
    }
}
