package data;

public enum SplitType {
    EQUAL,
    PERCENTAGE,
    SHARES
}
