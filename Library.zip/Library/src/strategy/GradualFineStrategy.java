package strategy;

public class GradualFineStrategy implements FineStrategy {
    public Long calculateFine(Long borrowedTime, Long dueTime, Long returnedTime){
        if(returnedTime <= dueTime){
            return 0L;
        }
        if(returnedTime <= dueTime + 7){
            return (returnedTime - dueTime) * 5;
        }
        if(returnedTime <= dueTime + 14){
            return (returnedTime - dueTime) * 10;
        }
        return (returnedTime - dueTime) * 20;
    }
}
