package strategy;

public interface FineStrategy {
    Long calculateFine(Long borrowedTime, Long dueTime, Long returnedTime);
}
