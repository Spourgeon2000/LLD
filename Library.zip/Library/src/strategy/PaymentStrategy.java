package strategy;

public interface PaymentStrategy {

    String pay(Long amount,String paidBy);
}
