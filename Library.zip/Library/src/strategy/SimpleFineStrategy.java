package strategy;

public class SimpleFineStrategy implements FineStrategy {

    public Long calculateFine(Long borrowedTime, Long dueTime, Long returnedTime) {
         return (returnedTime-dueTime)*10;
    }
}
