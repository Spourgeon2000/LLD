package strategy;

import data.Payment;
import data.PaymentStatus;
import data.PaymentType;

import java.util.UUID;

public class CashPaymentStrategy implements PaymentStrategy {
    public String pay(Long amount, String paidBy) {
        Payment payment = new Payment(UUID.randomUUID().toString(), PaymentType.CASH, PaymentStatus.PAID, paidBy);
        return payment.getPaymentId();
    }
}
