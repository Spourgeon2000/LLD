package strategy;

import data.Payment;
import data.PaymentStatus;
import data.PaymentType;

import java.util.UUID;

public class UPIPaymentStrategy implements PaymentStrategy {
    public String pay(Long amount, String paidBy) {
        //try catch we do
        Payment payment = new Payment(UUID.randomUUID().toString(), PaymentType.UPI, PaymentStatus.PAID, paidBy);
        return payment.getPaymentId();
    }
}
