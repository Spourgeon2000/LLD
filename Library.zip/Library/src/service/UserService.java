package service;

import data.ROLE;
import data.User;
import repo.UserRepo;

import java.util.Arrays;
import java.util.List;

public class UserService {

    private static UserService instance = null;

    private UserService() {
    }

    public static UserService getInstance() {
        if (instance == null) {
            instance = new UserService();
        }
        return instance;
    }

    private UserRepo userRepo = UserRepo.getInstance();

    /**
     * Register a new member
     */
    public User registerMember(String name, String email, String phoneNumber) {
        User user = userRepo.addUser(name, Arrays.asList(ROLE.MEMBER), email, phoneNumber);
        if (user != null) {
            System.out.println("Member registered successfully: " + name + " (" + email + ")");
        }
        return user;
    }

    /**
     * Register a new admin
     */
    public User registerAdmin(String name, String email, String phoneNumber) {
        User user = userRepo.addUser(name, Arrays.asList(ROLE.ADMIN), email, phoneNumber);
        if (user != null) {
            System.out.println("Admin registered successfully: " + name + " (" + email + ")");
        }
        return user;
    }

    /**
     * Register a user with multiple roles
     */
    public User registerUser(String name, List<ROLE> roles, String email, String phoneNumber) {
        User user = userRepo.addUser(name, roles, email, phoneNumber);
        if (user != null) {
            System.out.println("User registered successfully: " + name + " with roles: " + roles);
        }
        return user;
    }

    /**
     * Get user by ID
     */
    public User getUserById(String userId) {
        User user = userRepo.getUserById(userId);
        if (user == null) {
            System.out.println("User not found with ID: " + userId);
        }
        return user;
    }

    /**
     * Get user by email
     */
    public User getUserByEmail(String email) {
        User user = userRepo.getUserByEmail(email);
        if (user == null) {
            System.out.println("User not found with email: " + email);
        }
        return user;
    }

    /**
     * Update user profile
     */
    public User updateUserProfile(String userId, String name, String email, String phoneNumber) {
        User user = userRepo.updateUser(userId, name, email, phoneNumber);
        System.out.println("User profile updated successfully");
        return user;
    }

    /**
     * Promote member to admin (add ADMIN role)
     */
    public User promoteToAdmin(String userId) {
        User user = userRepo.getUserById(userId);
        if (user == null) {
            System.out.println("User not found");
            return null;
        }

        List<ROLE> roles = user.getRoles();
        if (!roles.contains(ROLE.ADMIN)) {
            roles.add(ROLE.ADMIN);
            userRepo.updateUserRoles(userId, roles);
            System.out.println("User promoted to admin: " + user.getName());
        } else {
            System.out.println("User is already an admin");
        }
        return user;
    }

    /**
     * Get all members
     */
    public List<User> getAllMembers() {
        return userRepo.getUsersByRole(ROLE.MEMBER);
    }

    /**
     * Get all admins
     */
    public List<User> getAllAdmins() {
        return userRepo.getUsersByRole(ROLE.ADMIN);
    }

    /**
     * Validate if user has admin privileges
     */
    public boolean isAdmin(String userId) {
        User user = userRepo.getUserById(userId);
        return user != null && user.isAdmin();
    }

    /**
     * Validate if user has member privileges
     */
    public boolean isMember(String userId) {
        User user = userRepo.getUserById(userId);
        return user != null && user.isMember();
    }
}

