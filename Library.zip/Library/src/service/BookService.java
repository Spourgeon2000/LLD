package service;

import data.Book;
import data.BookCopy;
import data.BookLocation;
import data.User;
import repo.BookCopyRepo;
import repo.BookRepo;
import repo.UserRepo;

import java.util.ArrayList;
import java.util.List;

public class BookService {

    //admin can manage books in the library

    public static BookService instance = null;

    private BookService() {
    }

    public static BookService getInstance() {
        if (instance == null) {
            instance = new BookService();
        }
        return instance;
    }

    BookRepo bookRepo = BookRepo.getInstance();
    BookCopyRepo bookCopyRepo = BookCopyRepo.getInstance();
    UserRepo userRepo = UserRepo.getInstance();

    /**
     * Validate if user is admin (for admin-only operations)
     */
    private boolean validateAdmin(String userId) {
        if (userId == null) {
            System.out.println("User ID is required");
            return false;
        }
        User user = userRepo.getUserById(userId);
        if (user == null) {
            System.out.println("User not found");
            return false;
        }
        if (!user.isAdmin()) {
            System.out.println("Access denied: Only admins can perform this operation");
            return false;
        }
        return true;
    }

    /**
     * Add a new book (Admin only)
     */
    public Book addBook(String adminId, String title, String author){
        if (!validateAdmin(adminId)) {
            return null;
        }
        Book book = bookRepo.addBookCopy(title, author);
        System.out.println("Book added successfully by admin: " + adminId);
        return book;
    }

    /**
     * Add a book copy (Admin only)
     */
    public BookCopy addBookCopy(String adminId, String bookId, String condition, BookLocation shelfLocation) {
        if (!validateAdmin(adminId)) {
            return null;
        }
        BookCopy bookCopy = bookCopyRepo.addBookCopy(bookId, condition, shelfLocation);
        System.out.println("Book Copy added successfully by admin: " + adminId);
        return bookCopy;
    }

    public Book getBookByTitle(String title){
        Book book = bookRepo.getBookByTitle(title);
        if (book == null) {
            System.out.println("Book not found with title: " + title);
            return null;
        }
        System.out.println(book.getBookId() + " " + book.getTitle() + " " + book.getAuthor());
        return book;
    }

    public List<BookCopy> getBookCopiesByBookId(String bookId){
        List<String> bookCopyIds = bookCopyRepo.getBookIdToBookCopies().get(bookId);
        if (bookCopyIds == null || bookCopyIds.isEmpty()) {
            System.out.println("No book copies found for bookId: " + bookId);
            return new ArrayList<>();
        }

        List<BookCopy> bookCopies = new ArrayList<>();
        for(String bookCopyId : bookCopyIds){
            System.out.println(bookCopyId);
            BookCopy bookCopy = bookCopyRepo.getBookCopies().get(bookCopyId);
            if (bookCopy != null) {
                System.out.println(bookCopy.getBookId() + " " + bookCopy.getCondition() + " " + bookCopy.getShelfLocation());
                bookCopies.add(bookCopy);
            }
        }
        return bookCopies;
    }

    /**
     * Search books by title or author (partial match)
     */
    public List<Book> searchBooks(String query) {
        if (query == null || query.trim().isEmpty()) {
            System.out.println("Search query cannot be empty");
            return new ArrayList<>();
        }

        List<Book> results = new ArrayList<>();
        String lowerQuery = query.toLowerCase();

        for (Book book : bookRepo.getBookCopies().values()) {
            if (book.getTitle().toLowerCase().contains(lowerQuery) ||
                book.getAuthor().toLowerCase().contains(lowerQuery)) {
                results.add(book);
            }
        }

        if (results.isEmpty()) {
            System.out.println("No books found matching: " + query);
        } else {
            System.out.println("Found " + results.size() + " book(s) matching: " + query);
            for (Book book : results) {
                System.out.println("  - " + book.getTitle() + " by " + book.getAuthor());
            }
        }

        return results;
    }

}
