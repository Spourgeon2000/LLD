package service;

import data.BookAvailability;
import data.BookCopy;
import data.Borrow;
import data.BorrowStatus;
import data.Payment;
import data.PaymentStatus;
import data.ROLE;
import data.User;
import repo.BookAvailabilityRepo;
import repo.BookCopyRepo;
import repo.BorrowRepo;
import repo.PaymentRepo;
import repo.UserRepo;
import strategy.FineStrategy;
import strategy.PaymentStrategy;

import java.util.List;
import java.util.Map;

public class BorrowService {


    public static BorrowService instance = null;

    public static BookAvailabilityRepo bookAvailabilityRepo = BookAvailabilityRepo.getInstance();
    public static BorrowRepo borrowRepo = BorrowRepo.getInstance();
    public static BookCopyRepo bookCopyRepo = BookCopyRepo.getInstance();
    public static PaymentRepo paymentRepo = PaymentRepo.getInstance();
    public static UserRepo userRepo = UserRepo.getInstance();
    public PaymentStrategy paymentStrategy;

    public BorrowService(PaymentStrategy paymentStrategy, FineStrategy fineStrategy) {
        this.paymentStrategy = paymentStrategy;
        this.fineStrategy = fineStrategy;
    }

    public FineStrategy fineStrategy;

    private BorrowService() {
    }

    public static BorrowService getInstance() {
        if (instance == null) {
            instance = new BorrowService();
        }
        return instance;
    }

    public void borrowBook(Long from, Long to, String bookCopyId, String borrowedBy) throws Exception {
        User user = userRepo.getUserById(borrowedBy);
        if (!user.getRoles().contains(ROLE.MEMBER)) {
            throw new Exception("Only members can borrow");
        }
        if (!isEligibleToBorrow(borrowedBy)) {
            System.out.println("Not eligible to borrow");
            return;
        }


        BookAvailability bookAvailability = bookAvailabilityRepo.getBookAvailabilityForTimeRange(from, to, bookCopyId);
        if (bookAvailability == null) {
            System.out.println("Book is not available");
            return;
        }
        Long oldFrom = bookAvailability.getAvailableFrom();
        Long oldTo = from - 1;

        Long newFrom = to + 1;
        Long newTo = bookAvailability.getAvailableTo();

        bookAvailabilityRepo.deleteBookAvailability(bookAvailability.getBookAvailabilityId());
        bookAvailabilityRepo.addBookAvailability(bookCopyId, bookAvailability.getBookId(), oldFrom, oldTo);
        bookAvailabilityRepo.addBookAvailability(bookCopyId, bookAvailability.getBookId(), newFrom, newTo);
        System.out.println("Book borrowed successfully");
        borrowRepo.addBorrow(borrowedBy, bookCopyId, from, to, data.BorrowStatus.ACTIVE, "good");
    }

    public Long returnBookAndGetFine(String borrowId, Long returnedTime, String conditionAtReturn) {
        Borrow borrow = borrowRepo.returnBook(borrowId, returnedTime, conditionAtReturn);

        Long from = borrow.getBorrowedTime();
        Long to = borrow.getDueTime();
        String bookCopyId = borrow.getBookCopyId();

        BookCopy bookCopy = bookCopyRepo.getBookCopy(bookCopyId);
        String bookId = bookCopy.getBookId();

        bookAvailabilityRepo.addBookAvailabilityWithMerge(bookCopyId, bookId, from, to);

        System.out.println("Book returned successfully");

        Long fine = fineStrategy.calculateFine(from, to, returnedTime);

        // If there's a fine, create a PENDING payment record
        if (fine > 0) {
            paymentRepo.addPayment(data.PaymentType.CASH, borrow.getBorrowedBy(), PaymentStatus.PENDING, fine);
            System.out.println("Fine of " + fine + " has been added to user's account. Status: PENDING");
        }

        return fine;
    }

    public void payFine(String userId, Long fine) {
        paymentStrategy.pay(fine, userId);

        Map<String, Payment> allPayments = paymentRepo.paymentMap;
        for (Payment payment : allPayments.values()) {
            if (payment.getPaidBy().equals(userId) &&
                    payment.getPaymentStatus() == PaymentStatus.PENDING &&
                    payment.getAmount().equals(fine)) {
                paymentRepo.updatePaymentStatus(payment.getPaymentId(), PaymentStatus.PAID);
                System.out.println("Fine payment of " + fine + " marked as COMPLETED for user: " + userId);
                break;
            }
        }
    }

    public boolean isEligibleToBorrow(String userId) {
        if (hasUnpaidFines(userId)) {
            System.out.println("User has unpaid fines. Cannot borrow books.");
            return false;
        }

        List<String> borrowIds = borrowRepo.getBorrowIdsByUser(userId);
        int activeBorrowCount = 0;
        Long currentTime = System.currentTimeMillis();

        for (String borrowId : borrowIds) {
            Borrow borrow = borrowRepo.getBorrowIdsByBorrowId(borrowId);

            if (borrow.getBorrowStatus() == BorrowStatus.ACTIVE ||
                    borrow.getBorrowStatus() == BorrowStatus.RESERVED) {

                if (borrow.getDueTime() < currentTime) {
                    System.out.println("User has overdue books. Cannot borrow until returned.");
                    return false;
                }

                activeBorrowCount++;
            }

            if (borrow.getBorrowStatus() == BorrowStatus.OVERDUE) {
                System.out.println("User has overdue books. Cannot borrow until returned.");
                return false;
            }
        }

        if (activeBorrowCount >= 5) {
            System.out.println("User has reached maximum borrowing limit (5 books). Cannot borrow more.");
            return false;
        }

        return true;
    }

    /**
     * Checks if user has any unpaid fines
     */
    private boolean hasUnpaidFines(String userId) {
        Map<String, Payment> allPayments = paymentRepo.paymentMap;

        for (Payment payment : allPayments.values()) {
            if (payment.getPaidBy().equals(userId) &&
                    payment.getPaymentStatus() == PaymentStatus.PENDING) {
                return true;
            }
        }

        return false;
    }
}
