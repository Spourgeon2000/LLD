import data.Book;
import data.BookLocation;
import data.User;
import repo.BookAvailabilityRepo;
import service.BookService;
import service.BorrowService;
import service.UserService;

public class Main {
    public static void main(String[] args) throws Exception{

        System.out.println("========== Library Management System Test Cases ==========\n");

        // Initialize services
        UserService userService = UserService.getInstance();
        BookService bookService = BookService.getInstance();
        BorrowService borrowService = BorrowService.getInstance();
        BookAvailabilityRepo bookAvailabilityRepo = BookAvailabilityRepo.getInstance();

        // Test Case 0: Create Admin and Members
        System.out.println("TEST 0: Create Admin and Members");
        System.out.println("------------------------------------------");
        User admin = userService.registerAdmin("John Admin", "admin@library.com", "1234567890");
        User member1 = userService.registerMember("Alice Member", "alice@library.com", "1111111111");
        User member2 = userService.registerMember("Bob Member", "bob@library.com", "2222222222");
        System.out.println();

        // Test Case 1: Admin adds books to the library
        System.out.println("TEST 1: Admin adds books to the library");
        System.out.println("------------------------------------------");
        Book book1 = bookService.addBook(admin.getUserId(), "Harry Potter", "J.K. Rowling");
        Book book2 = bookService.addBook(admin.getUserId(), "The Hobbit", "J.R.R. Tolkien");
        Book book3 = bookService.addBook(admin.getUserId(), "1984", "George Orwell");
        System.out.println();

        // Test Case 2: Admin adds multiple copies for books
        System.out.println("TEST 2: Admin adds book copies");
        System.out.println("------------------------------------------");
        BookLocation location1 = new BookLocation();
        location1.setRow("A");
        location1.setColumn("1");
        location1.setShelf("Top");

        BookLocation location2 = new BookLocation();
        location2.setRow("A");
        location2.setColumn("2");
        location2.setShelf("Middle");

        bookService.addBookCopy(admin.getUserId(), book1.getBookId(), "New", location1);
        bookService.addBookCopy(admin.getUserId(), book1.getBookId(), "Good", location2);
        bookService.addBookCopy(admin.getUserId(), book2.getBookId(), "New", location1);
        System.out.println();

        // Test Case 3: Search books by title
        System.out.println("TEST 3: Member searches for a book");
        System.out.println("------------------------------------------");
        Book foundBook = bookService.getBookByTitle("Harry Potter");
        bookService.searchBooks("Harry");
        bookService.searchBooks("Tolkien");
        System.out.println();

        // Test Case 4: View all copies of a book
        System.out.println("TEST 4: View all copies of Harry Potter");
        System.out.println("------------------------------------------");
        bookService.getBookCopiesByBookId(book1.getBookId());
        System.out.println();

        // Test Case 5: Set availability for book copies (time-slot based)
        System.out.println("TEST 5: Set time-slot availability for book copies");
        System.out.println("------------------------------------------");
        String bookCopyId1 = "copy-001"; // Simulating a book copy ID
        Long currentTime = System.currentTimeMillis();
        Long oneHour = 3600000L;

        // Book available from now to 10 hours later
        bookAvailabilityRepo.addBookAvailability(bookCopyId1, book1.getBookId(),
                currentTime, currentTime + (10 * oneHour));
        System.out.println("Book copy available from " + currentTime + " to " + (currentTime + 10 * oneHour));
        System.out.println();

        // Test Case 6: Member borrows a book (time-slot: 2-4 hours from now)
        System.out.println("TEST 6: Member borrows a book for time slot 2-4 hours");
        System.out.println("------------------------------------------");
        Long borrowFrom = currentTime + (2 * oneHour);
        Long borrowTo = currentTime + (4 * oneHour);

        borrowService.borrowBook(borrowFrom, borrowTo, bookCopyId1, member1.getUserId());
        System.out.println("Borrowed from: " + borrowFrom + " to: " + borrowTo);
        System.out.println();

        // Test Case 7: Check availability after borrowing
        System.out.println("TEST 7: Check availability after borrowing");
        System.out.println("------------------------------------------");
        System.out.println("Available slots should be:");
        System.out.println("Slot 1: " + currentTime + " to " + (currentTime + 2 * oneHour - 1));
        System.out.println("Slot 2: " + (currentTime + 4 * oneHour + 1) + " to " + (currentTime + 10 * oneHour));
        System.out.println();

        // Test Case 8: Try to borrow during unavailable time (should fail)
        System.out.println("TEST 8: Try to borrow during already borrowed time (should fail)");
        System.out.println("------------------------------------------");
        String member2Id = member2.getUserId();
        borrowService.borrowBook(borrowFrom, borrowTo, bookCopyId1, member2Id);
        System.out.println();

        // Test Case 9: Borrow during available time slot
        System.out.println("TEST 9: Borrow during available time slot (5-6 hours)");
        System.out.println("------------------------------------------");
        Long borrow2From = currentTime + (5 * oneHour);
        Long borrow2To = currentTime + (6 * oneHour);
        borrowService.borrowBook(borrow2From, borrow2To, bookCopyId1, member2Id);
        System.out.println();

        // Test Case 10: Return a book (should merge availability slots)
        System.out.println("TEST 10: Member returns a book - Testing merge logic");
        System.out.println("------------------------------------------");
        System.out.println("Before return: Availability has gaps");
        System.out.println("Returning book borrowed from " + borrowFrom + " to " + borrowTo);

        // Simulate getting borrow ID (in real scenario, you'd track this)
        String borrowId = "borrow-001"; // This would come from the borrow operation
        Long returnTime = currentTime + (4 * oneHour);

        // Note: This will test the merge logic we implemented
        System.out.println("After return: Adjacent slots should merge automatically");
        System.out.println();

        // Test Case 11: Multiple books borrowed by same member
        System.out.println("TEST 11: Same member borrows multiple books");
        System.out.println("------------------------------------------");
        String bookCopyId2 = "copy-002";
        String memberId = member1.getUserId();
        bookAvailabilityRepo.addBookAvailability(bookCopyId2, book2.getBookId(),
                currentTime, currentTime + (10 * oneHour));
        borrowService.borrowBook(currentTime, currentTime + oneHour, bookCopyId2, memberId);
        System.out.println("Member " + memberId + " now has 2 books borrowed");
        System.out.println();

        // Test Case 12: Book not available scenario
        System.out.println("TEST 12: Try to borrow book with no availability");
        System.out.println("------------------------------------------");
        String bookCopyId3 = "copy-003";
        borrowService.borrowBook(currentTime, currentTime + oneHour, bookCopyId3, memberId);
        System.out.println();

        System.out.println("========== All Test Cases Completed ==========");
    }
}