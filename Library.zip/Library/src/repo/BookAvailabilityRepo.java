package repo;

import data.BookAvailability;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class BookAvailabilityRepo {

    public static BookAvailabilityRepo instance = null;

    private BookAvailabilityRepo() {
    }

    public static BookAvailabilityRepo getInstance() {
        if (instance == null) {
            instance = new BookAvailabilityRepo();
        }
        return instance;
    }

    public Map<String, BookAvailability> bookAvailabilityMap = new HashMap<>();
    public Map<String, List<String>> bookCopyToBookAvailability = new HashMap<>();

    public BookAvailability addBookAvailability(String bookCopyId, String bookId, Long availableFrom,
                                                Long availableTo) {
        BookAvailability bookAvailability = new BookAvailability(UUID.randomUUID().toString(), bookCopyId, bookId, availableFrom, availableTo, false);
        bookAvailabilityMap.put(bookAvailability.getBookAvailabilityId(), bookAvailability);
        List<String> bookAvailabilityIds = bookCopyToBookAvailability.getOrDefault(bookCopyId, new ArrayList<>());
        bookAvailabilityIds.add(bookAvailability.getBookAvailabilityId());
        bookCopyToBookAvailability.put(bookCopyId, bookAvailabilityIds);
        return bookAvailability;
    }

    public BookAvailability deleteBookAvailability(String bookIdAvailabilityId) {
        BookAvailability bookAvailability = bookAvailabilityMap.get(bookIdAvailabilityId);
        if (!bookAvailabilityMap.containsKey(bookIdAvailabilityId)) {
            throw new RuntimeException("Book availability does not exists");
        }
        bookAvailability.setDeleted(true);
        bookAvailabilityMap.put(bookAvailability.getBookAvailabilityId(), bookAvailability);
        return bookAvailability;
    }
    
    public BookAvailability getBookAvailabilityForTimeRange(Long from , Long to, String bookCopyId){
        List<String> bookCopyAvailabiltyIds = bookCopyToBookAvailability.get(bookCopyId);
        if (bookCopyAvailabiltyIds == null || bookCopyAvailabiltyIds.isEmpty()) {
            return null;
        }
        for(String bookCopyAvailabiltyId : bookCopyAvailabiltyIds){
            BookAvailability bookAvailability = bookAvailabilityMap.get(bookCopyAvailabiltyId);
            if(bookAvailability.isDeleted()){
                continue;
            }
            if(bookAvailability.getAvailableFrom() <= from && bookAvailability.getAvailableTo() >= to){
                return bookAvailability;
            }
        }
        return null;
    }

    /**
     * Adds book availability with merging logic.
     * If there's an adjacent slot (from-1 or to+1), merge them.
     * Otherwise, create a new availability slot.
     */
    public BookAvailability addBookAvailabilityWithMerge(String bookCopyId, String bookId, Long from, Long to) {
        List<String> bookCopyAvailabilityIds = bookCopyToBookAvailability.getOrDefault(bookCopyId, new ArrayList<>());

        BookAvailability leftAdjacent = null;   // Slot ending at from-1
        BookAvailability rightAdjacent = null;  // Slot starting at to+1

        // Find adjacent slots
        for (String availabilityId : bookCopyAvailabilityIds) {
            BookAvailability availability = bookAvailabilityMap.get(availabilityId);
            if (availability.isDeleted()) {
                continue;
            }

            if (availability.getAvailableTo().equals(from - 1)) {
                leftAdjacent = availability;
            }

            if (availability.getAvailableFrom().equals(to + 1)) {
                rightAdjacent = availability;
            }
        }

        if (leftAdjacent != null && rightAdjacent != null) {
            Long mergedFrom = leftAdjacent.getAvailableFrom();
            Long mergedTo = rightAdjacent.getAvailableTo();

            deleteBookAvailability(leftAdjacent.getBookAvailabilityId());
            deleteBookAvailability(rightAdjacent.getBookAvailabilityId());

            return addBookAvailability(bookCopyId, bookId, mergedFrom, mergedTo);
        }

        if (leftAdjacent != null) {
            Long mergedFrom = leftAdjacent.getAvailableFrom();
            Long mergedTo = to;

            deleteBookAvailability(leftAdjacent.getBookAvailabilityId());

            return addBookAvailability(bookCopyId, bookId, mergedFrom, mergedTo);
        }

        if (rightAdjacent != null) {
            Long mergedFrom = from;
            Long mergedTo = rightAdjacent.getAvailableTo();

            deleteBookAvailability(rightAdjacent.getBookAvailabilityId());

            return addBookAvailability(bookCopyId, bookId, mergedFrom, mergedTo);
        }

        return addBookAvailability(bookCopyId, bookId, from, to);
    }
}
