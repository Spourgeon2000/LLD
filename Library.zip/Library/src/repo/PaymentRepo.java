package repo;

import data.Payment;
import data.PaymentStatus;
import data.PaymentType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PaymentRepo {
    public static PaymentRepo instance = null;

    private PaymentRepo() {
    }

    public static PaymentRepo getInstance() {
        if (instance == null) {
            instance = new PaymentRepo();
        }
        return instance;
    }

    public Map<String, Payment> paymentMap = new HashMap<>();

    public Payment addPayment(PaymentType paymentType, String paidBy, PaymentStatus paymentStatus) {
        Payment payment = new Payment(UUID.randomUUID().toString(), paymentType, paymentStatus, paidBy);
        paymentMap.put(payment.getPaymentId(), payment);
        return payment;
    }

    public Payment addPayment(PaymentType paymentType, String paidBy, PaymentStatus paymentStatus, Long amount) {
        Payment payment = new Payment(UUID.randomUUID().toString(), paymentType, paymentStatus, amount, paidBy);
        paymentMap.put(payment.getPaymentId(), payment);
        return payment;
    }

    public Payment updatePaymentStatus(String paymentId, PaymentStatus paymentStatus) {
        Payment payment = paymentMap.get(paymentId);
        if (payment == null) {
            throw new RuntimeException("Payment not found");
        }
        payment.setPaymentStatus(paymentStatus);
        paymentMap.put(paymentId, payment);
        return payment;
    }
}
