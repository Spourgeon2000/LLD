package repo;

import data.ROLE;
import data.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class UserRepo {

    private static UserRepo instance = null;

    private UserRepo() {
    }

    public static UserRepo getInstance() {
        if (instance == null) {
            instance = new UserRepo();
        }
        return instance;
    }

    private final Map<String, User> userMap = new HashMap<>();
    private final Map<String, User> emailToUser = new HashMap<>();

    public Map<String, User> getUserMap() {
        return userMap;
    }

    public Map<String, User> getEmailToUser() {
        return emailToUser;
    }

    public User addUser(String name, List<ROLE> roles, String email, String phoneNumber) {
        // Check if email already exists
        if (emailToUser.containsKey(email)) {
            System.out.println("User with email " + email + " already exists");
            return emailToUser.get(email);
        }

        User user = new User(UUID.randomUUID().toString(), name, roles, email, phoneNumber);
        userMap.put(user.getUserId(), user);
        emailToUser.put(email, user);
        return user;
    }

    public User getUserById(String userId) {
        return userMap.get(userId);
    }

    public User getUserByEmail(String email) {
        return emailToUser.get(email);
    }

    public User updateUser(String userId, String name, String email, String phoneNumber) {
        User user = userMap.get(userId);
        if (user == null) {
            throw new RuntimeException("User does not exist");
        }

        if (!user.getEmail().equals(email)) {
            emailToUser.remove(user.getEmail());
            emailToUser.put(email, user);
        }

        user.setName(name);
        user.setEmail(email);
        user.setPhoneNumber(phoneNumber);
        userMap.put(userId, user);
        return user;
    }

    public User updateUserRoles(String userId, List<ROLE> roles) {
        User user = userMap.get(userId);
        if (user == null) {
            throw new RuntimeException("User does not exist");
        }
        user.setRoles(roles);
        userMap.put(userId, user);
        return user;
    }

    public List<User> getUsersByRole(ROLE role) {
        List<User> users = new ArrayList<>();
        for (User user : userMap.values()) {
            if (user.hasRole(role)) {
                users.add(user);
            }
        }
        return users;
    }

    public void deleteUser(String userId) {
        User user = userMap.get(userId);
        if (user != null) {
            userMap.remove(userId);
            emailToUser.remove(user.getEmail());
        }
    }
}

