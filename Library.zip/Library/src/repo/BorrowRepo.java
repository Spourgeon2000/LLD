package repo;

import data.Borrow;
import data.BorrowStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class BorrowRepo {

    public static BorrowRepo instance = null;

    private BorrowRepo() {
    }

    public static BorrowRepo getInstance() {
        if (instance == null) {
            instance = new BorrowRepo();
        }
        return instance;
    }

    public Map<String, Borrow> getBorrowMap() {
        return borrowMap;
    }

    public Map<String, List<String>> getUserToBorrows() {
        return userToBorrows;
    }

    public Map<String, List<String>> getBookCopyToBorrows() {
        return bookCopyToBorrows;
    }

    public Map<String, Borrow> borrowMap = new HashMap<>();
    public Map<String, List<String>> userToBorrows = new HashMap<>();
    public Map<String, List<String>> bookCopyToBorrows = new HashMap<>();

    public List<String> getBorrowIdsByUser(String userId) {
        return userToBorrows.getOrDefault(userId, new ArrayList<>());
    }

    public Borrow getBorrowIdsByBorrowId(String borrowId) {
        return borrowMap.getOrDefault(borrowId, null);
    }
    public Borrow addBorrow(String borrowedBy, String bookCopyId, Long borrowedTime,
                            Long dueTime, BorrowStatus borrowStatus, String conditionAtBorrow) {
        Borrow borrow = new Borrow(
                UUID.randomUUID().toString(),
                borrowedBy,
                bookCopyId,
                borrowedTime,
                dueTime,
                null,
                borrowStatus,
                conditionAtBorrow,
                null
        );
        borrowMap.put(borrow.getBorrowId(), borrow);

        List<String> userBorrowIds = userToBorrows.getOrDefault(borrowedBy, new ArrayList<>());
        userBorrowIds.add(borrow.getBorrowId());
        userToBorrows.put(borrowedBy, userBorrowIds);

        List<String> bookCopyBorrowIds = bookCopyToBorrows.getOrDefault(bookCopyId, new ArrayList<>());
        bookCopyBorrowIds.add(borrow.getBorrowId());
        bookCopyToBorrows.put(bookCopyId, bookCopyBorrowIds);

        return borrow;
    }

    public Borrow updateBorrowStatus(String borrowId, BorrowStatus borrowStatus) {
        Borrow borrow = borrowMap.get(borrowId);
        if (!borrowMap.containsKey(borrowId)) {
            throw new RuntimeException("Borrow record does not exist");
        }
        borrow.setBorrowStatus(borrowStatus);
        borrowMap.put(borrow.getBorrowId(), borrow);
        return borrow;
    }

    public Borrow returnBook(String borrowId, Long returnedTime, String conditionAtReturn) {
        Borrow borrow = borrowMap.get(borrowId);
        if (!borrowMap.containsKey(borrowId)) {
            throw new RuntimeException("Borrow record does not exist");
        }
        borrow.setReturedTime(returnedTime);
        borrow.setConditionAtReturn(conditionAtReturn);
        borrow.setBorrowStatus(BorrowStatus.COMPLETED);
        borrowMap.put(borrow.getBorrowId(), borrow);
        return borrow;
    }

    public List<Borrow> getBorrowsByUser(String userId) {
        List<String> borrowIds = userToBorrows.getOrDefault(userId, new ArrayList<>());
        List<Borrow> borrows = new ArrayList<>();
        for (String borrowId : borrowIds) {
            borrows.add(borrowMap.get(borrowId));
        }
        return borrows;
    }

    public List<Borrow> getBorrowsByBookCopy(String bookCopyId) {
        List<String> borrowIds = bookCopyToBorrows.getOrDefault(bookCopyId, new ArrayList<>());
        List<Borrow> borrows = new ArrayList<>();
        for (String borrowId : borrowIds) {
            borrows.add(borrowMap.get(borrowId));
        }
        return borrows;
    }
}
