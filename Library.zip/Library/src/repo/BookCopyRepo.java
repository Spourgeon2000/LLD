package repo;

import data.BookCopy;
import data.BookLocation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class BookCopyRepo {

    public static BookCopyRepo instance = null;

    private BookCopyRepo() {
    }

    public static BookCopyRepo getInstance() {
        if (instance == null) {
            instance = new BookCopyRepo();
        }
        return instance;
    }
    public Map<String, BookCopy> bookCopies = new HashMap<>();
    public Map<String, List<String>> bookIdToBookCopies = new HashMap<>();

    public Map<String, BookCopy> getBookCopies() {
        return bookCopies;
    }

    public Map<String, List<String>> getBookIdToBookCopies() {
        return bookIdToBookCopies;
    }

    public BookCopy addBookCopy(String bookId, String condition, BookLocation shelfLocation) {
        BookCopy bookCopy =  new BookCopy(UUID.randomUUID().toString(), bookId, condition, shelfLocation);
        bookCopies.put(bookCopy.getBookCopyId(), bookCopy);
        bookIdToBookCopies.put(bookId, bookIdToBookCopies.getOrDefault(bookId, new ArrayList<>()));
        bookIdToBookCopies.get(bookId).add(bookCopy.getBookCopyId());
        return bookCopy;
    }

    public BookCopy updateBookCopy(String bookCopyId, String condition, BookLocation shelfLocation) {
        BookCopy bookCopy =  bookCopies.get(bookCopyId);
        bookCopy.setCondition(condition);
        bookCopy.setShelfLocation(shelfLocation);
        bookCopies.put(bookCopy.getBookCopyId(), bookCopy);
        return bookCopy;
    }

    public BookCopy getBookCopy(String bookCopyId) {
        return bookCopies.get(bookCopyId);
    }

}
