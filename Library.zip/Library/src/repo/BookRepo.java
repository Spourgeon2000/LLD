package repo;

import data.Book;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BookRepo {

    public static BookRepo instance = null;

    private BookRepo() {
    }

    public static BookRepo getInstance() {
        if (instance == null) {
            instance = new BookRepo();
        }
        return instance;
    }

    public Map<String, Book> getBookCopies() {
        return bookCopies;
    }

    public Map<String, Book> getTitleToBook() {
        return titleToBook;
    }

    public Book getBookByTitle(String title) {
        return titleToBook.get(title);
    }

    public Book getBookByBookId(String bookId) {
        return bookCopies.get(bookId);
    }


    private final Map<String, Book> bookCopies = new HashMap<>();
    private final Map<String, Book> titleToBook = new HashMap<>();

    public Book addBookCopy(String title, String author) {
        Long createdTime = System.currentTimeMillis();
        if (titleToBook.containsKey(title)) {
            System.out.println("Book already exists");
            return titleToBook.get(title);
        }
        Book book = new Book(UUID.randomUUID().toString(), title, author, createdTime, createdTime);
        bookCopies.put(book.getBookId(), book);
        titleToBook.put(book.getTitle(), book);
        return book;
    }

    public Book updateBook(String bookId,String title, String author) {
        Book book = bookCopies.get(bookId);
        if (!bookCopies.containsKey(bookId)){
            throw new RuntimeException("Book does not exists");
        }
        book.setAuthor(author);
        book.setTitle(title);
        book.setUpdatedTime(System.currentTimeMillis());
        bookCopies.put(book.getBookId(), book);
        return book;
    }
}
