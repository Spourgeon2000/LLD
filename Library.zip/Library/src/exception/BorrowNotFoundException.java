package exception;

/**
 * Thrown when a borrow record is not found
 */
public class BorrowNotFoundException extends LibraryException {
    public BorrowNotFoundException(String message) {
        super(message);
    }
}

