package exception;

/**
 * Thrown when a book is not available for borrowing
 */
public class BookNotAvailableException extends LibraryException {
    public BookNotAvailableException(String message) {
        super(message);
    }
}

