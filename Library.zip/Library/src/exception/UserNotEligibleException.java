package exception;

/**
 * Thrown when a user is not eligible to borrow books
 * Reasons: unpaid fines, overdue books, borrowing limit exceeded
 */
public class UserNotEligibleException extends LibraryException {
    public UserNotEligibleException(String message) {
        super(message);
    }
}

