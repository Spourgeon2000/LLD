package exception;

/**
 * Thrown when a payment record is not found
 */
public class PaymentNotFoundException extends LibraryException {
    public PaymentNotFoundException(String message) {
        super(message);
    }
}

