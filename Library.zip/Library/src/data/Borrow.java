package data;

public class Borrow {

    private String borrowId;
    private String borrowedBy;

    public String getBorrowId() {
        return borrowId;
    }

    public void setBorrowId(String borrowId) {
        this.borrowId = borrowId;
    }

    public String getBorrowedBy() {
        return borrowedBy;
    }

    public void setBorrowedBy(String borrowedBy) {
        this.borrowedBy = borrowedBy;
    }

    public String getBookCopyId() {
        return bookCopyId;
    }

    public void setBookCopyId(String bookCopyId) {
        this.bookCopyId = bookCopyId;
    }

    public Long getBorrowedTime() {
        return borrowedTime;
    }

    public void setBorrowedTime(Long borrowedTime) {
        this.borrowedTime = borrowedTime;
    }

    public Long getDueTime() {
        return dueTime;
    }

    public void setDueTime(Long dueTime) {
        this.dueTime = dueTime;
    }

    public Long getReturedTime() {
        return returedTime;
    }

    public void setReturedTime(Long returedTime) {
        this.returedTime = returedTime;
    }

    public BorrowStatus getBorrowStatus() {
        return borrowStatus;
    }

    public void setBorrowStatus(BorrowStatus borrowStatus) {
        this.borrowStatus = borrowStatus;
    }

    public String getConditionAtBorrow() {
        return conditionAtBorrow;
    }

    public void setConditionAtBorrow(String conditionAtBorrow) {
        this.conditionAtBorrow = conditionAtBorrow;
    }

    public String getConditionAtReturn() {
        return conditionAtReturn;
    }

    public void setConditionAtReturn(String conditionAtReturn) {
        this.conditionAtReturn = conditionAtReturn;
    }

    private String bookCopyId;
    private Long borrowedTime;
    private Long dueTime;
    private Long returedTime;

    public Borrow(String borrowId, String borrowedBy, String bookCopyId, Long borrowedTime, Long dueTime, Long returedTime, BorrowStatus borrowStatus, String conditionAtBorrow, String conditionAtReturn) {
        this.borrowId = borrowId;
        this.borrowedBy = borrowedBy;
        this.bookCopyId = bookCopyId;
        this.borrowedTime = borrowedTime;
        this.dueTime = dueTime;
        this.returedTime = returedTime;
        this.borrowStatus = borrowStatus;
        this.conditionAtBorrow = conditionAtBorrow;
        this.conditionAtReturn = conditionAtReturn;
    }

    private BorrowStatus borrowStatus;
    private String conditionAtBorrow;
    private String conditionAtReturn;
}
