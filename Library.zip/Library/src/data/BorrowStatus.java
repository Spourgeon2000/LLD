package data;

public enum BorrowStatus {
    RESERVED,
    ACTIVE,
    COMPLETED,
    OVERDUE,
    CANCELLED,
    NO_SHOW
}
