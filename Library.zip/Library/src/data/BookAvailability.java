package data;

public class BookAvailability {
    public BookAvailability(String bookAvailabilityId, String bookCopyId, String bookId, Long availableFrom, Long availableTo, boolean deleted) {
        this.bookAvailabilityId = bookAvailabilityId;
        this.bookCopyId = bookCopyId;
        this.bookId = bookId;
        this.availableFrom = availableFrom;
        this.availableTo = availableTo;
        this.deleted = deleted;
    }

    private String bookAvailabilityId;
    private String bookCopyId;
    private String bookId;
    private Long availableFrom;
    private Long availableTo;
    private boolean deleted;

    public boolean isDeleted() {
        return deleted;
    }

    public BookAvailability(String bookCopyId, String bookId, Long availableFrom, Long availableTo, boolean deleted) {
        this.bookCopyId = bookCopyId;
        this.bookId = bookId;
        this.availableFrom = availableFrom;
        this.availableTo = availableTo;
        this.deleted = deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public String getBookCopyId() {
        return bookCopyId;
    }

    public void setBookCopyId(String bookCopyId) {
        this.bookCopyId = bookCopyId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public Long getAvailableFrom() {
        return availableFrom;
    }

    public void setAvailableFrom(Long availableFrom) {
        this.availableFrom = availableFrom;
    }

    public String getBookAvailabilityId() {
        return bookAvailabilityId;
    }

    public void setBookAvailabilityId(String bookAvailabilityId) {
        this.bookAvailabilityId = bookAvailabilityId;
    }

    public Long getAvailableTo() {
        return availableTo;
    }

    public void setAvailableTo(Long availableTo) {
        this.availableTo = availableTo;
    }
}
