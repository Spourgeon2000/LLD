package data;

public enum ROLE {
    ADMIN,
    MEMBER
}
