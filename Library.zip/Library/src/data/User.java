package data;

import java.util.List;

public class User {
    private String userId;
    private String name;
    private List<ROLE> roles;
    private String email;
    private String phoneNumber;

    public User(String userId, String name, List<ROLE> roles, String email, String phoneNumber) {
        this.userId = userId;
        this.name = name;
        this.roles = roles;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<ROLE> getRoles() {
        return roles;
    }

    public void setRoles(List<ROLE> roles) {
        this.roles = roles;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * Check if user has a specific role
     */
    public boolean hasRole(ROLE role) {
        return roles != null && roles.contains(role);
    }

    /**
     * Check if user is an admin
     */
    public boolean isAdmin() {
        return hasRole(ROLE.ADMIN);
    }

    /**
     * Check if user is a member
     */
    public boolean isMember() {
        return hasRole(ROLE.MEMBER);
    }
}
