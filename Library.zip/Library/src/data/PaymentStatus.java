package data;

public enum PaymentStatus {
    PENDING,
    PAID
}
