package data;

public class BookCopy {
    private String bookCopyId;
    private String bookId;
    private String condition;
    private BookLocation shelfLocation;

    public String getBookCopyId() {
        return bookCopyId;
    }

    public BookCopy(String bookCopyId, String bookId, String condition, BookLocation shelfLocation) {
        this.bookCopyId = bookCopyId;
        this.bookId = bookId;
        this.condition = condition;
        this.shelfLocation = shelfLocation;
    }

    public void setBookCopyId(String bookCopyId) {
        this.bookCopyId = bookCopyId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public BookLocation getShelfLocation() {
        return shelfLocation;
    }

    public void setShelfLocation(BookLocation shelfLocation) {
        this.shelfLocation = shelfLocation;
    }
}
