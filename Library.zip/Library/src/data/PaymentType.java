package data;

public enum PaymentType {
    UPI,
    CASH,
    CARD,
    NET_BANKING
}
