package Data;

public enum Channel {
    SMS,
    EMAIL,
    PUSH
}
