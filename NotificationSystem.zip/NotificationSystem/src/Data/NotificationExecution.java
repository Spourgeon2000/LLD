package Data;

import java.time.LocalDateTime;

public class NotificationExecution {
    private Integer executionId;
    private Integer notificationId;
    private NotificationExecutionStatus status;
    private LocalDateTime scheduledTime;
    private LocalDateTime sentTime;
    private LocalDateTime deliveredTime;
    private int retryCount;
    private String errorMessage;

    public NotificationExecution() {
        this.retryCount = 0;
        this.status = NotificationExecutionStatus.PENDING;
    }

    public NotificationExecution(Integer notificationId, LocalDateTime scheduledTime) {
        this();
        this.notificationId = notificationId;
        this.scheduledTime = scheduledTime;
    }

    public Integer getExecutionId() {
        return executionId;
    }

    public void setExecutionId(Integer executionId) {
        this.executionId = executionId;
    }

    public Integer getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(Integer notificationId) {
        this.notificationId = notificationId;
    }

    public NotificationExecutionStatus getStatus() {
        return status;
    }

    public void setStatus(NotificationExecutionStatus status) {
        this.status = status;
    }

    public LocalDateTime getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(LocalDateTime scheduledTime) {
        this.scheduledTime = scheduledTime;
    }

    public LocalDateTime getSentTime() {
        return sentTime;
    }

    public void setSentTime(LocalDateTime sentTime) {
        this.sentTime = sentTime;
    }

    public LocalDateTime getDeliveredTime() {
        return deliveredTime;
    }

    public void setDeliveredTime(LocalDateTime deliveredTime) {
        this.deliveredTime = deliveredTime;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public void incrementRetryCount() {
        this.retryCount++;
    }

}

