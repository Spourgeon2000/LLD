package Data;

public enum NotificationType {
    ONETIME,
    RECURRING,
    SCHEDULED
}
