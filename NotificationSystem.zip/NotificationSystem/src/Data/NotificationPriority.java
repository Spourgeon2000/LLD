package Data;

public enum NotificationPriority {
    HIGH,
    MEDIUM,
    LOW
}
