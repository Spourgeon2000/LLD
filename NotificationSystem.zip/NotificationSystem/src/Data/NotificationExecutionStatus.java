package Data;

public enum NotificationExecutionStatus {
    PENDING,      // Created but not yet processed
    SENT,         // Sent to external service (SMS/Email provider)
    DELIVERED,    // Successfully delivered to recipient
    FAILED,       // Failed after all retry attempts
    RETRYING      // Currently retrying after failure
}

