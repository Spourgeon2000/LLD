package Data;

public class IdGenerator {
    private static Integer id = 0;

    public static Integer getNextId() {
        id++;
        return id;
    }
}
