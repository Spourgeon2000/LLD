package Data;

public class UserPreferences {
    private boolean isOptedForSms;
    private boolean isOptedForEmail;
    private boolean isOptedForPush;

    public boolean isOptedForSms() {
        return isOptedForSms;
    }

    public void setOptedForSms(boolean optedForSms) {
        isOptedForSms = optedForSms;
    }

    public boolean isOptedForEmail() {
        return isOptedForEmail;
    }

    public void setOptedForEmail(boolean optedForEmail) {
        isOptedForEmail = optedForEmail;
    }

    public boolean isOptedForPush() {
        return isOptedForPush;
    }

    public void setOptedForPush(boolean optedForPush) {
        isOptedForPush = optedForPush;
    }
}
