package Data;

public enum RecurringInterval {
    DAILY,
    WEEKLY,
    MONTHLY,
    YEARLY
}
