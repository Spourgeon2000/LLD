package Data;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Template class for reusable notification messages
 * Supports placeholders in format: {placeholderName}
 * Example: "Hello {name}, your order {orderId} is ready!"
 */
public class Template {
    private Integer templateId;
    private String name;
    private String content;  // Content with placeholders like {name}, {orderId}
    private Channel channel;

    public Integer getTemplateId() {
        return templateId;
    }

    public void setTemplateId(Integer templateId) {
        this.templateId = templateId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Channel getChannel() {
        return channel;
    }

    public void setChannel(Channel channel) {
        this.channel = channel;
    }

    /**
     * Replace placeholders in template content with actual values
     * Example: "Hello {name}" with {"name": "John"} -> "Hello John"
     */
    public String render(Map<String, String> placeholders) {
        String result = this.content;

        if (placeholders != null) {
            for (Map.Entry<String, String> entry : placeholders.entrySet()) {
                String placeholder = "{" + entry.getKey() + "}";
                String value = entry.getValue() != null ? entry.getValue() : "";
                result = result.replace(placeholder, value);
            }
        }

        return result;
    }

    /**
     * Check if template has a specific placeholder
     */
    public boolean hasPlaceholder(String placeholderName) {
        String placeholder = "{" + placeholderName + "}";
        return this.content.contains(placeholder);
    }

    /**
     * Get all placeholders in the template
     * Returns list of placeholder names (without curly braces)
     */
    public java.util.List<String> getPlaceholders() {
        java.util.List<String> placeholders = new java.util.ArrayList<>();
        Pattern pattern = Pattern.compile("\\{([^}]+)\\}");
        Matcher matcher = pattern.matcher(this.content);

        while (matcher.find()) {
            placeholders.add(matcher.group(1));
        }

        return placeholders;
    }

    /**
     * Validate if all required placeholders are provided
     */
    public boolean validatePlaceholders(Map<String, String> providedPlaceholders) {
        java.util.List<String> requiredPlaceholders = getPlaceholders();

        if (providedPlaceholders == null) {
            return requiredPlaceholders.isEmpty();
        }

        for (String required : requiredPlaceholders) {
            if (!providedPlaceholders.containsKey(required)) {
                return false;
            }
        }

        return true;
    }

    @Override
    public String toString() {
        return "Template{" +
                "templateId=" + templateId +
                ", name='" + name + '\'' +
                ", content='" + content + '\'' +
                ", channel=" + channel +
                ", placeholders=" + getPlaceholders() +
                '}';
    }
}
