package Data;

public enum NotificationStatus {
    PENDING,      // Created but not yet processed
    SCHEDULED,    // Scheduled for future delivery
    SENT,         // Sent to external service (SMS/Email provider)
    DELIVERED,    // Successfully delivered to recipient
    FAILED,       // Failed after all retry attempts
    RETRYING      // Currently retrying after failure
}
