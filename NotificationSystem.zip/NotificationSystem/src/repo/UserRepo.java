package repo;

import Data.IdGenerator;
import Data.User;
import Data.UserPreferences;

import java.util.HashMap;
import java.util.Map;

public class UserRepo {

    private static UserRepo instance = null;

    private UserRepo() {
    }

    public static UserRepo getInstance() {
        if (instance == null) {
            instance = new UserRepo();
        }
        return instance;
    }

    Map<Integer, User> usersMap = new HashMap<>();

    public void saveUser(String name, String email, String phoneNumber) {
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setUserId(IdGenerator.getNextId());
        user.setPhoneNumber(phoneNumber);
        UserPreferences userPreferences = new UserPreferences();
        userPreferences.setOptedForEmail(false);
        userPreferences.setOptedForSms(false);
        userPreferences.setOptedForPush(false);
        user.setPreferences(userPreferences);
        usersMap.put(user.getUserId(), user);
    }

    public User getUser(Integer userId) {
        return usersMap.get(userId);
    }

    public void addUserPreference(Integer userId, boolean isOptedForSms, boolean isOptedForEmail, boolean isOptedForPush) {
        User user = usersMap.get(userId);
        UserPreferences userPreferences = user.getPreferences();
        userPreferences.setOptedForSms(isOptedForSms);
        userPreferences.setOptedForEmail(isOptedForEmail);
        userPreferences.setOptedForPush(isOptedForPush);
        user.setPreferences(userPreferences);
        usersMap.put(userId, user);
    }
}
