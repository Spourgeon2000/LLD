package repo;

import Data.Channel;
import Data.Notification;
import Data.NotificationPriority;
import Data.NotificationType;
import Data.RecurringInterval;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import static Data.IdGenerator.getNextId;

public class NotificationRepo {
    private static NotificationRepo instance = null;

    private NotificationRepo() {
    }

    public static NotificationRepo getInstance() {
        if (instance == null) {
            instance = new NotificationRepo();
        }
        return instance;
    }

    public Map<Integer, Notification> getNotifications() {
        return notifications;
    }

    public void setNotifications(Map<Integer, Notification> notifications) {
        this.notifications = notifications;
    }

    public static void setInstance(NotificationRepo instance) {
        NotificationRepo.instance = instance;
    }

    Map<Integer, Notification> notifications = new HashMap<>();

    public void saveNotification(String content, Channel channel, NotificationPriority priority, NotificationType type,
                                 RecurringInterval recurringInterval, Integer templateId, LocalDateTime scheduledTime) {
        Notification notification = new Notification();
        notification.setNotificationId(getNextId());
        notification.setContent(content);
        notification.setChannel(channel);
        notification.setPriority(priority);
        notification.setType(type);
        notification.setRecurringInterval(recurringInterval);
        notification.setTemplateId(templateId);
        notification.setCreatedTime(LocalDateTime.now());
        notification.setScheduledTime(scheduledTime);
        notification.setNextTriggerTime(scheduledTime);
        notifications.put(notification.getNotificationId(), notification);
    }

    public void updateLastTriggerTime(Integer notificationId, LocalDateTime lastTriggerTime) {
        Notification notification = notifications.get(notificationId);
        notification.setLastTriggerTime(lastTriggerTime);
        notifications.put(notificationId, notification);
    }

    public void updateNextTriggerTime(Integer notificationId, LocalDateTime nextTriggerTime) {
        Notification notification = notifications.get(notificationId);
        notification.setNextTriggerTime(nextTriggerTime);
        notifications.put(notificationId, notification);
    }

    public Notification getNotification(Integer notificationId) {
        return notifications.get(notificationId);
    }

}
