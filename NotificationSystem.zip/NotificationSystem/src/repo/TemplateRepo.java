package repo;

import Data.Channel;
import Data.Template;

import java.util.HashMap;
import java.util.Map;

import static Data.IdGenerator.getNextId;

public class TemplateRepo {
    private static TemplateRepo instance = null;

    private TemplateRepo() {
    }

    public static TemplateRepo getInstance() {
        if (instance == null) {
            instance = new TemplateRepo();
        }
        return instance;
    }

    Map<Integer, Template> templates = new HashMap<>();

    public Template saveTemplate(String name, String content, Channel channel) {
        Template template = new Template();
        template.setTemplateId(getNextId());
        template.setName(name);
        template.setContent(content);
        template.setChannel(channel);
        templates.put(template.getTemplateId(), template);
        return template;
    }

    public Template getTemplate(Integer templateId) {
        return templates.get(templateId);
    }

    public Template getTemplateByName(String name) {
        return templates.values().stream()
                .filter(template -> template.getName().equals(name))
                .findFirst()
                .orElse(null);
    }

    public void updateTemplateContent(Integer templateId, String content) {
        Template template = templates.get(templateId);
        if (template != null) {
            template.setContent(content);
            templates.put(templateId, template);
        }
    }

    public void updateTemplateName(Integer templateId, String name) {
        Template template = templates.get(templateId);
        if (template != null) {
            template.setName(name);
            templates.put(templateId, template);
        }
    }


}
