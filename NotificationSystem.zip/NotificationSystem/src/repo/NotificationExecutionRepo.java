package repo;

import Data.NotificationExecution;
import Data.NotificationExecutionStatus;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static Data.IdGenerator.getNextId;

public class NotificationExecutionRepo {
    private static NotificationExecutionRepo instance = null;

    private NotificationExecutionRepo() {
    }

    public static NotificationExecutionRepo getInstance() {
        if (instance == null) {
            instance = new NotificationExecutionRepo();
        }
        return instance;
    }

    Map<Integer, NotificationExecution> executions = new HashMap<>();


    public NotificationExecution saveExecution(Integer notificationId, LocalDateTime scheduledTime) {
        NotificationExecution execution = new NotificationExecution();
        execution.setExecutionId(getNextId());
        execution.setNotificationId(notificationId);
        execution.setScheduledTime(scheduledTime);
        execution.setStatus(NotificationExecutionStatus.PENDING);
        executions.put(execution.getExecutionId(), execution);
        return execution;
    }


    public NotificationExecution getExecution(Integer executionId) {
        return executions.get(executionId);
    }

    public void updateStatus(Integer executionId, NotificationExecutionStatus status) {
        NotificationExecution execution = executions.get(executionId);
        if (execution != null) {
            execution.setStatus(status);
            executions.put(executionId, execution);
        }
    }

    public void updateSentTime(Integer executionId, LocalDateTime sentTime) {
        NotificationExecution execution = executions.get(executionId);
        if (execution != null) {
            execution.setSentTime(sentTime);
            executions.put(executionId, execution);
        }
    }

    public void updateDeliveredTime(Integer executionId, LocalDateTime deliveredTime) {
        NotificationExecution execution = executions.get(executionId);
        if (execution != null) {
            execution.setDeliveredTime(deliveredTime);
            executions.put(executionId, execution);
        }
    }

    public void updateErrorMessage(Integer executionId, String errorMessage) {
        NotificationExecution execution = executions.get(executionId);
        if (execution != null) {
            execution.setErrorMessage(errorMessage);
            executions.put(executionId, execution);
        }
    }

    public void updateRetryCount(Integer executionId, int retryCount) {
        NotificationExecution execution = executions.get(executionId);
        if (execution != null) {
            execution.setRetryCount(retryCount);
            executions.put(executionId, execution);
        }
    }

    public List<NotificationExecution> getExecutionsByNotificationId(Integer notificationId) {
        return executions.values().stream()
                .filter(exec -> exec.getNotificationId().equals(notificationId))
                .collect(Collectors.toList());
    }

    public List<NotificationExecution> getAllExecutions() {
        return executions.values().stream().collect(Collectors.toList());
    }
}

