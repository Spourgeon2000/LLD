package service;

import Data.Notification;
import Data.NotificationExecution;
import Data.NotificationType;
import Data.RecurringInterval;
import repo.NotificationExecutionRepo;
import repo.NotificationRepo;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class NotificationScheduler {
    private static NotificationScheduler instance = null;
    private ScheduledExecutorService scheduler;
    private NotificationRepo notificationRepo;
    private NotificationExecutionRepo executionRepo;
    private EnhancedNotificationService notificationService;
    private boolean isRunning = false;

    private NotificationScheduler() {
        this.scheduler = Executors.newScheduledThreadPool(2);
        this.notificationRepo = NotificationRepo.getInstance();
        this.executionRepo = NotificationExecutionRepo.getInstance();
        this.notificationService = EnhancedNotificationService.getInstance();
    }

    public static NotificationScheduler getInstance() {
        if (instance == null) {
            instance = new NotificationScheduler();
        }
        return instance;
    }

    public void start() {
        if (isRunning) {
            System.out.println("⚠️ Scheduler is already running");
            return;
        }

        System.out.println("🚀 Starting Notification Scheduler...");
        isRunning = true;

        // Schedule task to run every 5 seconds
        scheduler.scheduleAtFixedRate(() -> {
            try {
                processScheduledNotifications();
                processRecurringNotifications();
            } catch (Exception e) {
                System.err.println("❌ Scheduler error: " + e.getMessage());
                e.printStackTrace();
            }
        }, 0, 5, TimeUnit.SECONDS);

        System.out.println("✅ Scheduler started successfully");
    }

    public void stop() {
        if (!isRunning) {
            System.out.println("⚠️ Scheduler is not running");
            return;
        }

        System.out.println("🛑 Stopping Notification Scheduler...");
        scheduler.shutdown();
        isRunning = false;
        System.out.println("✅ Scheduler stopped");
    }

    private void processScheduledNotifications() {
        List<Notification> scheduledNotifications = notificationRepo.getNotifications().values().stream()
                .filter(n -> n.getType() == NotificationType.SCHEDULED)
                .filter(n -> !n.getCompleted())
                .filter(n -> isReadyToSend(n))
                .collect(Collectors.toList());

        for (Notification notification : scheduledNotifications) {
            System.out.println("⏰ Processing scheduled notification: " + notification.getNotificationId());

            // Create execution
            NotificationExecution execution = executionRepo.saveExecution(
                    notification.getNotificationId(),
                    notification.getScheduledTime()
            );

            // Send notification
            notificationService.sendNotificationExecution(execution);

            // Mark notification as completed
            notification.setCompleted(true);
        }
    }

    private void processRecurringNotifications() {
        List<Notification> recurringNotifications = notificationRepo.getNotifications().values().stream()
                .filter(n -> n.getType() == NotificationType.RECURRING)
                .filter(n -> isReadyToSend(n))
                .collect(Collectors.toList());

        for (Notification notification : recurringNotifications) {
            System.out.println("🔄 Processing recurring notification: " + notification.getNotificationId() +
                    " (Interval: " + notification.getRecurringInterval() + ")");

            NotificationExecution execution = executionRepo.saveExecution(
                    notification.getNotificationId(),
                    notification.getNextTriggerTime()
            );

            notificationService.sendNotificationExecution(execution);

            notificationRepo.updateLastTriggerTime(
                    notification.getNotificationId(),
                    LocalDateTime.now()
            );

            LocalDateTime nextTrigger = calculateNextTriggerTime(
                    notification.getNextTriggerTime(),
                    notification.getRecurringInterval()
            );
            notificationRepo.updateNextTriggerTime(notification.getNotificationId(), nextTrigger);

            System.out.println("   Next trigger scheduled for: " + nextTrigger);
        }
    }

    /**
     * Check if notification is ready to be sent
     */
    private boolean isReadyToSend(Notification notification) {
        if (notification.getNextTriggerTime() == null && notification.getScheduledTime() == null) {
            return true; // Immediate notification
        }

        LocalDateTime triggerTime = notification.getNextTriggerTime() != null
                ? notification.getNextTriggerTime()
                : notification.getScheduledTime();

        LocalDateTime now = LocalDateTime.now();
        return now.isAfter(triggerTime) || now.isEqual(triggerTime);
    }

    /**
     * Calculate next trigger time based on recurring interval
     */
    private LocalDateTime calculateNextTriggerTime(LocalDateTime currentTrigger, RecurringInterval interval) {
        if (interval == null) {
            return null;
        }

        switch (interval) {
            case DAILY:
                return currentTrigger.plusDays(1);
            case WEEKLY:
                return currentTrigger.plusWeeks(1);
            case MONTHLY:
                return currentTrigger.plusMonths(1);
            case YEARLY:
                return currentTrigger.plusYears(1);
            default:
                return currentTrigger.plusDays(1);
        }
    }

    public boolean isRunning() {
        return isRunning;
    }
}

