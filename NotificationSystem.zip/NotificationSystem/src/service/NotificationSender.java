package service;

import Data.NotificationExecution;

public interface NotificationSender {
    boolean send(NotificationExecution execution);
}

