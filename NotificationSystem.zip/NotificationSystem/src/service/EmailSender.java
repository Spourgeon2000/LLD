package service;

import Data.*;
import repo.NotificationExecutionRepo;
import repo.NotificationRepo;
import repo.UserRepo;

import java.time.LocalDateTime;
import java.util.Random;

/**
 * Email Notification Sender
 * Simulates sending emails through external service (SendGrid, AWS SES, etc.)
 */
public class EmailSender implements NotificationSender {
    private NotificationRepo notificationRepo;
    private UserRepo userRepo;
    private NotificationExecutionRepo executionRepo;
    private Random random;

    public EmailSender() {
        this.notificationRepo = NotificationRepo.getInstance();
        this.userRepo = UserRepo.getInstance();
        this.executionRepo = NotificationExecutionRepo.getInstance();
        this.random = new Random();
    }

    @Override
    public boolean send(NotificationExecution execution) {
        try {
            Notification notification = notificationRepo.getNotification(execution.getNotificationId());
            User user = userRepo.getUser(notification.getUserId());

            // Check if user has opted for Email
            if (!user.getPreferences().isOptedForEmail()) {
                System.out.println("❌ Email: User " + user.getName() + " has not opted for Email notifications");
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
                executionRepo.updateErrorMessage(execution.getExecutionId(), "User not opted for Email");
                return false;
            }

            // Simulate Email sending (in real world, call SendGrid/AWS SES API)
            System.out.println("📧 Sending Email to " + user.getEmail());
            System.out.println("   Subject: Notification");
            System.out.println("   Content: " + notification.getContent());

            // Simulate network delay
            Thread.sleep(150);

            // Simulate 85% success rate (for testing retry mechanism)
            boolean success = random.nextDouble() > 0.15;

            if (success) {
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.SENT);
                executionRepo.updateSentTime(execution.getExecutionId(), LocalDateTime.now());
                
                // Simulate delivery confirmation
                Thread.sleep(100);
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.DELIVERED);
                executionRepo.updateDeliveredTime(execution.getExecutionId(), LocalDateTime.now());
                
                System.out.println("✅ Email delivered successfully to " + user.getEmail());
                return true;
            } else {
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
                executionRepo.updateErrorMessage(execution.getExecutionId(), "Email service unavailable");
                System.out.println("❌ Email failed: Service unavailable");
                return false;
            }

        } catch (Exception e) {
            System.err.println("❌ Email sending error: " + e.getMessage());
            executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
            executionRepo.updateErrorMessage(execution.getExecutionId(), "Exception: " + e.getMessage());
            return false;
        }
    }
}

