package service;

import Data.*;
import repo.NotificationExecutionRepo;
import repo.NotificationRepo;
import repo.UserRepo;

import java.time.LocalDateTime;
import java.util.Random;

/**
 * SMS Notification Sender
 * Simulates sending SMS through external gateway (Twilio, AWS SNS, etc.)
 */
public class SMSSender implements NotificationSender {
    private NotificationRepo notificationRepo;
    private UserRepo userRepo;
    private NotificationExecutionRepo executionRepo;
    private Random random;

    public SMSSender() {
        this.notificationRepo = NotificationRepo.getInstance();
        this.userRepo = UserRepo.getInstance();
        this.executionRepo = NotificationExecutionRepo.getInstance();
        this.random = new Random();
    }

    @Override
    public boolean send(NotificationExecution execution) {
        try {
            Notification notification = notificationRepo.getNotification(execution.getNotificationId());
            User user = userRepo.getUser(notification.getUserId());

            // Check if user has opted for SMS
            if (!user.getPreferences().isOptedForSms()) {
                System.out.println("❌ SMS: User " + user.getName() + " has not opted for SMS notifications");
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
                executionRepo.updateErrorMessage(execution.getExecutionId(), "User not opted for SMS");
                return false;
            }

            // Simulate SMS sending (in real world, call Twilio/AWS SNS API)
            System.out.println("📱 Sending SMS to " + user.getPhoneNumber());
            System.out.println("   Content: " + notification.getContent());

            // Simulate network delay
            Thread.sleep(100);

            // Simulate 80% success rate (for testing retry mechanism)
            boolean success = random.nextDouble() > 0.2;

            if (success) {
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.SENT);
                executionRepo.updateSentTime(execution.getExecutionId(), LocalDateTime.now());
                
                // Simulate delivery confirmation
                Thread.sleep(50);
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.DELIVERED);
                executionRepo.updateDeliveredTime(execution.getExecutionId(), LocalDateTime.now());
                
                System.out.println("✅ SMS delivered successfully to " + user.getPhoneNumber());
                return true;
            } else {
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
                executionRepo.updateErrorMessage(execution.getExecutionId(), "SMS gateway timeout");
                System.out.println("❌ SMS failed: Gateway timeout");
                return false;
            }

        } catch (Exception e) {
            System.err.println("❌ SMS sending error: " + e.getMessage());
            executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
            executionRepo.updateErrorMessage(execution.getExecutionId(), "Exception: " + e.getMessage());
            return false;
        }
    }
}

