package service;

import Data.*;
import repo.NotificationExecutionRepo;
import repo.NotificationRepo;
import repo.UserRepo;

import java.time.LocalDateTime;
import java.util.Random;

public class PushSender implements NotificationSender {
    private NotificationRepo notificationRepo;
    private UserRepo userRepo;
    private NotificationExecutionRepo executionRepo;
    private Random random;

    public PushSender() {
        this.notificationRepo = NotificationRepo.getInstance();
        this.userRepo = UserRepo.getInstance();
        this.executionRepo = NotificationExecutionRepo.getInstance();
        this.random = new Random();
    }

    @Override
    public boolean send(NotificationExecution execution) {
        try {
            Notification notification = notificationRepo.getNotification(execution.getNotificationId());
            User user = userRepo.getUser(notification.getUserId());

            // Check if user has opted for Push
            if (!user.getPreferences().isOptedForPush()) {
                System.out.println("❌ Push: User " + user.getName() + " has not opted for Push notifications");
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
                executionRepo.updateErrorMessage(execution.getExecutionId(), "User not opted for Push");
                return false;
            }

            // Simulate Push notification sending (in real world, call Firebase/OneSignal API)
            System.out.println("🔔 Sending Push Notification to " + user.getName());
            System.out.println("   Content: " + notification.getContent());

            // Simulate network delay
            Thread.sleep(80);

            // Simulate 90% success rate (Push is usually more reliable)
            boolean success = random.nextDouble() > 0.1;

            if (success) {
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.SENT);
                executionRepo.updateSentTime(execution.getExecutionId(), LocalDateTime.now());
                
                // Simulate delivery confirmation
                Thread.sleep(50);
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.DELIVERED);
                executionRepo.updateDeliveredTime(execution.getExecutionId(), LocalDateTime.now());
                
                System.out.println("✅ Push notification delivered successfully to " + user.getName());
                return true;
            } else {
                executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
                executionRepo.updateErrorMessage(execution.getExecutionId(), "Push service unavailable");
                System.out.println("❌ Push failed: Service unavailable");
                return false;
            }

        } catch (Exception e) {
            System.err.println("❌ Push sending error: " + e.getMessage());
            executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
            executionRepo.updateErrorMessage(execution.getExecutionId(), "Exception: " + e.getMessage());
            return false;
        }
    }
}

