package service;

import Data.NotificationExecution;
import Data.NotificationExecutionStatus;
import repo.NotificationExecutionRepo;

public class RetryHandler {
    private static RetryHandler instance = null;
    private static final int MAX_RETRIES = 3;
    
    private NotificationExecutionRepo executionRepo;

    private RetryHandler() {
        this.executionRepo = NotificationExecutionRepo.getInstance();
    }

    public static RetryHandler getInstance() {
        if (instance == null) {
            instance = new RetryHandler();
        }
        return instance;
    }

    public long calculateBackoffDelay(int retryCount) {
        long baseDelay = 1000; // 1 second
        return baseDelay * (long) Math.pow(2, retryCount);
    }

    public boolean shouldRetry(NotificationExecution execution) {
        return execution.getRetryCount() < MAX_RETRIES;
    }

    public void retryWithBackoff(NotificationExecution execution, NotificationSender sender) {
        if (!shouldRetry(execution)) {
            // Max retries reached, mark as failed
            executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
            executionRepo.updateErrorMessage(execution.getExecutionId(), 
                "Failed after " + MAX_RETRIES + " retry attempts");
            System.out.println("❌ Execution " + execution.getExecutionId() + 
                " FAILED after " + MAX_RETRIES + " retries");
            return;
        }

        // Calculate backoff delay
        long delay = calculateBackoffDelay(execution.getRetryCount());
        
        System.out.println("⏳ Retrying execution " + execution.getExecutionId() + 
            " (Attempt " + (execution.getRetryCount() + 1) + "/" + MAX_RETRIES + 
            ") after " + delay + "ms delay...");

        // Update status to RETRYING
        executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.RETRYING);

        try {
            // Simulate delay (exponential backoff)
            Thread.sleep(delay);

            // Increment retry count
            execution.incrementRetryCount();
            executionRepo.updateRetryCount(execution.getExecutionId(), execution.getRetryCount());

            // Attempt to send again
            boolean success = sender.send(execution);

            if (success) {
                System.out.println("✅ Retry successful for execution " + execution.getExecutionId());
            } else {
                System.out.println("❌ Retry failed for execution " + execution.getExecutionId());
                // Recursively retry with next backoff
                retryWithBackoff(executionRepo.getExecution(execution.getExecutionId()), sender);
            }

        } catch (InterruptedException e) {
            System.err.println("Retry interrupted: " + e.getMessage());
            executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
            executionRepo.updateErrorMessage(execution.getExecutionId(), "Retry interrupted: " + e.getMessage());
        }
    }

    public void handleFailure(NotificationExecution execution, String errorMessage, NotificationSender sender) {
        System.out.println("⚠️ Notification execution " + execution.getExecutionId() + " failed: " + errorMessage);
        
        executionRepo.updateErrorMessage(execution.getExecutionId(), errorMessage);

        if (shouldRetry(execution)) {
            retryWithBackoff(execution, sender);
        } else {
            executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
            System.out.println("❌ Max retries reached for execution " + execution.getExecutionId());
        }
    }

    public String getRetryStats(NotificationExecution execution) {
        return String.format("Retry Stats - Execution ID: %d, Retry Count: %d/%d, Status: %s",
            execution.getExecutionId(),
            execution.getRetryCount(),
            MAX_RETRIES,
            execution.getStatus());
    }

    public int getMaxRetries() {
        return MAX_RETRIES;
    }
}

