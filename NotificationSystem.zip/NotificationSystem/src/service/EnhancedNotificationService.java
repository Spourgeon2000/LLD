package service;

import Data.*;
import repo.NotificationExecutionRepo;
import repo.NotificationRepo;
import repo.UserRepo;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * Enhanced Notification Service with Priority Queue and Retry Support
 * Processes notifications based on priority (HIGH > MEDIUM > LOW)
 */
public class EnhancedNotificationService {
    private static EnhancedNotificationService instance = null;

    private NotificationRepo notificationRepo;
    private UserRepo userRepo;
    private NotificationExecutionRepo executionRepo;
    private RetryHandler retryHandler;

    private PriorityQueue<Notification> notificationQueue;

    private Map<Channel, NotificationSender> senders;

    private EnhancedNotificationService() {
        this.notificationRepo = NotificationRepo.getInstance();
        this.userRepo = UserRepo.getInstance();
        this.executionRepo = NotificationExecutionRepo.getInstance();
        this.retryHandler = RetryHandler.getInstance();
        this.notificationQueue = new PriorityQueue<>();

        this.senders = new HashMap<>();
        this.senders.put(Channel.SMS, new SMSSender());
        this.senders.put(Channel.EMAIL, new EmailSender());
        this.senders.put(Channel.PUSH, new PushSender());
    }

    public static EnhancedNotificationService getInstance() {
        if (instance == null) {
            instance = new EnhancedNotificationService();
        }
        return instance;
    }

    /**
     * Create and enqueue a notification
     */
    public Notification createNotification(Integer userId, String content, Channel channel, 
                                          NotificationPriority priority, NotificationType type,
                                          RecurringInterval recurringInterval, Integer templateId, 
                                          LocalDateTime scheduledTime) {
        
        notificationRepo.saveNotification(content, channel, priority, type, 
                                         recurringInterval, templateId, scheduledTime);
        
        // Get the created notification (last one added)
        Notification notification = notificationRepo.getNotifications().values().stream()
                .reduce((first, second) -> second)
                .orElse(null);
        
        if (notification != null) {
            notification.setUserId(userId);

            if (type == NotificationType.ONETIME && scheduledTime == null) {
                notificationQueue.offer(notification);
                System.out.println("✅ Notification added to priority queue: " + notification.getNotificationId() + 
                        " (Priority: " + priority + ")");
            } else {
                System.out.println("✅ Notification created: " + notification.getNotificationId() + 
                        " (Type: " + type + ", Scheduled: " + scheduledTime + ")");
            }
        }
        
        return notification;
    }

    public void processQueue() {
        System.out.println("\n🔄 Processing notification queue (" + notificationQueue.size() + " notifications)...");
        
        while (!notificationQueue.isEmpty()) {
            Notification notification = notificationQueue.poll();
            System.out.println("\n📤 Processing notification " + notification.getNotificationId() + 
                    " (Priority: " + notification.getPriority() + ")");
            
            // Create execution
            NotificationExecution execution = executionRepo.saveExecution(
                    notification.getNotificationId(),
                    LocalDateTime.now()
            );
            
            // Send notification
            sendNotificationExecution(execution);
        }
        
        System.out.println("\n✅ Queue processing complete\n");
    }

    public void sendNotificationExecution(NotificationExecution execution) {
        Notification notification = notificationRepo.getNotification(execution.getNotificationId());
        User user = userRepo.getUser(notification.getUserId());
        
        if (user == null) {
            System.out.println("❌ User not found for notification " + notification.getNotificationId());
            executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
            executionRepo.updateErrorMessage(execution.getExecutionId(), "User not found");
            return;
        }

        System.out.println("📨 Sending " + notification.getChannel() + " notification to " + user.getName());
        
        // Get appropriate sender for channel
        NotificationSender sender = senders.get(notification.getChannel());
        
        if (sender == null) {
            System.out.println("❌ No sender found for channel: " + notification.getChannel());
            executionRepo.updateStatus(execution.getExecutionId(), NotificationExecutionStatus.FAILED);
            executionRepo.updateErrorMessage(execution.getExecutionId(), "No sender for channel");
            return;
        }

        // Attempt to send
        boolean success = sender.send(execution);
        
        // If failed, trigger retry mechanism
        if (!success) {
            NotificationExecution latestExecution = executionRepo.getExecution(execution.getExecutionId());
            retryHandler.handleFailure(latestExecution, 
                    latestExecution.getErrorMessage(), sender);
        }
    }

    /**
     * Get current queue size
     */
    public int getQueueSize() {
        return notificationQueue.size();
    }

    /**
     * Clear the queue
     */
    public void clearQueue() {
        notificationQueue.clear();
        System.out.println("🗑️ Notification queue cleared");
    }
}

