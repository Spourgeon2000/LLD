package service;

import repo.NotificationRepo;
import repo.UserRepo;

public class UserService {
    private static UserService instance = null;

    private UserService() {
    }

    public static UserService getInstance() {
        if (instance == null) {
            instance = new UserService();
        }
        return instance;
    }

    UserRepo userRepo = UserRepo.getInstance();

    public void addUser(String name, String email, String phoneNumber) {
        userRepo.saveUser(name, email, phoneNumber);
    }

    public void addUserPreference(Integer userId, boolean isOptedForSms, boolean isOptedForEmail, boolean isOptedForPush) {
        userRepo.addUserPreference(userId, isOptedForSms, isOptedForEmail, isOptedForPush);
    }

}
