package service;

import Data.Channel;
import Data.Notification;
import Data.NotificationPriority;
import Data.NotificationType;
import Data.RecurringInterval;
import Data.User;
import Data.UserPreferences;
import repo.NotificationRepo;
import repo.UserRepo;

import java.time.LocalDateTime;

public class NotificationService {
    private static NotificationService instance = null;

    private NotificationService() {
    }

    public static NotificationService getInstance() {
        if (instance == null) {
            instance = new NotificationService();
        }
        return instance;
    }

    NotificationRepo notificationRepo = NotificationRepo.getInstance();
    UserRepo userRepo = UserRepo.getInstance();

    public void addNotification(String content, Channel channel, NotificationPriority priority, NotificationType type,
                                RecurringInterval recurringInterval, Integer templateId, LocalDateTime scheduledTime) {
        notificationRepo.saveNotification(content, channel, priority, type, recurringInterval, templateId, scheduledTime);
        System.out.println("Notification added successfully");
    }

    public void sendNotification(Integer notificationId, Integer userId) {
        User user = userRepo.getUser(userId);
        UserPreferences userPreferences = user.getPreferences();
        Notification notification = notificationRepo.getNotification(notificationId);
        if (userPreferences.isOptedForSms() && notification.getChannel() == Channel.SMS) {
            //external api call
            System.out.println("Sending SMS notification to " + user.getPhoneNumber());
        } else if (userPreferences.isOptedForEmail() && notification.getChannel() == Channel.EMAIL) {
            //external api call
            System.out.println("Sending Email notification to " + user.getEmail());
        } else if (userPreferences.isOptedForPush() && notification.getChannel() == Channel.PUSH) {
            //external api call
            System.out.println("Sending Push notification to " + user.getName());
        } else {
            System.out.println("User is not opted for " + notification.getChannel());
        }
    }
}
