import Data.*;
import service.*;
import repo.*;

import java.time.LocalDateTime;

/**
 * Complete Notification System Demo
 * Demonstrates all 8 requirements:
 * 1. Multiple notification types (SMS, Email, Push)
 * 2. Scheduled notifications
 * 3. Recurring notifications
 * 4. User preferences
 * 5. Priority-based delivery
 * 6. Status tracking
 * 7. Reusable templates
 * 8. Retry with exponential backoff
 */
public class Main {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("╔════════════════════════════════════════════════════════════╗");
        System.out.println("║     NOTIFICATION SYSTEM - COMPLETE DEMO                    ║");
        System.out.println("╚════════════════════════════════════════════════════════════╝\n");

        // Initialize services
        UserService userService = UserService.getInstance();
        EnhancedNotificationService notificationService = EnhancedNotificationService.getInstance();
        NotificationScheduler scheduler = NotificationScheduler.getInstance();
        TemplateRepo templateRepo = TemplateRepo.getInstance();

        // ============================================================
        // REQUIREMENT 1 & 4: Create Users with Preferences
        // ============================================================
        System.out.println("\n📋 STEP 1: Creating Users with Preferences\n");

        userService.addUser("Alice Johnson", "alice@example.com", "+1-555-0101");
        userService.addUserPreference(1, true, true, true); // Opted for all channels

        userService.addUser("Bob Smith", "bob@example.com", "+1-555-0102");
        userService.addUserPreference(2, true, false, true); // SMS and Push only

        userService.addUser("Charlie Brown", "charlie@example.com", "+1-555-0103");
        userService.addUserPreference(3, false, true, false); // Email only

        System.out.println("✅ Created 3 users with different preferences");

        // ============================================================
        // REQUIREMENT 7: Create Reusable Templates
        // ============================================================
        System.out.println("\n📋 STEP 2: Creating Reusable Templates\n");

        Template otpTemplate = templateRepo.saveTemplate(
                "otp_template",
                "Your OTP is {otp}. Valid for {minutes} minutes.",
                Channel.SMS
        );

        Template welcomeTemplate = templateRepo.saveTemplate(
                "welcome_template",
                "Welcome {name}! Your account has been created successfully.",
                Channel.EMAIL
        );

        System.out.println("✅ Created 2 reusable templates");

        // ============================================================
        // REQUIREMENT 5: Priority-Based Delivery (HIGH > MEDIUM > LOW)
        // ============================================================
        System.out.println("\n📋 STEP 3: Testing Priority-Based Delivery\n");

        // Create notifications with different priorities
        notificationService.createNotification(
                1, "Low priority message", Channel.EMAIL,
                NotificationPriority.LOW, NotificationType.ONETIME,
                null, null, null
        );

        notificationService.createNotification(
                1, "High priority alert!", Channel.SMS,
                NotificationPriority.HIGH, NotificationType.ONETIME,
                null, null, null
        );

        notificationService.createNotification(
                1, "Medium priority update", Channel.PUSH,
                NotificationPriority.MEDIUM, NotificationType.ONETIME,
                null, null, null
        );

        System.out.println("\n🔄 Processing queue (HIGH priority will be processed first)...\n");
        Thread.sleep(1000);
        notificationService.processQueue();

        // ============================================================
        // REQUIREMENT 2: Scheduled Notifications
        // ============================================================
        System.out.println("\n📋 STEP 4: Creating Scheduled Notification\n");

        LocalDateTime scheduledTime = LocalDateTime.now().plusSeconds(10);
        notificationService.createNotification(
                2, "Scheduled reminder: Meeting in 10 minutes", Channel.SMS,
                NotificationPriority.MEDIUM, NotificationType.SCHEDULED,
                null, null, scheduledTime
        );

        System.out.println("✅ Scheduled notification created for: " + scheduledTime);

        // ============================================================
        // REQUIREMENT 3: Recurring Notifications
        // ============================================================
        System.out.println("\n📋 STEP 5: Creating Recurring Notification\n");

        LocalDateTime firstTrigger = LocalDateTime.now().plusSeconds(15);
        notificationService.createNotification(
                3, "Daily standup reminder at 9 AM", Channel.EMAIL,
                NotificationPriority.LOW, NotificationType.RECURRING,
                RecurringInterval.DAILY, null, firstTrigger
        );

        System.out.println("✅ Recurring notification created (DAILY interval)");
        System.out.println("   First trigger: " + firstTrigger);

        // ============================================================
        // REQUIREMENT 8: Retry with Exponential Backoff
        // ============================================================
        System.out.println("\n📋 STEP 6: Testing Retry Mechanism\n");
        System.out.println("Note: Senders have simulated failure rates to demonstrate retry");
        System.out.println("      If a notification fails, it will retry with exponential backoff");
        System.out.println("      Delays: 1s, 2s, 4s (max 3 retries)\n");

        // ============================================================
        // Start Scheduler for Scheduled & Recurring Notifications
        // ============================================================
        System.out.println("\n📋 STEP 7: Starting Notification Scheduler\n");
        scheduler.start();

        System.out.println("⏳ Waiting for scheduled and recurring notifications...");
        System.out.println("   (Scheduler checks every 5 seconds)\n");

        // Wait for 30 seconds to see scheduled and recurring notifications
        Thread.sleep(30000);

        // ============================================================
        // Stop Scheduler
        // ============================================================
        scheduler.stop();

        // ============================================================
        // REQUIREMENT 6: Display Status Tracking
        // ============================================================
        System.out.println("\n📋 STEP 8: Notification Status Tracking\n");

        NotificationExecutionRepo executionRepo = NotificationExecutionRepo.getInstance();
        var allExecutions = executionRepo.getAllExecutions();

        System.out.println("Total Executions: " + allExecutions.size());
        System.out.println("\nExecution History:");
        System.out.println("─────────────────────────────────────────────────────────");

        for (NotificationExecution exec : allExecutions) {
            System.out.printf("ID: %d | Notification: %d | Status: %s | Retries: %d%n",
                    exec.getExecutionId(),
                    exec.getNotificationId(),
                    exec.getStatus(),
                    exec.getRetryCount());

            if (exec.getErrorMessage() != null) {
                System.out.println("   Error: " + exec.getErrorMessage());
            }
        }

        System.out.println("\n╔════════════════════════════════════════════════════════════╗");
        System.out.println("║     ALL 8 REQUIREMENTS DEMONSTRATED SUCCESSFULLY! ✅       ║");
        System.out.println("╚════════════════════════════════════════════════════════════╝");
    }
}