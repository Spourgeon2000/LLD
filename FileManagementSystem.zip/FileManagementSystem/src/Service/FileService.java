package Service;

import Es.FileEs;
import data.File;
import data.User;
import repo.FileDb;

public class FileService {

    public static FileService instance = null;

    public static FileService getInstance() {
        if (instance == null) {
            instance = new FileService();
            return instance;
        }
        return instance;
    }

    FileDb fileDb = FileDb.getInstance();
    FileEs fileEs = FileEs.getInstance();

    public void addFile(String path, String name, User createdBy, String content) {
        File file = fileDb.addFile(path, name, createdBy, content);
        if(file == null) return;
        fileEs.addNodeInEs(file);
    }

    public void copyFile(String source, String destination, Integer fileId) {
        File file = fileDb.copyFile(source, destination, fileId);
        if(file == null) return;
        fileEs.addNodeInEs(file);
    }

    public void moveFile(String source, String destination, Integer fileId) {
        fileDb.moveFile(source, destination, fileId);
    }

    public void deleteFile(Integer fileId) {
        File file = (File) FileDb.getInstance().getFileMap().get(fileId);
        fileDb.deleteFile(fileId);
        if(file == null) return;
        fileEs.removeNodeFromEs(file);
    }
}
