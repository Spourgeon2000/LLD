package Service;

import Es.FileEs;
import data.Folder;
import repo.FileDb;

public class FolderService {
    public static FolderService instance = null;

    public static FolderService getInstance() {
        if (instance == null) {
            instance = new FolderService();
            return instance;
        }
        return instance;
    }

    FileDb fileDb = FileDb.getInstance();
    FileEs fileEs = FileEs.getInstance();

    public void createFolder(String path, String name, data.User createdBy) {
        Folder folder = fileDb.addFolder(path, name, createdBy);
        if(folder == null) return;
        fileEs.addNodeInEs(folder);
    }
}
