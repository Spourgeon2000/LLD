package Service;

import Es.FileEs;
import data.Node;
import repo.FileDb;

import java.util.Comparator;

public class FilesFetchService {
    public static FilesFetchService instance = null;
    public static FilesFetchService getInstance() {
        if (instance == null) {
            instance = new FilesFetchService();
            return instance;
        }
        return instance;
    }

    FileEs fileEs = FileEs.getInstance();
    FileDb fileDb = FileDb.getInstance();
    public void fetchFilesByUserName(String name){
        System.out.println("Files created by " + name + " are :");
        fileEs.getNameToNodeMap().values().stream().filter(node -> node.getCreatedBy().getName().equals(name)).
                forEach(node -> System.out.println(node.getName()));
        System.out.println();
    }

    public void fetchAllFiles(){
        System.out.println("Files are :");
        fileEs.getNameToNodeMap().values().stream().filter(node -> node.getFileType().equals(data.FileType.FILE)).sorted(Comparator.comparing(Node::getCreatedTime)).
                forEach(node -> System.out.println(node.getName()));
        System.out.println();
    }

    public void fetchFilesByName(String fileName) {
        System.out.println("Files with name " + fileName + " are :");
        fileEs.getNameToNodeMap().values().stream().filter(node -> node.getFileType().equals(data.FileType.FILE)).filter(node -> node.getName().equals(fileName)).
                forEach(node -> System.out.println(node.getName()));
        System.out.println();
    }
}
