package repo;

import data.File;
import data.FileType;
import data.Folder;
import data.IdGenerator;
import data.Node;
import data.User;

import java.util.HashMap;
import java.util.Map;

public class FileDb {
    private static FileDb instance = null;

    private FileDb() {
    }

    public static FileDb getInstance() {
        if (instance == null) {
            instance = new FileDb();
            return instance;
        }
        return instance;
    }

    public Map<Integer, Node> getFileMap() {
        return fileMap;
    }

    public void setFileMap(Map<Integer, Node> fileMap) {
        this.fileMap = fileMap;
    }

    public static void setInstance(FileDb instance) {
        FileDb.instance = instance;
    }

    public Map<String, Integer> getPathToNodeIdMap() {
        return pathToNodeIdMap;
    }

    public void setPathToNodeIdMap(Map<String, Integer> pathToNodeIdMap) {
        this.pathToNodeIdMap = pathToNodeIdMap;
    }

    Map<Integer, Node> fileMap = new HashMap<>();
    Map<String, Integer> pathToNodeIdMap = new HashMap<>();
    Map<String, Integer> fileNameToNodeIdMap = new HashMap<>();

    public Folder addFolder(String path, String name, User createdBy) {
        if (!pathToNodeIdMap.containsKey(path) && !path.isEmpty()) {
            System.out.println("No folder path is present to add");
            return null;
        }
        Folder node = new Folder();
        node.setName(name);
        node.setCreatedBy(createdBy);
        node.setCreatedTime(System.currentTimeMillis());
        node.setFileType(FileType.FOLDER);
        node.setNodeId(IdGenerator.getId());
        if (path.isEmpty()) {
            node.setPath("/" + name);
        } else {
            Integer parentNodeId = pathToNodeIdMap.get(path);
            node.setPath(path + "/" + name);
            Node parentNode = fileMap.get(parentNodeId);
            ((Folder) parentNode).getChildren().put(name, node);
            fileMap.put(parentNodeId, parentNode);
        }
        fileMap.put(node.getNodeId(), node);
        pathToNodeIdMap.put(node.getPath(), node.getNodeId());
        System.out.println("Successfully added the folder");
        return node;
    }

    public File addFile(String path, String name, User createdBy, String content) {
        if (!pathToNodeIdMap.containsKey(path) && !path.isEmpty()) {
            System.out.println("No folder path is present to add file");
            return null;
        }
        if (pathToNodeIdMap.containsKey(path + "/" + name)) {
            System.out.println("File already present , do you want to replace it");
            return null;
        }
        File node = new File();
        node.setName(name);
        node.setContent(content);
        node.setCreatedBy(createdBy);
        node.setCreatedTime(System.currentTimeMillis());
        node.setFileType(FileType.FILE);
        node.setNodeId(IdGenerator.getId());
        if (path.isEmpty()) {
            node.setPath("/" + name);
        } else {
            node.setPath(path + "/" + name);
        }
        fileMap.put(node.getNodeId(), node);
        pathToNodeIdMap.put(node.getPath(), node.getNodeId());
        System.out.println("Successfully added the file");
        return node;
    }

    public File copyFile(String sourcePath, String destinationPath, Integer fileId) {
        if (!pathToNodeIdMap.containsKey(destinationPath)) {
            System.out.println("No destination folder path is present to copy file");
            return null;
        }
        if (!pathToNodeIdMap.containsKey(sourcePath)) {
            System.out.println("No source folder path is present to copy file");
            return null;
        }
        if(!fileMap.containsKey(fileId)){
            System.out.println("File not present to copy");
            return null;
        }
        if (pathToNodeIdMap.containsKey(destinationPath + "/" + fileMap.get(fileId).getName())) {
            System.out.println("File already present , do you want to replace it");
            return null;
        }
        Node node = fileMap.get(fileId);
        if (node.getFileType().equals(FileType.FILE)) {
            File newNode = addFile(destinationPath, node.getName(), node.getCreatedBy(), ((File) node).getContent());
            System.out.println("Successfully copied the file");
            return newNode;
        } else {
            System.out.println("Not a file");
        }
        return  null;
    }

    public void moveFile(String sourcePath, String destinationPath, Integer fileId) {
        if (!pathToNodeIdMap.containsKey(destinationPath)) {
            System.out.println("No destination folder path is present to move file");
            return;
        }
        if (!pathToNodeIdMap.containsKey(sourcePath)) {
            System.out.println("No source folder path is present to move file");
            return;
        }
        if (pathToNodeIdMap.containsKey(destinationPath + "/" + fileMap.get(fileId).getName())) {
            System.out.println("File already present , do you want to replace it");
            return;
        }
        Node node = fileMap.get(fileId);
        if (node.getFileType().equals(FileType.FILE)) {
            String name = fileMap.get(fileId).getName();
            Integer parentNodeId = pathToNodeIdMap.get(sourcePath);
            Node parentNode = fileMap.get(parentNodeId);
            if (parentNode.getFileType().equals(FileType.FOLDER)) {
                ((Folder) parentNode).getChildren().remove(name);
            } else {
                System.out.println("Not a folder");
                return;
            }
            Integer newParentNodeId = pathToNodeIdMap.get(destinationPath);
            Folder newParentNode = (Folder) fileMap.get(newParentNodeId);
            newParentNode.getChildren().put(name, node);
            node.setPath(destinationPath + "/" + fileMap.get(fileId).getName());
            System.out.println("Successfully moved the file");
        } else {
            System.out.println("Not a file");
        }
    }

    public void deleteFile(Integer fileId) {
        Node node = fileMap.get(fileId);
        if(node == null){
            System.out.println("cannot delete a file as it is not present ");
            return;
        }
        String parentPath = node.getPath().replace("/" + node.getName(), "");
        Integer parentNodeId = pathToNodeIdMap.get(parentPath);
        if (!parentPath.isEmpty()) {
            Folder parentNode = (Folder) fileMap.get(parentNodeId);
            parentNode.getChildren().remove(node.getName());
        }
        fileMap.remove(node.getNodeId());
        pathToNodeIdMap.remove(node.getPath());
    }

}
