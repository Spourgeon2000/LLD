package data;

import java.util.HashMap;
import java.util.Map;

public class Folder extends Node {
    private Map<String, Node> children= new HashMap<>();

    public Map<String, Node> getChildren() {
        return children;
    }

    public void setChildren(Map<String, Node> children) {
        this.children = children;
    }
}
