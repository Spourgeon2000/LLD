package data;

public enum FileType {
    FILE,
    FOLDER
}
