import Service.FileService;
import Service.FilesFetchService;
import Service.FolderService;
import data.User;

public class Main {
    public static void main(String[] args) {
        System.out.println("========== FILE MANAGEMENT SYSTEM - TEST SUITE ==========\n");

        // Initialize services
        FolderService folderService = FolderService.getInstance();
        FileService fileService = FileService.getInstance();
        FilesFetchService fetchService = FilesFetchService.getInstance();

        // Create mock users
        User user1 = createUser(1L, "Alice", "alice@example.com");
        User user2 = createUser(2L, "Bob", "bob@example.com");
        User user3 = createUser(3L, "Charlie", "charlie@example.com");

        System.out.println("✓ Created 3 mock users: Alice, Bob, Charlie\n");

        // ========== TEST 1: Create Folders ==========
        System.out.println("========== TEST 1: Create Folders ==========");
        folderService.createFolder("", "documents", user1);
        folderService.createFolder("/documents", "work", user1);
        folderService.createFolder("/documents", "personal", user2);
        folderService.createFolder("/documents/work", "projects", user1);
        folderService.createFolder("", "photos", user2);
        folderService.createFolder("/photos", "vacation", user2);
        System.out.println();

        // ========== TEST 2: Add Files ==========
        System.out.println("========== TEST 2: Add Files ==========");
        fileService.addFile("/documents/work", "report.txt", user1, "Q4 Sales Report");
        fileService.addFile("/documents/work", "presentation.ppt", user1, "Client Presentation");
        fileService.addFile("/documents/personal", "notes.txt", user2, "Personal Notes");
        fileService.addFile("/documents/work/projects", "project1.doc", user1, "Project Documentation");
        fileService.addFile("/photos/vacation", "beach.jpg", user2, "Beach photo");
        fileService.addFile("/photos", "profile.jpg", user3, "Profile picture");
        System.out.println();

        // ========== TEST 3: Add Duplicate File (Should be ignored) ==========
        System.out.println("========== TEST 3: Add Duplicate File (Should be ignored) ==========");
        fileService.addFile("/documents/work", "report.txt", user1, "Updated Report");
        System.out.println();

        // ========== TEST 4: List All Files ==========
        System.out.println("========== TEST 4: List All Files ==========");
        fetchService.fetchAllFiles();

        // ========== TEST 5: Search Files by Creator ==========
        System.out.println("========== TEST 5: Search Files by Creator ==========");
        fetchService.fetchFilesByUserName("Alice");
        fetchService.fetchFilesByUserName("Bob");
        fetchService.fetchFilesByUserName("Charlie");

        // ========== TEST 6: Search Files by Name ==========
        System.out.println("========== TEST 6: Search Files by Name ==========");
        fetchService.fetchFilesByName("report.txt");
        fetchService.fetchFilesByName("notes.txt");
        fetchService.fetchFilesByName("nonexistent.txt");

        // ========== TEST 7: Copy File ==========
        System.out.println("========== TEST 7: Copy File ==========");
        // Get file ID for report.txt (it's the first file added, so ID should be 7)
        // Folders: documents(1), work(2), personal(3), projects(4), photos(5), vacation(6)
        // Files: report.txt(7), presentation.ppt(8), notes.txt(9), project1.doc(10), beach.jpg(11), profile.jpg(12)
        fileService.copyFile("/documents/work", "/documents/personal", 7);
        System.out.println("After copy:");
        fetchService.fetchAllFiles();

        // ========== TEST 8: Copy File to Same Location (Should fail) ==========
        System.out.println("========== TEST 8: Copy File to Same Location (Should fail) ==========");
        fileService.copyFile("/documents/work", "/documents/work", 7);
        System.out.println();

        // ========== TEST 9: Move File ==========
        System.out.println("========== TEST 9: Move File ==========");
        fileService.moveFile("/documents/work", "/documents/personal", 8); // Move presentation.ppt
        System.out.println("After move:");
        fetchService.fetchAllFiles();

        // ========== TEST 10: Move File to Location with Duplicate (Should fail) ==========
        System.out.println("========== TEST 10: Move File to Location with Duplicate (Should fail) ==========");
        fileService.moveFile("/documents/personal", "/documents/work", 13); // Try to move copied report.txt back
        System.out.println();

        // ========== TEST 11: Delete File ==========
        System.out.println("========== TEST 11: Delete File ==========");
        fileService.deleteFile(9); // Delete notes.txt
        System.out.println("After delete:");
        fetchService.fetchAllFiles();

        // ========== TEST 12: Delete Non-existent File (Should fail gracefully) ==========
        System.out.println("========== TEST 12: Delete Non-existent File (Should fail gracefully) ==========");
        fileService.deleteFile(999);
        System.out.println();

        // ========== TEST 13: Add File to Non-existent Folder (Should fail) ==========
        System.out.println("========== TEST 13: Add File to Non-existent Folder (Should fail) ==========");
        fileService.addFile("/nonexistent/folder", "test.txt", user1, "Test content");
        System.out.println();

        // ========== TEST 14: Create Folder in Non-existent Path (Should fail) ==========
        System.out.println("========== TEST 14: Create Folder in Non-existent Path (Should fail) ==========");
        folderService.createFolder("/nonexistent/path", "newfolder", user1);
        System.out.println();

        // ========== TEST 15: Copy Non-existent File (Should fail) ==========
        System.out.println("========== TEST 15: Copy Non-existent File (Should fail) ==========");
        fileService.copyFile("/documents/work", "/documents/personal", 999);
        System.out.println();

        // ========== TEST 16: Final State - List All Files ==========
        System.out.println("========== TEST 16: Final State - List All Files ==========");
        fetchService.fetchAllFiles();

        System.out.println("========== ALL TESTS COMPLETED ==========");
    }

    // Helper method to create mock users
    private static User createUser(Long id, String name, String email) {
        User user = new User();
        user.setUserId(id);
        user.setName(name);
        user.setEmail(email);
        return user;
    }
}