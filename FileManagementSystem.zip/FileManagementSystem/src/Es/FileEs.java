package Es;

import data.Node;
import java.util.HashMap;
import java.util.Map;

public class FileEs {
    public static FileEs instance = null;
    public static FileEs getInstance(){
        if(instance == null){
            instance = new FileEs();
        }
        return  instance;
    }

    public Map<String, Node> getNameToNodeMap() {
        return nameToNodeMap;
    }

    public void setNameToNodeMap(Map<String, Node> nameToNodeMap) {
        this.nameToNodeMap = nameToNodeMap;
    }

    public static void setInstance(FileEs instance) {
        FileEs.instance = instance;
    }

    Map<String, Node> nameToNodeMap = new HashMap<>();

    public void addNodeInEs(Node node){
        nameToNodeMap.put(node.getPath(), node);
    }

    public void removeNodeFromEs(Node node){
        nameToNodeMap.remove(node.getPath());
    }
}
