import data.*;
import service.TransactionService;
import service.UserService;
import service.WalletService;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Wallet System Test Cases ===\n");

        WalletService walletService = WalletService.getInstance();
        UserService userService = UserService.getInstance();
        TransactionService transactionService = TransactionService.getInstance();

        try {
            // Test Case 1: Create Users
            System.out.println("Test 1: Creating Users");
            User user1 = new User();
            user1.setUserId("user1");
            user1.setName("Alice");
            userService.addUser(user1);

            User user2 = new User();
            user2.setUserId("user2");
            user2.setName("Bob");
            userService.addUser(user2);
            System.out.println("✓ Created users: Alice and Bob\n");

            // Test Case 2: Create Wallets
            System.out.println("Test 2: Creating Wallets");
            Wallet wallet1 = new Wallet();
            wallet1.setOwnedByUserId("user1");
            wallet1.setAmount(0L);
            wallet1.setStatus(WalletStatus.ACTIVE);
            wallet1 = walletService.addWallet(wallet1);
            System.out.println("✓ Created wallet for Alice: " + wallet1.getWalletId());

            Wallet wallet2 = new Wallet();
            wallet2.setOwnedByUserId("user2");
            wallet2.setAmount(0L);
            wallet2.setStatus(WalletStatus.ACTIVE);
            wallet2 = walletService.addWallet(wallet2);
            System.out.println("✓ Created wallet for Bob: " + wallet2.getWalletId() + "\n");

            // Test Case 3: Add Money to Wallet
            System.out.println("Test 3: Adding Money to Alice's Wallet");
            Long balance = walletService.addMoney(wallet1.getWalletId(), 1000L);
            System.out.println("✓ Added ₹1000. New balance: ₹" + balance + "\n");

            // Test Case 4: Check Balance
            System.out.println("Test 4: Checking Balance");
            Long currentBalance = walletService.getBalanceForWallet(wallet1.getWalletId());
            System.out.println("✓ Alice's balance: ₹" + currentBalance + "\n");

            // Test Case 5: Wallet-to-Wallet Transfer
            System.out.println("Test 5: Wallet-to-Wallet Transfer (Alice → Bob)");
            walletService.addMoney(wallet2.getWalletId(), 500L); // Give Bob some initial balance

            Account sourceAccount = new Account();
            sourceAccount.setAccountId(wallet1.getWalletId());
            sourceAccount.setAccountType(AccountType.WALLET);

            Account destAccount = new Account();
            destAccount.setAccountId(wallet2.getWalletId());
            destAccount.setAccountType(AccountType.WALLET);

            WalletToWalletTransferMetadata transferMetadata = new WalletToWalletTransferMetadata();
            transferMetadata.setSourceAccount(sourceAccount);
            transferMetadata.setDestinationAccount(destAccount);

            Transaction transfer = transactionService.transferMoney(transferMetadata, 300L, TransactionType.NORMAL);
            System.out.println("✓ Transfer successful. Transaction ID: " + transfer.getTransactionID());
            System.out.println("  Alice's balance: ₹" + walletService.getBalanceForWallet(wallet1.getWalletId()));
            System.out.println("  Bob's balance: ₹" + walletService.getBalanceForWallet(wallet2.getWalletId()) + "\n");

            // Test Case 6: External Payment Callback (Simulating payment from bank)
            System.out.println("Test 6: External Payment Callback");
            Account externalSource = new Account();
            externalSource.setAccountId("BANK_ACCOUNT_123");
            externalSource.setAccountType(AccountType.EXTERNAL);

            Account walletDest = new Account();
            walletDest.setAccountId(wallet1.getWalletId());
            walletDest.setAccountType(AccountType.WALLET);

            ExternalTransferMetaData externalMetadata = new ExternalTransferMetaData();
            externalMetadata.setSourceAccount(externalSource);
            externalMetadata.setDestinationAccount(walletDest);

            Transaction externalTxn = transactionService.externalCallBack(externalMetadata, 2000L, "EXT_TXN_001");
            System.out.println("✓ External payment received. Transaction ID: " + externalTxn.getTransactionID());
            System.out.println("  Alice's new balance: ₹" + walletService.getBalanceForWallet(wallet1.getWalletId()) + "\n");

            // Test Case 7: Idempotent External Callback (Same external transaction ID)
            System.out.println("Test 7: Testing Idempotency (Duplicate External Callback)");
            Transaction duplicateTxn = transactionService.externalCallBack(externalMetadata, 2000L, "EXT_TXN_001");
            System.out.println("✓ Duplicate callback handled. Returned existing transaction: " + duplicateTxn.getTransactionID());
            System.out.println("  Alice's balance unchanged: ₹" + walletService.getBalanceForWallet(wallet1.getWalletId()) + "\n");

            // Test Case 8: Initiate Refund
            System.out.println("Test 8: Initiating Refund");
            Account refundSource = new Account();
            refundSource.setAccountId("BANK_ACCOUNT_123");
            refundSource.setAccountType(AccountType.EXTERNAL);

            Account refundDest = new Account();
            refundDest.setAccountId(wallet1.getWalletId());
            refundDest.setAccountType(AccountType.WALLET);

            ExternalTransferMetaData refundMetadata = new ExternalTransferMetaData();
            refundMetadata.setSourceAccount(refundSource);
            refundMetadata.setDestinationAccount(refundDest);

            Transaction refund = transactionService.initiateRefund(
                externalTxn.getTransactionID(),
                refundMetadata,
                500L,
                "REFUND_TXN_001"
            );
            System.out.println("✓ Refund processed. Transaction ID: " + refund.getTransactionID());
            System.out.println("  Refund amount: ₹500");
            System.out.println("  Alice's balance after refund: ₹" + walletService.getBalanceForWallet(wallet1.getWalletId()) + "\n");

            // Test Case 9: Partial Refund
            System.out.println("Test 9: Partial Refund (Second refund on same transaction)");
            ExternalTransferMetaData refundMetadata2 = new ExternalTransferMetaData();
            refundMetadata2.setSourceAccount(refundSource);
            refundMetadata2.setDestinationAccount(refundDest);

            Transaction partialRefund = transactionService.initiateRefund(
                externalTxn.getTransactionID(),
                refundMetadata2,
                300L,
                "REFUND_TXN_002"
            );
            System.out.println("✓ Partial refund processed. Transaction ID: " + partialRefund.getTransactionID());
            System.out.println("  Total refunded so far: ₹800 (₹500 + ₹300)");
            System.out.println("  Alice's balance: ₹" + walletService.getBalanceForWallet(wallet1.getWalletId()) + "\n");

            // Test Case 10: Get Transaction History
            System.out.println("Test 10: Transaction History for Alice");
            List<Transaction> aliceTransactions = transactionService.getTransactionsByUserId("user1");
            System.out.println("✓ Total transactions: " + aliceTransactions.size());
            for (int i = 0; i < aliceTransactions.size(); i++) {
                Transaction txn = aliceTransactions.get(i);
                System.out.println("  " + (i + 1) + ". Type: " + txn.getTransactionType() +
                                 ", Amount: ₹" + txn.getAmount() +
                                 ", Status: " + txn.getTransactionStatus());
            }
            System.out.println();

            // Test Case 11: Validation - Negative Amount
            System.out.println("Test 11: Testing Validation (Negative Amount)");
            try {
                walletService.addMoney(wallet1.getWalletId(), -100L);
                System.out.println("✗ Should have thrown exception!");
            } catch (IllegalArgumentException e) {
                System.out.println("✓ Correctly rejected negative amount: " + e.getMessage() + "\n");
            }

            // Test Case 12: Validation - Insufficient Balance
            System.out.println("Test 12: Testing Insufficient Balance");
            try {
                walletService.deductAmountFromWallet(wallet2.getWalletId(), 999999L, OperationType.DEBIT);
                System.out.println("✗ Should have thrown exception!");
            } catch (RuntimeException e) {
                System.out.println("✓ Correctly rejected insufficient balance: " + e.getMessage() + "\n");
            }

            // Test Case 13: Inactive Wallet
            System.out.println("Test 13: Testing Inactive Wallet");
            Wallet wallet3 = new Wallet();
            wallet3.setOwnedByUserId("user3");
            wallet3.setAmount(0L);
            wallet3.setStatus(WalletStatus.INACTIVE);
            wallet3 = walletService.addWallet(wallet3);

            try {
                walletService.addMoney(wallet3.getWalletId(), 100L);
                System.out.println("✗ Should have thrown exception!");
            } catch (RuntimeException e) {
                System.out.println("✓ Correctly rejected inactive wallet: " + e.getMessage() + "\n");
            }

            // Test Case 14: Duplicate Wallet for Same User
            System.out.println("Test 14: Testing Duplicate Wallet Prevention");
            try {
                Wallet duplicateWallet = new Wallet();
                duplicateWallet.setOwnedByUserId("user1");
                duplicateWallet.setAmount(0L);
                duplicateWallet.setStatus(WalletStatus.ACTIVE);
                walletService.addWallet(duplicateWallet);
                System.out.println("✗ Should have thrown exception!");
            } catch (RuntimeException e) {
                System.out.println("✓ Correctly prevented duplicate wallet: " + e.getMessage() + "\n");
            }

            // Final Summary
            System.out.println("=== Final Summary ===");
            System.out.println("Alice's final balance: ₹" + walletService.getBalanceForWallet(wallet1.getWalletId()));
            System.out.println("Bob's final balance: ₹" + walletService.getBalanceForWallet(wallet2.getWalletId()));
            System.out.println("\n✓ All test cases completed successfully!");

        } catch (Exception e) {
            System.err.println("✗ Test failed with error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}