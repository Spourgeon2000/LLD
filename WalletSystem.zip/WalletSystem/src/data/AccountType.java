package data;

public enum AccountType {
    WALLET,
    EXTERNAL
}
