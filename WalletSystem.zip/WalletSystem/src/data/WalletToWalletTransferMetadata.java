package data;

public class WalletToWalletTransferMetadata extends TransferMetaData {

}
