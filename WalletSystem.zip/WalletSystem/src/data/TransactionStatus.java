package data;

public enum TransactionStatus {
    FAILED,
    SUCCESS,
    PENDING
}
