package data;

public enum OperationType {
    CREDIT,
    DEBIT
}
