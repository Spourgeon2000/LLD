package data;

public enum TransactionType {
    REFUND,
    NORMAL
}
