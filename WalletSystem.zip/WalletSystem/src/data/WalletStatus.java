package data;

public enum WalletStatus {
    ACTIVE,
    INACTIVE
}
