package data;

public class Transaction {
    private String transactionID;
    private TransactionType transactionType;
    private TransactionStatus transactionStatus;
    private TransferMetaData metaData;
    private Long amount;

    public String getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(String transactionID) {
        this.transactionID = transactionID;
    }

    public TransferMetaData getMetaData() {
        return metaData;
    }

    public void setMetaData(TransferMetaData metaData) {
        this.metaData = metaData;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    public TransactionStatus getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(TransactionStatus transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }
}
