package data;

public class Wallet {
    private String walletId;
    private String ownedByUserId;
    private Long amount;
    private WalletStatus status;

    public WalletStatus getStatus() {
        return status;
    }

    public void setStatus(WalletStatus status) {
        this.status = status;
    }

    public String getWalletId() {
        return walletId;
    }

    public void setWalletId(String walletId) {
        this.walletId = walletId;
    }

    public String getOwnedByUserId() {
        return ownedByUserId;
    }

    public void setOwnedByUserId(String ownedByUserId) {
        this.ownedByUserId = ownedByUserId;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }
}
