package service;

import data.User;
import repo.UserRepo;

public class UserService {
    public static UserService instance = null;

    public static UserService getInstance() {
        if (instance == null) {
            instance = new UserService();
        }
        return instance;
    }

    UserRepo userRepo = UserRepo.getInstance();

    public User addUser(User user) {
        return userRepo.addUser(user);
    }
}
