package service;

import data.OperationType;
import data.Wallet;
import data.WalletStatus;
import repo.WalletRepo;

import java.util.Objects;

import static data.OperationType.DEBIT;
import static utils.ValidateUtils.validateAmount;

public class WalletService {
    public static WalletService instance = null;

    public static WalletService getInstance() {
        if (instance == null) {
            instance = new WalletService();
        }
        return instance;
    }

    WalletRepo walletRepo = WalletRepo.getInstance();

    public Wallet addWallet(Wallet wallet) {
        String userID = wallet.getOwnedByUserId();
        if (walletRepo.getUserIdToWallet().containsKey(userID)) {
            throw new RuntimeException("Wallet already exists for the user");
        }
        return walletRepo.addWallet(wallet);
    }

    public Long addMoney(String walletId, Long amount) {
        validateAmount(amount);
        Wallet wallet = walletRepo.getWalletById(walletId);
        if (wallet.getStatus() == WalletStatus.INACTIVE) {
            throw new RuntimeException("Wallet is inactive");
        }
        Wallet updatedWallet = walletRepo.updateWalletBalance(walletId, amount + wallet.getAmount());
        return updatedWallet.getAmount();
    }

    public Long getBalanceForWallet(String walletId) {
        Wallet wallet = walletRepo.getWalletById(walletId);
        return wallet.getAmount();
    }

    public Wallet getWalletById(String walletId) {
        return walletRepo.getWalletById(walletId);
    }

    public Long deductAmountFromWallet(String walletId, Long amount, OperationType operationType) {
        validateAmount(amount);
        Wallet wallet = walletRepo.getWalletById(walletId);
        if (wallet.getStatus() == WalletStatus.INACTIVE) {
            throw new RuntimeException("Wallet is inactive");
        }
        Long currentAmount = wallet.getAmount();
        if (Objects.equals(operationType, DEBIT) && currentAmount < amount) {
            throw new RuntimeException("Insufficient balance");
        }
        if (operationType == DEBIT) {
            currentAmount -= amount;
        } else {
            currentAmount += amount;
        }
        walletRepo.updateWalletBalance(wallet.getWalletId(), currentAmount);
        return currentAmount;
    }

    public Wallet getWalletByUserId(String userId) {
        return walletRepo.getWalletByUserId(userId);
    }
}
