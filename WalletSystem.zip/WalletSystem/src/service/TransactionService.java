package service;

import data.Account;
import data.ExternalTransferMetaData;
import data.OperationType;
import data.Transaction;
import data.TransactionStatus;
import data.TransactionType;
import data.TransferMetaData;
import data.Wallet;
import data.WalletStatus;
import repo.TransactionRepo;

import java.util.List;
import java.util.Objects;

import static utils.ValidateUtils.validateAmount;

public class TransactionService {
    public static TransactionService instance = null;

    public static TransactionService getInstance() {
        if (instance == null) {
            instance = new TransactionService();
        }
        return instance;
    }

    TransactionRepo transactionRepo = TransactionRepo.getInstance();
    WalletService walletService = WalletService.getInstance();

    public Transaction transferMoney(TransferMetaData transferMetaData, Long amount, TransactionType transactionType) {
        validateAmount(amount);
        Transaction transaction = new Transaction();
        String destinationWalletId = null;
        String sourceWalletId = transferMetaData.getSourceAccount().getAccountId();
        if (transferMetaData.getDestinationAccount().getAccountType() == data.AccountType.WALLET) {
            destinationWalletId = transferMetaData.getDestinationAccount().getAccountId();
        }
        try {
            Wallet sourceWallet = walletService.getWalletById(sourceWalletId);
            if (destinationWalletId != null) {
                Wallet destinationWallet = walletService.getWalletById(destinationWalletId);
                if (destinationWallet.getStatus() != WalletStatus.ACTIVE) {
                    throw new RuntimeException("Destination wallet is not active");
                }
            }
            walletService.deductAmountFromWallet(sourceWalletId, amount, OperationType.DEBIT);

            try {
                if (destinationWalletId != null) {
                    walletService.deductAmountFromWallet(destinationWalletId, amount, OperationType.CREDIT);
                }
            } catch (Exception e) {
                walletService.deductAmountFromWallet(sourceWalletId, amount, OperationType.CREDIT);
                throw e;
            }

            transaction.setAmount(amount);
            transaction.setTransactionType(transactionType);
            transaction.setTransactionStatus(TransactionStatus.SUCCESS);
            transaction.setMetaData(transferMetaData);
        } catch (Exception e) {
            transaction.setAmount(amount);
            transaction.setTransactionType(transactionType);
            transaction.setMetaData(transferMetaData);
            transaction.setTransactionStatus(TransactionStatus.FAILED);
        }
        return transactionRepo.addTransaction(transaction);
    }

    public Transaction initiateRefund(String originalTransactionId, ExternalTransferMetaData transferMetaData, Long amount,
                                      String externalTransactionId) {
        validateAmount(amount);
        Account sourceAccount = transferMetaData.getSourceAccount();
        Account destinationAccount = transferMetaData.getDestinationAccount();
        if (!Objects.equals(sourceAccount.getAccountType(), data.AccountType.WALLET)) {
            throw new RuntimeException("Refund is only supported from external sources");
        }

        Transaction originalTransaction = transactionRepo.getTransactionByExternalTransactionId(externalTransactionId);
        if (originalTransaction != null) {
            throw new RuntimeException("Transaction already exists for the external transaction id , it is not allowed multiple times for same external transaction id");
        }
        Transaction parentTransaction = transactionRepo.getTransactionByID(originalTransactionId);
        if (parentTransaction == null) {
            throw new RuntimeException("Original transaction not found: " + originalTransactionId);
        }
        Long totalRefunded = transactionRepo.getTotalRefundedAmount(parentTransaction.getTransactionID());
        if (totalRefunded + amount > parentTransaction.getAmount()) {
            throw new RuntimeException("Refund amount exceeds original transaction amount");
        }
        Transaction transaction = new Transaction();
        transaction.setAmount(amount);
        transaction.setTransactionType(TransactionType.REFUND);
        transaction.setMetaData(transferMetaData);
        transferMetaData.setParentTransactionId(originalTransactionId);
        transaction.setTransactionStatus(TransactionStatus.SUCCESS);
        walletService.deductAmountFromWallet(destinationAccount.getAccountId(), amount, OperationType.CREDIT);
        return transactionRepo.addTransaction(transaction);
    }

    public Transaction externalCallBack(ExternalTransferMetaData transferMetaData, Long amount,
                                        String externalTransactionId) {
        Account sourceAccount = transferMetaData.getSourceAccount();
        validateAmount(amount);
        if (!Objects.equals(sourceAccount.getAccountType(), data.AccountType.WALLET)) {
            throw new RuntimeException("Refund is only supported from external sources");
        }
        Transaction existingTransaction = transactionRepo.getTransactionByExternalTransactionId(externalTransactionId);
        if (existingTransaction != null) {
            return existingTransaction;
        }

        Transaction transaction = new Transaction();
        transaction.setAmount(amount);
        transaction.setTransactionType(TransactionType.NORMAL);
        transferMetaData.setExternalTransactionId(externalTransactionId);
        String walletId = transferMetaData.getDestinationAccount().getAccountId();
        walletService.deductAmountFromWallet(walletId, amount, OperationType.CREDIT);
        transaction.setMetaData(transferMetaData);
        transaction.setTransactionStatus(TransactionStatus.SUCCESS);
        return transactionRepo.addTransaction(transaction);
    }

    public List<Transaction> getTransactionsByUserId(String userId) {
        Wallet wallet = walletService.getWalletByUserId(userId);
        return transactionRepo.getTransactionsByWalletId(wallet.getWalletId());
    }

    public List<Transaction> getTransactionsByWalletId(String walletId) {
        return transactionRepo.getTransactionsByWalletId(walletId);
    }


}

