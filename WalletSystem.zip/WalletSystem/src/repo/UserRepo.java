package repo;

import data.User;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class UserRepo {
    public static UserRepo instance = null;
    private UserRepo(){

    }
    public static UserRepo getInstance() {
        if (instance == null) {
            instance = new UserRepo();
        }
        return instance;
    }

    Map<String, User> userMap = new HashMap<>();

    public User addUser(User user) {
        if (user.getUsrId() == null) {
            user.setUsrId(UUID.randomUUID().toString());
        }
        userMap.put(user.getUsrId(), user);
        return user;
    }
}
