package repo;

import data.ExternalTransferMetaData;
import data.Transaction;
import data.TransactionStatus;
import data.TransactionType;
import data.TransferMetaData;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class TransactionRepo {
    public static TransactionRepo instance = null;

    public static TransactionRepo getInstance() {
        if (instance == null) {
            instance = new TransactionRepo();
        }
        return instance;
    }


    Map<String, Transaction> transactionMap = new HashMap<>();

    public Transaction addTransaction(Transaction transaction) {
        if (transaction.getTransactionID() == null) {
            transaction.setTransactionID(UUID.randomUUID().toString());
        }
        transactionMap.put(transaction.getTransactionID(), transaction);
        return transaction;
    }

    public List<Transaction> getTransactionsByWalletId(String walletId) {
        return transactionMap.values().stream().filter(transaction -> {
            TransferMetaData transferMetaData = transaction.getMetaData();
            return (transferMetaData.getSourceAccount().getAccountId().equals(walletId) && transferMetaData.getSourceAccount().getAccountType() == data.AccountType.WALLET)
                    || (transferMetaData.getDestinationAccount().getAccountId().equals(walletId) && transferMetaData.getDestinationAccount().getAccountType() == data.AccountType.WALLET);
        }).toList();
    }

    public Transaction getTransactionByID(String transactionID) {
        return transactionMap.get(transactionID);
    }

    public Transaction getTransactionByExternalTransactionId(String externalTransactionId) {
        for (Transaction transaction : transactionMap.values()) {
            if (transaction.getMetaData() instanceof ExternalTransferMetaData meta) {
                if (meta.getExternalTransactionId() != null &&
                        meta.getExternalTransactionId().equals(externalTransactionId)) {
                    return transaction;
                }
            }
        }
        return null;
    }

    public Long getTotalRefundedAmount(String parentTransactionId) {
        return transactionMap.values().stream()
                .filter(txn -> txn.getTransactionType() == TransactionType.REFUND)
                .filter(txn -> txn.getMetaData() instanceof ExternalTransferMetaData)
                .filter(txn -> {
                    ExternalTransferMetaData meta = (ExternalTransferMetaData) txn.getMetaData();
                    return parentTransactionId.equals(meta.getParentTransactionId());
                })
                .filter(txn -> txn.getTransactionStatus() == TransactionStatus.SUCCESS)
                .mapToLong(Transaction::getAmount)
                .sum();
    }
}
