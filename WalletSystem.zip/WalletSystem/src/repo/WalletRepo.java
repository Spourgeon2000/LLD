package repo;

import data.Wallet;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class WalletRepo {
    public static WalletRepo instance = null;

    public static void setInstance(WalletRepo instance) {
        WalletRepo.instance = instance;
    }

    public Map<String, Wallet> getWalletMap() {
        return walletMap;
    }

    public void setWalletMap(Map<String, Wallet> walletMap) {
        this.walletMap = walletMap;
    }

    public Map<String, Wallet> getUserIdToWallet() {
        return userIdToWallet;
    }

    public void setUserIdToWallet(Map<String, Wallet> userIdToWallet) {
        this.userIdToWallet = userIdToWallet;
    }

    public static WalletRepo getInstance() {
        if (instance == null) {
            instance = new WalletRepo();
        }
        return instance;
    }

    Map<String, Wallet> walletMap = new HashMap<>();
    Map<String, Wallet> userIdToWallet = new HashMap<>();

    public Wallet addWallet(Wallet wallet) {
        if (wallet.getWalletId() == null) {
            wallet.setWalletId(UUID.randomUUID().toString());
        }
        userIdToWallet.put(wallet.getOwnedByUserId(), wallet);
        walletMap.put(wallet.getWalletId(), wallet);
        return wallet;
    }

    public Wallet updateWalletBalance(String walletId, Long amount) {
        Wallet wallet = walletMap.get(walletId);
        wallet.setAmount(amount);
        walletMap.put(walletId, wallet);
        return wallet;
    }

    public Wallet getWalletById(String walletId) {
        if (walletMap.get(walletId) == null) {
            throw new RuntimeException("Wallet not found");
        }
        return walletMap.get(walletId);
    }

    public Wallet getWalletByUserId(String userId) {
        Wallet wallet = userIdToWallet.get(userId);
        if (wallet == null) {
            throw new RuntimeException("There is no wallet for the user");
        }
        return wallet;
    }
}
