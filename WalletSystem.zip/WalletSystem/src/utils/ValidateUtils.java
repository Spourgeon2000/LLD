package utils;

public class ValidateUtils {
    public static void validateAmount(Long amount){
        if (amount == null) {
            throw new IllegalArgumentException("Amount cannot be null");
        }
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be greater than 0");
        }
    }
}
