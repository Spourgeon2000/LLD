package factory;

import data.ElevatorPickRequestType;
import strategy.ElevatorPickStrategy;
import strategy.PickIdleElevatorStrategy;
import strategy.PickNearestByDirectionStrategy;
import strategy.PickRandomMovingElevatorStrategy;

public class ElevatorPickStrategyFactory {

    private static ElevatorPickStrategyFactory instance = null;


    public static ElevatorPickStrategyFactory getInstance() {
        if (instance == null) {
            instance = new ElevatorPickStrategyFactory();
        }
        return instance;
    }

    public ElevatorPickStrategy getStrategy(ElevatorPickRequestType requestType) {
        switch (requestType) {
            case PICK_NEAREST_BY_DIRECTION:
                return new PickNearestByDirectionStrategy();

            case PICK_IDLE:
                return new PickIdleElevatorStrategy();

            case PICK_RANDOM_MOVING:
                return new PickRandomMovingElevatorStrategy();

            default:
                throw new IllegalArgumentException("Unknown request type: " + requestType);
        }
    }
}

