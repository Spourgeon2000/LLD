package factory;

import data.FloorSelectionStrategyType;
import strategy.FloorSelectionStrategy;
import strategy.ScanSelectionStrategy;

public class FloorSelectionStrategyFactory {

    private static FloorSelectionStrategyFactory instance = null;

    public static FloorSelectionStrategyFactory getInstance() {
        if (instance == null) {
            instance = new FloorSelectionStrategyFactory();
        }
        return instance;
    }

    public FloorSelectionStrategy getStrategy(FloorSelectionStrategyType strategyType) {
        switch (strategyType) {
            case SCAN:
                return new ScanSelectionStrategy();
            default:
                throw new IllegalArgumentException("Unknown strategy type: " + strategyType);
        }
    }
}

