package strategy;

import data.ElevatorCar;
import data.ElevatorPickRequest;

import java.util.List;

public interface ElevatorPickStrategy {
    ElevatorCar pickElevator(ElevatorPickRequest elevatorPickRequest);
}
