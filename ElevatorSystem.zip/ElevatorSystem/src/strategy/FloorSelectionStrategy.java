package strategy;

import data.ElevatorCar;
import data.Request;

import java.util.List;

public interface FloorSelectionStrategy {
     public Integer getNextFloorNumber(List<Request> requests, ElevatorCar elevatorCar);
}
