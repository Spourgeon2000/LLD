package strategy;

import data.ElevatorCar;
import data.ElevatorPickRequest;
import service.ElevatorService;

import java.util.List;

public class PickIdleElevatorStrategy implements ElevatorPickStrategy {
    ElevatorService elevatorService = ElevatorService.getInstance();

    public ElevatorCar pickElevator(ElevatorPickRequest elevatorPickRequest) {
        if (elevatorPickRequest == null) {
            throw new IllegalArgumentException("ElevatorPickRequest cannot be null");
        }

        List<ElevatorCar> elevators = elevatorService.getAllElevators();

        if (elevators == null || elevators.isEmpty()) {
            throw new IllegalStateException("No elevators available in the system");
        }

        ElevatorCar elevator = null;
        for (ElevatorCar elevatorCar : elevators) {
            if (elevatorCar == null) {
                continue;
            }

            if (elevatorCar.getElevatorStatus() == data.ElevatorStatus.IDLE) {
                elevator = elevatorCar;
                break;
            }
        }
        return elevator;
    }
}
