package strategy;

import data.Direction;
import data.ElevatorCar;
import data.InsideRequest;
import data.NextFloorChoice;
import data.OutsideRequest;
import data.Request;
import data.RequestType;

import java.util.List;
import java.util.Objects;

import static data.Direction.UP;

public class ScanSelectionStrategy implements FloorSelectionStrategy {

    public Integer getNextFloorNumber(List<Request> requests, ElevatorCar elevatorCar) {
        if (elevatorCar == null) {
            throw new IllegalArgumentException("ElevatorCar cannot be null");
        }
        if (elevatorCar.getDirection() == null) {
            throw new IllegalStateException("Elevator direction is not set");
        }
        if (elevatorCar.getCurrentFloorNumber() == null) {
            throw new IllegalStateException("Elevator current floor is not set");
        }
        if (elevatorCar.getMaxFloorNumber() == null) {
            throw new IllegalStateException("Elevator max floor is not set");
        }
        if (elevatorCar.getMinFloorNumber() == null) {
            throw new IllegalStateException("Elevator min floor is not set");
        }
        if (requests == null) {
            throw new IllegalArgumentException("Requests list cannot be null");
        }

        Direction currentDirection = elevatorCar.getDirection();
        Integer currentFloorNumber = elevatorCar.getCurrentFloorNumber();
        NextFloorChoice outsideNextFloorChoice = new NextFloorChoice();
        NextFloorChoice insideNextFloorChoice = new NextFloorChoice();

        for (Request request : requests) {
            if (request == null || !request.isValid()) {
                continue;
            }

            if (request.getRequestType() == RequestType.OUTSIDE) {
                OutsideRequest outsideRequest = (OutsideRequest) request;
                Direction direction = outsideRequest.getDirection();
                if (Objects.equals(direction, currentDirection)) {
                    outsideNextFloorChoice = getNextFloorChoiceForOutsideRequest(currentFloorNumber, outsideRequest, direction, elevatorCar);
                }
            } else if (request.getRequestType() == RequestType.INSIDE) {
                InsideRequest insideRequest = (InsideRequest) request;
                insideNextFloorChoice = getNextFloorChoiceForOutsideRequest(currentFloorNumber, insideRequest, currentDirection, elevatorCar);
            }
        }

        if (currentDirection == UP) {
            Integer nextFloorNumber = elevatorCar.getMaxFloorNumber() + 1;
            nextFloorNumber = Math.min(Math.min(nextFloorNumber, outsideNextFloorChoice.getUpFloor()), insideNextFloorChoice.getUpFloor());
            if (nextFloorNumber != elevatorCar.getMaxFloorNumber() + 1) {
                return nextFloorNumber;
            } else {
                return Math.max(outsideNextFloorChoice.getDownFloor(), insideNextFloorChoice.getDownFloor());
            }
        } else {
            Integer nextDownFloor = elevatorCar.getMinFloorNumber() - 1;
            nextDownFloor = Math.max(Math.max(nextDownFloor, outsideNextFloorChoice.getDownFloor()), insideNextFloorChoice.getDownFloor());
            if (nextDownFloor != elevatorCar.getMinFloorNumber() - 1) {
                return nextDownFloor;
            } else {
                return Math.min(outsideNextFloorChoice.getUpFloor(), insideNextFloorChoice.getUpFloor());
            }
        }
    }


    NextFloorChoice getNextFloorChoiceForOutsideRequest(Integer currentFloorNumber, Request request, Direction direction,
                                                        ElevatorCar elevatorCar) {
        if (currentFloorNumber == null) {
            throw new IllegalArgumentException("Current floor number cannot be null");
        }
        if (request == null) {
            throw new IllegalArgumentException("Request cannot be null");
        }
        if (request.getFloorNumber() == null) {
            throw new IllegalArgumentException("Request floor number cannot be null");
        }
        if (direction == null) {
            throw new IllegalArgumentException("Direction cannot be null");
        }
        if (elevatorCar == null) {
            throw new IllegalArgumentException("ElevatorCar cannot be null");
        }

        NextFloorChoice nextFloorChoice = new NextFloorChoice();
        int nextUpFloor = elevatorCar.getMaxFloorNumber() + 1;
        int nextDownFloor = elevatorCar.getMinFloorNumber() - 1;

        if (Objects.equals(direction, UP)) {
            if (currentFloorNumber < request.getFloorNumber()) {
                nextUpFloor = Math.min(nextUpFloor, request.getFloorNumber());
            }
        } else if (Objects.equals(direction, Direction.DOWN)) {
            if (currentFloorNumber > request.getFloorNumber()) {
                nextDownFloor = Math.max(nextDownFloor, request.getFloorNumber());
            }
        }

        nextFloorChoice.setDownFloor(nextDownFloor);
        nextFloorChoice.setUpFloor(nextUpFloor);
        return nextFloorChoice;
    }
}
