package strategy;

import data.Direction;
import data.ElevatorCar;
import data.ElevatorPickRequest;
import data.NearestElevatorPickRequest;
import data.OutsideRequest;
import service.ElevatorService;

import java.util.List;
import java.util.Objects;

import static data.ElevatorStatus.IDLE;
import static data.ElevatorStatus.MOVING;

public class PickNearestByDirectionStrategy implements ElevatorPickStrategy {
    ElevatorService elevatorService = ElevatorService.getInstance();

    public ElevatorCar pickElevator(ElevatorPickRequest elevatorPickRequest) {
        if (elevatorPickRequest == null) {
            throw new IllegalArgumentException("ElevatorPickRequest cannot be null");
        }
        if (!(elevatorPickRequest instanceof NearestElevatorPickRequest)) {
            throw new IllegalArgumentException("Expected NearestElevatorPickRequest but got " + elevatorPickRequest.getClass().getSimpleName());
        }

        NearestElevatorPickRequest nearestElevatorPickRequest = (NearestElevatorPickRequest) elevatorPickRequest;
        OutsideRequest outsideRequest = nearestElevatorPickRequest.getRequest();

        if (outsideRequest == null) {
            throw new IllegalArgumentException("OutsideRequest cannot be null");
        }
        if (outsideRequest.getFloorNumber() == null) {
            throw new IllegalArgumentException("Requested floor number cannot be null");
        }
        if (outsideRequest.getDirection() == null) {
            throw new IllegalArgumentException("Requested direction cannot be null");
        }

        List<ElevatorCar> elevators = elevatorService.getAllElevators();

        if (elevators == null || elevators.isEmpty()) {
            throw new IllegalStateException("No elevators available in the system");
        }

        Integer requestedFloor = outsideRequest.getFloorNumber();
        Direction requestedDirection = outsideRequest.getDirection();
        ElevatorCar nearest = null;
        int minDistance = Integer.MAX_VALUE;

        for (ElevatorCar elevator : elevators) {
            if (elevator == null) {
                continue;
            }

            if (Objects.equals(elevator.getElevatorStatus(), MOVING) &&
                    Objects.equals(requestedDirection, elevator.getDirection())) {
                boolean isApproaching = false;
                if (requestedDirection == Direction.UP) {
                    isApproaching = elevator.getCurrentFloorNumber() <= requestedFloor;
                } else {
                    isApproaching = elevator.getCurrentFloorNumber() >= requestedFloor;
                }
                if (isApproaching) {
                    int distance = Math.abs(requestedFloor - elevator.getCurrentFloorNumber());
                    if (distance < minDistance) {
                        minDistance = distance;
                        nearest = elevator;
                    }
                }
            }
        }

        if (nearest == null) {
            nearest = findNearestIdle(elevators, requestedFloor);
        }

        return nearest;
    }

    private ElevatorCar findNearestIdle(List<ElevatorCar> elevators, Integer requestedFloor) {
        if (elevators == null || elevators.isEmpty()) {
            return null;
        }
        if (requestedFloor == null) {
            throw new IllegalArgumentException("Requested floor cannot be null");
        }

        ElevatorCar nearest = null;
        int minDistance = Integer.MAX_VALUE;

        for (ElevatorCar elevator : elevators) {
            if (elevator == null) {
                continue;
            }

            if (elevator.getElevatorStatus() == IDLE) {
                if (elevator.getCurrentFloorNumber() == null) {
                    continue;
                }

                int distance = Math.abs(requestedFloor - elevator.getCurrentFloorNumber());
                if (distance < minDistance) {
                    minDistance = distance;
                    nearest = elevator;
                }
            }
        }
        return nearest;
    }
}
