import data.Direction;
import data.ElevatorCar;
import data.ElevatorPickRequestType;
import data.ElevatorStatus;
import data.FloorSelectionStrategyType;
import data.InsideRequest;
import data.NearestElevatorPickRequest;
import data.OutsideRequest;
import data.Request;
import data.RequestType;
import repo.ElevatorCarRepo;
import repo.RequestRepo;
import service.ElevatorService;

import java.util.List;

public class Main {

    private static ElevatorService elevatorService;
    private static ElevatorCarRepo elevatorRepo;
    private static RequestRepo requestRepo;

    public static void main(String[] args) {
        // Initialize services
        elevatorService = ElevatorService.getInstance();
        elevatorRepo = ElevatorCarRepo.getInstance();
        requestRepo = RequestRepo.getInstance();

        System.out.println("╔════════════════════════════════════════════════════════╗");
        System.out.println("║        ELEVATOR SYSTEM - COMPREHENSIVE TESTS          ║");
        System.out.println("╚════════════════════════════════════════════════════════╝\n");

        // Run all test scenarios
        testScenario1_BasicOutsideRequest();
        testScenario2_MultipleRequests();
        testScenario3_ScanAlgorithm();
        testScenario4_CapacityValidation();
        testScenario5_NearestElevatorSelection();

        System.out.println("\n╔════════════════════════════════════════════════════════╗");
        System.out.println("║              ALL TESTS COMPLETED ✅                    ║");
        System.out.println("╚════════════════════════════════════════════════════════╝");
    }

    // ========== TEST SCENARIO 1: Basic Outside Request ==========
    private static void testScenario1_BasicOutsideRequest() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("TEST 1: Basic Outside Request (User presses UP on floor 5)");
        System.out.println("=".repeat(60));

        // Setup: Initialize 3 elevators
        clearData();
        String elevator1Id = initializeElevator(0, ElevatorStatus.IDLE, Direction.UP, 0);
        String elevator2Id = initializeElevator(3, ElevatorStatus.MOVING, Direction.UP, 2);
        String elevator3Id = initializeElevator(7, ElevatorStatus.MOVING, Direction.DOWN, 5);

        displayAllElevators();

        // Test: User on floor 5 presses UP button
        System.out.println("\n👤 User on floor 5 presses UP button...");
        OutsideRequest request = createOutsideRequest(5, Direction.UP);

        // Assign elevator using nearest strategy
        NearestElevatorPickRequest pickRequest = new NearestElevatorPickRequest();
        pickRequest.setRequest(request);
        pickRequest.setElevatorPickRequestType(ElevatorPickRequestType.PICK_NEAREST_BY_DIRECTION);

        ElevatorCar assigned = elevatorService.getElevatorForRequest(request, pickRequest);

        // Verify
        if (assigned != null) {
            request.setElevatorId(assigned.getElevatorCarId());
            requestRepo.addRequest(request);

            System.out.println("✅ PASS: Elevator " + assigned.getElevatorCarId() + " assigned");
            System.out.println("   Expected: Elevator at floor 3 moving UP (nearest in direction)");
            System.out.println("   Actual: " + assigned.getElevatorCarId() +
                    " at floor " + assigned.getCurrentFloorNumber() +
                    " moving " + assigned.getDirection());
        } else {
            System.out.println("❌ FAIL: No elevator assigned");
        }
    }

    // ========== TEST SCENARIO 2: Multiple Requests ==========
    private static void testScenario2_MultipleRequests() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("TEST 2: Multiple Requests (Inside + Outside)");
        System.out.println("=".repeat(60));

        // Setup
        clearData();
        String elevatorId = initializeElevator(2, ElevatorStatus.MOVING, Direction.UP, 3);

        displayAllElevators();

        // Add multiple requests to same elevator
        System.out.println("\n📝 Adding multiple requests to elevator " + elevatorId + ":");

        // Inside request: User wants floor 5
        InsideRequest inside1 = createInsideRequest(5, elevatorId);
        requestRepo.addRequest(inside1);
        System.out.println("  - Inside request: Floor 5");

        // Inside request: User wants floor 7
        InsideRequest inside2 = createInsideRequest(7, elevatorId);
        requestRepo.addRequest(inside2);
        System.out.println("  - Inside request: Floor 7");

        // Outside request: Floor 6 going UP
        OutsideRequest outside1 = createOutsideRequest(6, Direction.UP);
        outside1.setElevatorId(elevatorId);
        requestRepo.addRequest(outside1);
        System.out.println("  - Outside request: Floor 6 UP");

        // Test SCAN algorithm
        System.out.println("\n🔍 Testing SCAN algorithm:");
        ElevatorCar elevator = elevatorRepo.getElevatorCar(elevatorId);
        Integer nextFloor = elevatorService.getFloorToMoveForElevator(elevator, FloorSelectionStrategyType.SCAN);

        System.out.println("✅ PASS: SCAN returns next floor: " + nextFloor);
        System.out.println("   Expected: 5 (nearest floor in UP direction)");
        System.out.println("   Actual: " + nextFloor);

        // Display all requests
        displayRequestsForElevator(elevatorId);
    }

    // ========== TEST SCENARIO 3: SCAN Algorithm Behavior ==========
    private static void testScenario3_ScanAlgorithm() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("TEST 3: SCAN Algorithm (Continues in direction)");
        System.out.println("=".repeat(60));

        // Setup: Elevator at floor 5, moving UP
        clearData();
        String elevatorId = initializeElevator(5, ElevatorStatus.MOVING, Direction.UP, 2);

        // Add requests above and below current floor
        InsideRequest req1 = createInsideRequest(3, elevatorId); // Below
        InsideRequest req2 = createInsideRequest(7, elevatorId); // Above
        InsideRequest req3 = createInsideRequest(8, elevatorId); // Above
        InsideRequest req4 = createInsideRequest(2, elevatorId); // Below

        requestRepo.addRequest(req1);
        requestRepo.addRequest(req2);
        requestRepo.addRequest(req3);
        requestRepo.addRequest(req4);

        System.out.println("📍 Elevator at floor 5, moving UP");
        System.out.println("📝 Requests: Floor 3, 7, 8, 2");

        ElevatorCar elevator = elevatorRepo.getElevatorCar(elevatorId);
        Integer nextFloor = elevatorService.getFloorToMoveForElevator(elevator, FloorSelectionStrategyType.SCAN);

        System.out.println("\n✅ PASS: SCAN continues UP first");
        System.out.println("   Expected: 7 (next floor in UP direction)");
        System.out.println("   Actual: " + nextFloor);
        System.out.println("   Note: Will serve 7, 8, then reverse to serve 3, 2");
    }

    // ========== TEST SCENARIO 4: Capacity Validation ==========
    private static void testScenario4_CapacityValidation() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("TEST 4: Capacity Validation (Elevator Full)");
        System.out.println("=".repeat(60));

        // Setup: Elevator at max capacity
        clearData();
        ElevatorCar elevator = new ElevatorCar();
        elevator.setCurrentFloorNumber(3);
        elevator.setElevatorStatus(ElevatorStatus.IDLE);
        elevator.setDirection(Direction.UP);
        elevator.setCapacity(10); // FULL
        elevator.setMaxCapacity(10);
        elevator.setMinFloorNumber(0);
        elevator.setMaxFloorNumber(9);
        elevatorRepo.addElevatorCar(elevator);

        System.out.println("📍 Elevator capacity: " + elevator.getCapacity() + "/" + elevator.getMaxCapacity());

        // Try to board user
        System.out.println("\n👤 Attempting to board user...");

        try {
            service.UserService.getInstance().onBoardUser(elevator.getElevatorCarId(), "user-123");
            System.out.println("❌ FAIL: Should have thrown exception");
        } catch (RuntimeException e) {
            System.out.println("✅ PASS: Exception thrown: " + e.getMessage());
            System.out.println("   Expected: 'Elevator is full'");
            System.out.println("   Actual: '" + e.getMessage() + "'");
        }
    }

    // ========== TEST SCENARIO 5: Nearest Elevator Selection ==========
    private static void testScenario5_NearestElevatorSelection() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("TEST 5: Nearest Elevator Selection Strategy");
        System.out.println("=".repeat(60));

        // Setup: 3 elevators at different positions
        clearData();
        String e1 = initializeElevator(0, ElevatorStatus.IDLE, Direction.UP, 0);
        String e2 = initializeElevator(4, ElevatorStatus.MOVING, Direction.UP, 2);
        String e3 = initializeElevator(8, ElevatorStatus.MOVING, Direction.DOWN, 3);

        displayAllElevators();

        // Test Case A: Request from floor 6, going UP
        System.out.println("\n📍 Test Case A: Floor 6, going UP");
        OutsideRequest requestA = createOutsideRequest(6, Direction.UP);
        NearestElevatorPickRequest pickA = new NearestElevatorPickRequest();
        pickA.setRequest(requestA);
        pickA.setElevatorPickRequestType(ElevatorPickRequestType.PICK_NEAREST_BY_DIRECTION);

        ElevatorCar assignedA = elevatorService.getElevatorForRequest(requestA, pickA);
        System.out.println("   Expected: Elevator at floor 4 moving UP (nearest in direction)");
        System.out.println("   Actual: Elevator at floor " + assignedA.getCurrentFloorNumber() +
                " moving " + assignedA.getDirection());

        if (assignedA.getCurrentFloorNumber() == 4 && assignedA.getDirection() == Direction.UP) {
            System.out.println("   ✅ PASS");
        } else {
            System.out.println("   ❌ FAIL");
        }

        // Test Case B: Request from floor 2, going DOWN
        System.out.println("\n📍 Test Case B: Floor 2, going DOWN");
        OutsideRequest requestB = createOutsideRequest(2, Direction.DOWN);
        NearestElevatorPickRequest pickB = new NearestElevatorPickRequest();
        pickB.setRequest(requestB);
        pickB.setElevatorPickRequestType(ElevatorPickRequestType.PICK_NEAREST_BY_DIRECTION);

        ElevatorCar assignedB = elevatorService.getElevatorForRequest(requestB, pickB);

        if (assignedB != null) {
            System.out.println("   Expected: Nearest IDLE elevator (no elevator moving DOWN towards floor 2)");
            System.out.println("   Actual: Elevator at floor " + assignedB.getCurrentFloorNumber() +
                    " status " + assignedB.getElevatorStatus());

            if (assignedB.getElevatorStatus() == ElevatorStatus.IDLE) {
                System.out.println("   ✅ PASS (Fallback to IDLE)");
            } else {
                System.out.println("   ❌ FAIL");
            }
        } else {
            System.out.println("   ⚠️  No elevator available (all busy in opposite direction)");
        }
    }

    // ========== HELPER METHODS ==========

    private static void clearData() {
        elevatorRepo.setElevatorCarMap(new java.util.HashMap<>());
        // Note: RequestRepo doesn't have a clear method, would need to add one
    }

    private static String initializeElevator(int floor, ElevatorStatus status, Direction direction, int capacity) {
        ElevatorCar elevator = new ElevatorCar();
        elevator.setCurrentFloorNumber(floor);
        elevator.setElevatorStatus(status);
        elevator.setDirection(direction);
        elevator.setCapacity(capacity);
        elevator.setMaxCapacity(10);
        elevator.setMinFloorNumber(0);
        elevator.setMaxFloorNumber(9);
        elevatorRepo.addElevatorCar(elevator);
        return elevator.getElevatorCarId();
    }

    private static OutsideRequest createOutsideRequest(int floor, Direction direction) {
        OutsideRequest request = new OutsideRequest();
        request.setFloorNumber(floor);
        request.setDirection(direction);
        request.setRequestType(RequestType.OUTSIDE);
        request.setValid(true);
        return request;
    }

    private static InsideRequest createInsideRequest(int floor, String elevatorId) {
        InsideRequest request = new InsideRequest();
        request.setFloorNumber(floor);
        request.setRequestType(RequestType.INSIDE);
        request.setElevatorId(elevatorId);
        request.setValid(true);
        return request;
    }

    private static void displayAllElevators() {
        System.out.println("\n📊 Current Elevator States:");
        List<ElevatorCar> elevators = elevatorService.getAllElevators();
        for (ElevatorCar e : elevators) {
            System.out.println("   Elevator " + e.getElevatorCarId().substring(0, 8) + "... | " +
                    "Floor: " + e.getCurrentFloorNumber() + " | " +
                    "Direction: " + e.getDirection() + " | " +
                    "Status: " + e.getElevatorStatus() + " | " +
                    "Capacity: " + e.getCapacity() + "/" + e.getMaxCapacity());
        }
    }

    private static void displayRequestsForElevator(String elevatorId) {
        System.out.println("\n📋 Requests for elevator " + elevatorId + ":");
        List<Request> requests = requestRepo.fetchRequestsByElevatorId(elevatorId);
        for (Request r : requests) {
            System.out.println("   - Floor " + r.getFloorNumber() +
                    " | Type: " + r.getRequestType() +
                    " | Valid: " + r.isValid());
        }
    }
}