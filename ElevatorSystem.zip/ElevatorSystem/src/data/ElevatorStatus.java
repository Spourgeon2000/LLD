package data;

public enum ElevatorStatus {
    MOVING,
    IDLE,
    NOT_WORKING
}
