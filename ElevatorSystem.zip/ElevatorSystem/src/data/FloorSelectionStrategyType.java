package data;

public enum FloorSelectionStrategyType {
    SCAN
}

