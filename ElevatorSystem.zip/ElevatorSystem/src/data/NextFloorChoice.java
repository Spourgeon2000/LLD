package data;

public class NextFloorChoice {
    public Integer upFloor;

    public Integer getDownFloor() {
        return downFloor;
    }

    public void setDownFloor(Integer downFloor) {
        this.downFloor = downFloor;
    }

    public Integer getUpFloor() {
        return upFloor;
    }

    public void setUpFloor(Integer upFloor) {
        this.upFloor = upFloor;
    }

    public Integer downFloor;
}
