package data;

public class OutsideRequest extends Request {
    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    Direction direction;
}
