package data;

public enum RequestType {
    OUTSIDE,
    INSIDE
}
