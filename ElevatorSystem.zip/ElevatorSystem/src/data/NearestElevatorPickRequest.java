package data;

public class NearestElevatorPickRequest extends  ElevatorPickRequest {
    OutsideRequest request;

    public OutsideRequest getRequest() {
        return request;
    }

    public void setRequest(OutsideRequest request) {
        this.request = request;
    }
}
