package data;

public abstract class ElevatorPickRequest {
    public ElevatorPickRequestType elevatorPickRequestType;

    public ElevatorPickRequestType getElevatorPickRequestType() {
        return elevatorPickRequestType;
    }

    public void setElevatorPickRequestType(ElevatorPickRequestType elevatorPickRequestType) {
        this.elevatorPickRequestType = elevatorPickRequestType;
    }
}
