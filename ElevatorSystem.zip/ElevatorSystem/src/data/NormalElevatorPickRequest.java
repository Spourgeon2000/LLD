package data;

public class NormalElevatorPickRequest extends ElevatorPickRequest {

}
