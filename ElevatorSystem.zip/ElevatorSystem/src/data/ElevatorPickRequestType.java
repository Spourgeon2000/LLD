package data;

public enum ElevatorPickRequestType {
    PICK_NEAREST_BY_DIRECTION,
    PICK_IDLE,
    PICK_RANDOM_MOVING
}
