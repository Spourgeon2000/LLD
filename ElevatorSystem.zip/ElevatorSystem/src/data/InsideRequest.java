package data;

public class InsideRequest extends Request {

}
