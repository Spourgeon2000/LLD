package data;

public class ElevatorCar {
    public String elevatorCarId;
    public ElevatorStatus elevatorStatus;
    public Integer currentFloorNumber;
    public Integer nextFloorNumber;
    public Direction direction;
    public Integer capacity;
    public Integer maxCapacity;

    public Integer getMaxCapacity() {
        return maxCapacity;
    }

    public void setMaxCapacity(Integer maxCapacity) {
        this.maxCapacity = maxCapacity;
    }

    public Integer maxFloorNumber;
    public Integer minFloorNumber;

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public Integer getMaxFloorNumber() {
        return maxFloorNumber;
    }

    public void setMaxFloorNumber(Integer maxFloorNumber) {
        this.maxFloorNumber = maxFloorNumber;
    }

    public Integer getMinFloorNumber() {
        return minFloorNumber;
    }

    public void setMinFloorNumber(Integer minFloorNumber) {
        this.minFloorNumber = minFloorNumber;
    }

    public String getElevatorCarId() {
        return elevatorCarId;
    }

    public void setElevatorCarId(String elevatorCarId) {
        this.elevatorCarId = elevatorCarId;
    }

    public ElevatorStatus getElevatorStatus() {
        return elevatorStatus;
    }

    public void setElevatorStatus(ElevatorStatus elevatorStatus) {
        this.elevatorStatus = elevatorStatus;
    }

    public Integer getCurrentFloorNumber() {
        return currentFloorNumber;
    }

    public void setCurrentFloorNumber(Integer currentFloorNumber) {
        this.currentFloorNumber = currentFloorNumber;
    }

    public Integer getNextFloorNumber() {
        return nextFloorNumber;
    }

    public void setNextFloorNumber(Integer nextFloorNumber) {
        this.nextFloorNumber = nextFloorNumber;
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public void move(Integer nextFloorNumber) {
        this.nextFloorNumber = nextFloorNumber;
    }
}
