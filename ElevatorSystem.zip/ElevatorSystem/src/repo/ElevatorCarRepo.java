package repo;

import data.ElevatorCar;
import data.ElevatorStatus;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ElevatorCarRepo {

    public static ElevatorCarRepo instance = null;

    public static ElevatorCarRepo getInstance() {
        if (instance == null) {
            instance = new ElevatorCarRepo();
        }
        return instance;
    }

    public Map<String, ElevatorCar> getElevatorCarMap() {
        return elevatorCarMap;
    }

    public void setElevatorCarMap(Map<String, ElevatorCar> elevatorCarMap) {
        this.elevatorCarMap = elevatorCarMap;
    }

    public static void setInstance(ElevatorCarRepo instance) {
        ElevatorCarRepo.instance = instance;
    }

    Map<String, ElevatorCar> elevatorCarMap = new HashMap<>();

    public ElevatorCar getElevatorCar(String id) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("Elevator ID cannot be null or empty");
        }

        ElevatorCar elevator = elevatorCarMap.get(id);
        if (elevator == null) {
            throw new IllegalArgumentException("Elevator not found with ID: " + id);
        }
        return elevator;
    }

    public void addElevatorCar(ElevatorCar elevatorCar) {
        if (elevatorCar == null) {
            throw new IllegalArgumentException("ElevatorCar cannot be null");
        }

        if (elevatorCar.getElevatorCarId() == null) {
            elevatorCar.setElevatorCarId(UUID.randomUUID().toString());
        }

        if (elevatorCarMap.containsKey(elevatorCar.getElevatorCarId())) {
            throw new IllegalStateException("Elevator with ID " + elevatorCar.getElevatorCarId() + " already exists");
        }

        elevatorCarMap.put(elevatorCar.getElevatorCarId(), elevatorCar);
    }

    public void updateCapacity(String elevatorId, Integer capacity) {
        if (elevatorId == null || elevatorId.trim().isEmpty()) {
            throw new IllegalArgumentException("Elevator ID cannot be null or empty");
        }
        if (capacity == null) {
            throw new IllegalArgumentException("Capacity cannot be null");
        }
        if (capacity < 0) {
            throw new IllegalArgumentException("Capacity cannot be negative");
        }

        ElevatorCar elevatorCar = elevatorCarMap.get(elevatorId);
        if (elevatorCar == null) {
            throw new IllegalArgumentException("Elevator not found with ID: " + elevatorId);
        }

        if (capacity > elevatorCar.getMaxCapacity()) {
            throw new IllegalArgumentException("Capacity " + capacity + " exceeds max capacity " + elevatorCar.getMaxCapacity());
        }

        elevatorCar.setCapacity(capacity);
        elevatorCarMap.put(elevatorId, elevatorCar);
    }

    public void updateElevatorCar(ElevatorCar elevatorCar) {
        if (elevatorCar == null) {
            throw new IllegalArgumentException("ElevatorCar cannot be null");
        }
        if (elevatorCar.getElevatorCarId() == null) {
            throw new IllegalArgumentException("ElevatorCar ID cannot be null");
        }

        if (!elevatorCarMap.containsKey(elevatorCar.getElevatorCarId())) {
            throw new IllegalArgumentException("Elevator not found with ID: " + elevatorCar.getElevatorCarId());
        }

        elevatorCarMap.put(elevatorCar.getElevatorCarId(), elevatorCar);
    }

    public void updateElevatorStatus(String elevatorId, ElevatorStatus status) {
        if (elevatorId == null || elevatorId.trim().isEmpty()) {
            throw new IllegalArgumentException("Elevator ID cannot be null or empty");
        }
        if (status == null) {
            throw new IllegalArgumentException("ElevatorStatus cannot be null");
        }

        ElevatorCar elevatorCar = elevatorCarMap.get(elevatorId);
        if (elevatorCar == null) {
            throw new IllegalArgumentException("Elevator not found with ID: " + elevatorId);
        }

        elevatorCar.setElevatorStatus(status);
        elevatorCarMap.put(elevatorId, elevatorCar);
    }
}
