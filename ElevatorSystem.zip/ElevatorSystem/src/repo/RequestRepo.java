package repo;

import data.Request;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class RequestRepo {

    public static RequestRepo instance = null;

    public static RequestRepo getInstance() {
        if (instance == null) {
            instance = new RequestRepo();
        }
        return instance;
    }

    Map<String, Request> requestMap = new HashMap<String, Request>();
    List<Request> pendingRequests = new ArrayList<>();

    public Request addRequest(Request request) {
        if (request == null) {
            throw new IllegalArgumentException("Request cannot be null");
        }

        if (request.getRequestId() == null) {
            request.setRequestId(UUID.randomUUID().toString());
        }

        if (requestMap.containsKey(request.getRequestId())) {
            throw new IllegalStateException("Request with ID " + request.getRequestId() + " already exists");
        }

        requestMap.put(request.getRequestId(), request);
        return request;
    }

    public List<Request> fetchRequestsByElevatorId(String elevatorId) {
        if (elevatorId == null || elevatorId.trim().isEmpty()) {
            throw new IllegalArgumentException("Elevator ID cannot be null or empty");
        }

        List<Request> requests = new ArrayList<Request>();
        for (Request request : requestMap.values()) {
            if (request.getElevatorId() != null && request.getElevatorId().equals(elevatorId)) {
                requests.add(request);
            }
        }
        return requests;
    }

    public Request updateRequestIsValidOrNot(boolean isValid, String requestId) {
        if (requestId == null || requestId.trim().isEmpty()) {
            throw new IllegalArgumentException("Request ID cannot be null or empty");
        }

        Request request = requestMap.get(requestId);
        if (request == null) {
            throw new IllegalArgumentException("Request not found with ID: " + requestId);
        }

        request.setValid(isValid);
        requestMap.put(requestId, request);
        return request;
    }

    public void addPendingRequest(Request request) {
        if (request == null) {
            throw new IllegalArgumentException("Request cannot be null");
        }

        pendingRequests.add(request);
        System.out.println("Request " + request.getRequestId() + " added to pending queue");
    }

    public List<Request> getPendingRequests() {
        return new ArrayList<>(pendingRequests);
    }

    public void removePendingRequest(Request request) {
        if (request == null) {
            throw new IllegalArgumentException("Request cannot be null");
        }

        pendingRequests.remove(request);
    }
}
