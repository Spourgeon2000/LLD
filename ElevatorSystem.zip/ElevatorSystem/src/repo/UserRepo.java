package repo;

import data.User;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class UserRepo {
    public static UserRepo instance = null;

    public static UserRepo getInstance() {
        if (instance == null) {
            instance = new UserRepo();
        }
        return instance;
    }

    Map<String, User> userMap = new HashMap<>();

    public User addUser(User user){
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null");
        }

        if(user.getUserId() == null) {
            user.setUserId(UUID.randomUUID().toString());
        }

        if (userMap.containsKey(user.getUserId())) {
            throw new IllegalStateException("User with ID " + user.getUserId() + " already exists");
        }

        userMap.put(user.getUserId(), user);
        return user;
    }
}
