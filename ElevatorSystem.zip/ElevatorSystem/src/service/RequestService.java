package service;

import data.Request;
import repo.RequestRepo;

import java.util.List;

public class RequestService {
    public static RequestService instance = null;

    public static RequestService getInstance() {
        if (instance == null) {
            instance = new RequestService();
        }
        return instance;
    }

    RequestRepo requestRepo = RequestRepo.getInstance();

    Request addRequest(Request request) {
        if (request == null) {
            throw new IllegalArgumentException("Request cannot be null");
        }
        return requestRepo.addRequest(request);
    }

    List<Request> fetchRequestsByElevatorId(String elevatorId) {
        if (elevatorId == null || elevatorId.trim().isEmpty()) {
            throw new IllegalArgumentException("Elevator ID cannot be null or empty");
        }
        return requestRepo.fetchRequestsByElevatorId(elevatorId);
    }


}
