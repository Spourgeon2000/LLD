package service;

import data.Direction;
import data.ElevatorCar;
import data.ElevatorPickRequest;
import data.ElevatorStatus;
import data.FloorSelectionStrategyType;
import data.Request;
import factory.ElevatorPickStrategyFactory;
import factory.FloorSelectionStrategyFactory;
import repo.ElevatorCarRepo;
import repo.RequestRepo;
import strategy.ElevatorPickStrategy;
import strategy.FloorSelectionStrategy;

import java.util.List;

public class ElevatorService {

    public static ElevatorService instance = null;

    public static ElevatorService getInstance() {
        if (instance == null) {
            instance = new ElevatorService();
        }
        return instance;
    }

    ElevatorPickStrategyFactory elevatorPickStrategyFactory = ElevatorPickStrategyFactory.getInstance();
    FloorSelectionStrategyFactory floorSelectionStrategyFactory = FloorSelectionStrategyFactory.getInstance();

    ElevatorCarRepo elevatorCarRepo = ElevatorCarRepo.getInstance();
    RequestRepo requestRepo = RequestRepo.getInstance();
    UserService userService = UserService.getInstance();

    public List<ElevatorCar> getAllElevators() {
        if (elevatorCarRepo == null) {
            throw new IllegalStateException("ElevatorCarRepo is not initialized");
        }
        return (List<ElevatorCar>) elevatorCarRepo.getElevatorCarMap().values();
    }

    public ElevatorCar getElevatorForRequest(Request request, ElevatorPickRequest elevatorPickRequest) {
        if (request == null) {
            throw new IllegalArgumentException("Request cannot be null");
        }
        if (elevatorPickRequest == null) {
            throw new IllegalArgumentException("ElevatorPickRequest cannot be null");
        }
        if (elevatorPickRequest.getElevatorPickRequestType() == null) {
            throw new IllegalArgumentException("ElevatorPickRequestType cannot be null");
        }

        ElevatorPickStrategy elevatorPickStrategy = elevatorPickStrategyFactory.getStrategy(elevatorPickRequest.getElevatorPickRequestType());
        ElevatorCar elevatorCar = elevatorPickStrategy.pickElevator(elevatorPickRequest);

        if (elevatorCar == null) {
            throw new IllegalStateException("No elevator available for request " + request.getRequestId());
        }

        System.out.println("Elevator " + elevatorCar.getElevatorCarId() + " picked for request " + request.getRequestId());
        return elevatorCar;
    }

    public Integer getFloorToMoveForElevator(ElevatorCar elevatorCar, FloorSelectionStrategyType floorSelectionStrategyType) {
        if (elevatorCar == null) {
            throw new IllegalArgumentException("ElevatorCar cannot be null");
        }
        if (elevatorCar.getElevatorCarId() == null) {
            throw new IllegalArgumentException("ElevatorCar ID cannot be null");
        }
        if (floorSelectionStrategyType == null) {
            throw new IllegalArgumentException("FloorSelectionStrategyType cannot be null");
        }

        FloorSelectionStrategy floorSelectionStrategy = floorSelectionStrategyFactory.getStrategy(floorSelectionStrategyType);
        List<Request> requests = requestRepo.fetchRequestsByElevatorId(elevatorCar.getElevatorCarId());
        return floorSelectionStrategy.getNextFloorNumber(requests, elevatorCar);
    }

    public Integer getNextFloor(Request request, ElevatorPickRequest elevatorPickRequest) {
        if (request == null) {
            throw new IllegalArgumentException("Request cannot be null");
        }
        if (elevatorPickRequest == null) {
            throw new IllegalArgumentException("ElevatorPickRequest cannot be null");
        }

        ElevatorCar elevatorCar = getElevatorForRequest(request, elevatorPickRequest);
        return getFloorToMoveForElevator(elevatorCar, FloorSelectionStrategyType.SCAN);
    }

    public void makeRequestInvalidAfterReachingFloor(String requestId, List<String> userIds) {
        if (requestId == null || requestId.trim().isEmpty()) {
            throw new IllegalArgumentException("Request ID cannot be null or empty");
        }
        if (userIds == null) {
            throw new IllegalArgumentException("User IDs list cannot be null");
        }

        for (String userId : userIds) {
            if (userId == null || userId.trim().isEmpty()) {
                throw new IllegalArgumentException("User ID cannot be null or empty");
            }
            userService.onBoardUser(requestId, userId);
        }
        requestRepo.updateRequestIsValidOrNot(false, requestId);
    }

    public void updateElevatorStatus(ElevatorStatus elevatorStatus, String elevatorId) {
        if (elevatorId == null || elevatorId.trim().isEmpty()) {
            throw new IllegalArgumentException("Elevator ID cannot be null or empty");
        }
        if (elevatorStatus == null) {
            throw new IllegalArgumentException("ElevatorStatus cannot be null");
        }

        elevatorCarRepo.updateElevatorStatus(elevatorId, elevatorStatus);
    }

    public void displayElevatorState(ElevatorCar elevator) {
        if (elevator == null) {
            throw new IllegalArgumentException("Elevator cannot be null");
        }

        System.out.println("===================");
        System.out.println("Elevator ID: " + elevator.getElevatorCarId());
        System.out.println("Current Floor: " + elevator.getCurrentFloorNumber());
        System.out.println("Direction: " + elevator.getDirection());
        System.out.println("Status: " + elevator.getElevatorStatus());
        System.out.println("Capacity: " + elevator.getCapacity() + "/" + elevator.getMaxCapacity());
        System.out.println("===================");
    }

    public void displayAllElevators() {
        System.out.println("\n========== ALL ELEVATORS ==========");
        List<ElevatorCar> elevators = getAllElevators();

        if (elevators == null || elevators.isEmpty()) {
            System.out.println("No elevators available in the system");
            System.out.println("===================================\n");
            return;
        }

        for (ElevatorCar elevator : elevators) {
            if (elevator == null) {
                continue;
            }
            System.out.println("Elevator " + elevator.getElevatorCarId() +
                    " | Floor: " + elevator.getCurrentFloorNumber() +
                    " | Direction: " + elevator.getDirection() +
                    " | Status: " + elevator.getElevatorStatus() +
                    " | Capacity: " + elevator.getCapacity() + "/" + elevator.getMaxCapacity());
        }
        System.out.println("===================================\n");
    }

    // Admin: Add new elevator
    public String addElevator() {
        ElevatorCar newElevator = new ElevatorCar();
        newElevator.setCurrentFloorNumber(0); // Ground floor
        newElevator.setElevatorStatus(ElevatorStatus.IDLE);
        newElevator.setDirection(Direction.UP);
        newElevator.setCapacity(0);
        newElevator.setMaxCapacity(10);
        newElevator.setMinFloorNumber(0);
        newElevator.setMaxFloorNumber(9);

        elevatorCarRepo.addElevatorCar(newElevator);
        System.out.println("✅ New elevator added: " + newElevator.getElevatorCarId());
        return newElevator.getElevatorCarId();
    }

    // Admin: Remove elevator (mark as NOT_WORKING)
    public void removeElevator(String elevatorId) {
        if (elevatorId == null || elevatorId.trim().isEmpty()) {
            throw new IllegalArgumentException("Elevator ID cannot be null or empty");
        }

        ElevatorCar elevator = elevatorCarRepo.getElevatorCar(elevatorId);

        if (elevator == null) {
            throw new IllegalArgumentException("Elevator not found with ID: " + elevatorId);
        }

        // Mark as not working (will complete current requests)
        elevator.setElevatorStatus(ElevatorStatus.NOT_WORKING);
        elevatorCarRepo.updateElevatorCar(elevator);

        System.out.println("⚠️ Elevator " + elevatorId + " marked for removal (completing current requests)");
    }

    // Admin: Disable elevator for maintenance
    public void disableElevator(String elevatorId) {
        if (elevatorId == null || elevatorId.trim().isEmpty()) {
            throw new IllegalArgumentException("Elevator ID cannot be null or empty");
        }
        removeElevator(elevatorId); // Same as remove
    }

    // Admin: Re-enable elevator
    public void enableElevator(String elevatorId) {
        if (elevatorId == null || elevatorId.trim().isEmpty()) {
            throw new IllegalArgumentException("Elevator ID cannot be null or empty");
        }

        ElevatorCar elevator = elevatorCarRepo.getElevatorCar(elevatorId);

        if (elevator == null) {
            throw new IllegalArgumentException("Elevator not found with ID: " + elevatorId);
        }

        elevator.setElevatorStatus(ElevatorStatus.IDLE);
        elevatorCarRepo.updateElevatorCar(elevator);
        System.out.println("✅ Elevator " + elevatorId + " re-enabled");
    }

}
