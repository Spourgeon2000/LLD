package service;

import data.ElevatorCar;
import repo.ElevatorCarRepo;

import java.util.Objects;

public class UserService {
    public static UserService instance = null;

    public static UserService getInstance() {
        if (instance == null) {
            instance = new UserService();
        }
        return instance;
    }

    ElevatorCarRepo elevatorCarRepo = ElevatorCarRepo.getInstance();

    public void onBoardUser(String elevatorId, String userId) {
        if (elevatorId == null || elevatorId.trim().isEmpty()) {
            throw new IllegalArgumentException("Elevator ID cannot be null or empty");
        }
        if (userId == null || userId.trim().isEmpty()) {
            throw new IllegalArgumentException("User ID cannot be null or empty");
        }

        ElevatorCar elevatorCar = elevatorCarRepo.getElevatorCar(elevatorId);

        if (elevatorCar == null) {
            throw new IllegalArgumentException("Elevator not found with ID: " + elevatorId);
        }
        if (elevatorCar.getCapacity() == null) {
            throw new IllegalStateException("Elevator capacity is not initialized");
        }
        if (elevatorCar.getMaxCapacity() == null) {
            throw new IllegalStateException("Elevator max capacity is not initialized");
        }

        if (Objects.equals(elevatorCar.getCapacity(), elevatorCar.getMaxCapacity())) {
            throw new IllegalStateException("Elevator " + elevatorId + " is full. Cannot board user " + userId);
        }

        elevatorCarRepo.updateCapacity(elevatorId, elevatorCar.getCapacity() + 1);
    }


}
