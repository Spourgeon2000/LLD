package repo;

import data.ConsumerData;

import java.util.*;

/**
 * Repository for managing consumer state storage
 * Follows Repository Pattern - handles CRUD operations for consumers
 */
public class ConsumerRepository {
    private static ConsumerRepository instance = null;

    // Storage: consumerId → ConsumerData
    private Map<String, ConsumerData> consumers;
    
    // Storage: (groupId + topicName) → List of consumer IDs
    private Map<String, List<String>> groupConsumers;
    
    // Storage: consumerId → (partitionId → currentOffset)
    private Map<String, Map<Integer, Long>> consumerOffsets;
    
    // Storage: consumerId → List of assigned partition IDs
    private Map<String, List<Integer>> consumerPartitions;
    
    private ConsumerRepository() {
        this.consumers = new HashMap<>();
        this.groupConsumers = new HashMap<>();
        this.consumerOffsets = new HashMap<>();
        this.consumerPartitions = new HashMap<>();
    }
    
    public static ConsumerRepository getInstance() {
        if (instance == null) {
            instance = new ConsumerRepository();
        }
        return instance;
    }
    
    /**
     * Save or update a consumer
     */
    public void saveConsumer(ConsumerData consumer) {
        consumers.put(consumer.getId(), consumer);
    }

    /**
     * Get consumer by ID
     */
    public ConsumerData getConsumer(String consumerId) {
        return consumers.get(consumerId);
    }
    
    /**
     * Delete consumer
     */
    public void deleteConsumer(String consumerId) {
        consumers.remove(consumerId);
        consumerOffsets.remove(consumerId);
        consumerPartitions.remove(consumerId);
    }
    
    /**
     * Add consumer to a group
     */
    public void addConsumerToGroup(String groupId, String topicName, String consumerId) {
        String key = groupId + "-" + topicName;
        groupConsumers.putIfAbsent(key, new ArrayList<>());
        if (!groupConsumers.get(key).contains(consumerId)) {
            groupConsumers.get(key).add(consumerId);
        }
    }
    
    /**
     * Remove consumer from group
     */
    public void removeConsumerFromGroup(String groupId, String topicName, String consumerId) {
        String key = groupId + "-" + topicName;
        if (groupConsumers.containsKey(key)) {
            groupConsumers.get(key).remove(consumerId);
        }
    }
    
    /**
     * Get all consumers in a group
     */
    public List<String> getConsumersInGroup(String groupId, String topicName) {
        String key = groupId + "-" + topicName;
        return new ArrayList<>(groupConsumers.getOrDefault(key, new ArrayList<>()));
    }
    
    /**
     * Save consumer offset for a partition
     */
    public void saveOffset(String consumerId, int partitionId, long offset) {
        consumerOffsets.putIfAbsent(consumerId, new HashMap<>());
        consumerOffsets.get(consumerId).put(partitionId, offset);
    }
    
    /**
     * Get consumer offset for a partition
     */
    public long getOffset(String consumerId, int partitionId) {
        if (!consumerOffsets.containsKey(consumerId)) {
            return 0L;
        }
        return consumerOffsets.get(consumerId).getOrDefault(partitionId, 0L);
    }
    
    /**
     * Get all offsets for a consumer
     */
    public Map<Integer, Long> getAllOffsets(String consumerId) {
        return new HashMap<>(consumerOffsets.getOrDefault(consumerId, new HashMap<>()));
    }
    
    /**
     * Assign partition to consumer
     */
    public void assignPartition(String consumerId, int partitionId) {
        consumerPartitions.putIfAbsent(consumerId, new ArrayList<>());
        if (!consumerPartitions.get(consumerId).contains(partitionId)) {
            consumerPartitions.get(consumerId).add(partitionId);
        }
    }
    
    /**
     * Clear all partitions for a consumer
     */
    public void clearPartitions(String consumerId) {
        consumerPartitions.put(consumerId, new ArrayList<>());
        consumerOffsets.put(consumerId, new HashMap<>());
    }
    
    /**
     * Get assigned partitions for a consumer
     */
    public List<Integer> getAssignedPartitions(String consumerId) {
        return new ArrayList<>(consumerPartitions.getOrDefault(consumerId, new ArrayList<>()));
    }
}

