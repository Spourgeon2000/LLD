package repo;

import data.Message;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MessageDb {
    private static MessageDb instance = null;

    private MessageDb() {
    }

    public static MessageDb getInstance() {
        if (instance == null) {
            instance = new MessageDb();
        }
        return instance;
    }

    Map<String, Message> messages = new HashMap<String, Message>();

    public void addMessage(Message message) {
        if (message.getId() == null) {
            message.setId(java.util.UUID.randomUUID().toString());
        }
        if (messages.containsKey(message.getId())) {
            return;
        }
        messages.put(message.getId(), message);
    }

    public Message getMessageById(String id) {
        if (!messages.containsKey(id)) {
            throw new RuntimeException("Message not found");
        }
        return messages.get(id);
    }

    public List<Message> getMessagesByPartitionAndOffsetRange(int partitionId, long startOffset, int maxMessages) {
        List<Message> result = new ArrayList<>();

        for (Message msg : messages.values()) {
            if (msg.getPartitionId() != null &&
                msg.getPartitionId() == partitionId &&
                msg.getOffset() != null &&
                msg.getOffset() >= startOffset) {
                result.add(msg);
            }
        }

        result.sort(Comparator.comparingLong(Message::getOffset));

        // Limit to maxMessages
        if (result.size() > maxMessages) {
            result = result.subList(0, maxMessages);
        }

        return result;
    }

    public List<Message> getMessagesByPartition(int partitionId) {
        List<Message> result = new ArrayList<>();

        for (Message msg : messages.values()) {
            if (msg.getPartitionId() != null && msg.getPartitionId() == partitionId) {
                result.add(msg);
            }
        }

        result.sort(Comparator.comparingLong(Message::getOffset));

        return result;
    }

    public int getMessageCountByPartition(int partitionId) {
        int count = 0;
        for (Message msg : messages.values()) {
            if (msg.getPartitionId() != null && msg.getPartitionId() == partitionId) {
                count++;
            }
        }
        return count;
    }

}
