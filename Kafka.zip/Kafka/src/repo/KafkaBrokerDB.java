package repo;

import data.KafkaBroker;
import data.Partition;
import data.Topic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

public class KafkaBrokerDB {
    private static KafkaBrokerDB instance = null;

    private KafkaBrokerDB() {
    }

    public static KafkaBrokerDB getInstance() {
        if (instance == null) {
            instance = new KafkaBrokerDB();
        }
        return instance;
    }

    Map<String, KafkaBroker> brokers = new HashMap<>();

    public KafkaBroker addBroker(KafkaBroker broker) {
        if (broker.getId() == null || broker.getId().isEmpty()) {
            broker.setId(UUID.randomUUID().toString());
        }
        if (brokers.containsKey(broker.getId())) {
            throw new RuntimeException("Broker already exists");
        }
        brokers.put(broker.getId(), broker);
        return broker;
    }

    public KafkaBroker getBroker(String id) {
        if (!brokers.containsKey(id)) {
            throw new RuntimeException("Broker not found");
        }
        return brokers.get(id);
    }

    public Topic addTopic(String brokerId, Topic topic) {
        KafkaBroker broker = getBroker(brokerId);
        Map<String, Topic> topics = broker.getTopics();
        if (topics.containsKey(topic.getName())) {
            throw new RuntimeException("Topic already exists");
        }
        topics.put(topic.getName(), topic);
        broker.setTopics(topics);
        brokers.put(broker.getId(), broker);
        return topic;
    }

    public Topic updateTopic(String brokerId, Topic topic) {
        KafkaBroker broker = getBroker(brokerId);
        Map<String, Topic> topics = broker.getTopics();
        if (!topics.containsKey(topic.getName())) {
            throw new RuntimeException("Topic not found");
        }
        topics.put(topic.getName(), topic);
        broker.setTopics(topics);
        brokers.put(broker.getId(), broker);
        return topic;
    }

    public Topic getTopic(String brokerId, String topicName) {
        KafkaBroker broker = getBroker(brokerId);
        Map<String, Topic> topics = broker.getTopics();
        if (!topics.containsKey(topicName)) {
            throw new RuntimeException("Topic not found");
        }
        return topics.get(topicName);
    }

    public Topic addPartition(String brokerId, String topicName, int partitionId) {
        Topic topic = getTopic(brokerId, topicName);
        List<Partition> partitions = topic.getPartitions();
        for (Partition partition : partitions) {
            if (partition.getPartitionId() == partitionId) {
                throw new RuntimeException("Partition already exists");
            }
        }
        partitions.add(new Partition(partitionId));
        return addTopic(brokerId, topic);
    }

    public void updatePartition(String brokerId, String topicName, Partition partition) {
        Topic topic = getTopic(brokerId, topicName);
        List<Partition> partitions = topic.getPartitions();
        for (int i = 0; i < partitions.size(); i++) {
            if (Objects.equals(partitions.get(i).getPartitionId(), partition.getPartitionId())) {
                partitions.set(i, partition);
                return;
            }
        }
        topic.setPartitions(partitions);
        updateTopic(brokerId, topic);
    }

    /**
     * PHASE 6: List all topics in a broker
     */
    public List<String> listTopics(String brokerId) {
        KafkaBroker broker = getBroker(brokerId);
        return new ArrayList<>(broker.getTopics().keySet());
    }

    /**
     * PHASE 6: Delete a topic
     */
    public void deleteTopic(String brokerId, String topicName) {
        KafkaBroker broker = getBroker(brokerId);
        Map<String, Topic> topics = broker.getTopics();
        if (!topics.containsKey(topicName)) {
            throw new RuntimeException("Topic not found: " + topicName);
        }
        topics.remove(topicName);
        broker.setTopics(topics);
        brokers.put(broker.getId(), broker);
    }

    /**
     * PHASE 6: Check if topic exists
     */
    public boolean topicExists(String brokerId, String topicName) {
        try {
            KafkaBroker broker = getBroker(brokerId);
            return broker.getTopics().containsKey(topicName);
        } catch (RuntimeException e) {
            return false;
        }
    }
}
