package strategy;

import data.Partition;
import data.Topic;

public interface IPartitionSelectionStrategy {
    public Partition selectPartition(Topic topic, String key);
}
