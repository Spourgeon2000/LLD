package strategy;

import data.Partition;
import data.Topic;

public class RoundRobinBasedPartitionSelectionStratgy implements IPartitionSelectionStrategy {
    private int roundRobinCounter = 0;

    public Partition selectPartition(Topic topic, String key) {
        int numPartitions = topic.getPartitions().size();
        int partitionId = roundRobinCounter++ % numPartitions;
        return topic.getPartitions().get(partitionId);
    }
}
