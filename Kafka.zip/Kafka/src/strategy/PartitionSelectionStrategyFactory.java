package strategy;

import data.SelectionType;

public class PartitionSelectionStrategyFactory {

    private static PartitionSelectionStrategyFactory instance = null;
    private PartitionSelectionStrategyFactory() {
    }
    public static PartitionSelectionStrategyFactory getInstance() {
        if (instance == null) {
            instance = new PartitionSelectionStrategyFactory();
        }
        return instance;
    }

    public IPartitionSelectionStrategy getStrategy(SelectionType type) {
        switch (type) {
            case KEY_BASED:
                return new KeyBasedPartitionSelectionStrategy();
            case ROUND_ROBIN:
                return new RoundRobinBasedPartitionSelectionStratgy();
            default:
                throw new IllegalArgumentException("Unknown selection type: " + type);
        }
    }
}

