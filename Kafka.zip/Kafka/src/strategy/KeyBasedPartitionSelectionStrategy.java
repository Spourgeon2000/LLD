package strategy;

import data.Partition;
import data.Topic;
import repo.KafkaBrokerDB;

import java.util.List;

public class KeyBasedPartitionSelectionStrategy implements IPartitionSelectionStrategy {

    public Partition selectPartition(Topic topic, String key) {
        List<Partition> partitions = topic.getPartitions();
        int numPartitions = partitions.size();
        return partitions.get(Math.abs(key.hashCode()) % numPartitions);
    }
}
