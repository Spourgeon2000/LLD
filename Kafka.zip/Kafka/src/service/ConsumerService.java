package service;

import data.*;
import repo.ConsumerRepository;
import repo.KafkaBrokerDB;
import repo.MessageDb;

import java.util.*;

/**
 * Service layer for Consumer operations
 * Follows Single Responsibility Principle - handles business logic for consumers
 * Follows Dependency Inversion - depends on abstractions (repositories)
 */
public class ConsumerService {
    private static ConsumerService instance = null;
    
    private final ConsumerRepository consumerRepo;
    private final KafkaBrokerDB brokerDB;
    private final MessageDb messageDB;
    
    private ConsumerService() {
        this.consumerRepo = ConsumerRepository.getInstance();
        this.brokerDB = KafkaBrokerDB.getInstance();
        this.messageDB = MessageDb.getInstance();
    }
    
    public static ConsumerService getInstance() {
        if (instance == null) {
            instance = new ConsumerService();
        }
        return instance;
    }
    
    /**
     * Create a new consumer
     */
    public ConsumerData createConsumer() {
        ConsumerData consumer = new ConsumerData();
        consumerRepo.saveConsumer(consumer);
        return consumer;
    }
    
    /**
     * Subscribe to a topic with manual partition assignment
     */
    public void subscribe(String consumerId, String brokerId, String topicName, List<Integer> partitionIds) {
        // Validate topic exists
        Topic topic = brokerDB.getTopic(brokerId, topicName);
        if (topic == null) {
            throw new RuntimeException("Topic not found: " + topicName);
        }
        
        // Validate partitions exist
        for (Integer partitionId : partitionIds) {
            if (topic.getPartition(partitionId) == null) {
                throw new RuntimeException("Partition " + partitionId + " not found in topic " + topicName);
            }
        }
        
        // Update consumer data
        ConsumerData consumer = consumerRepo.getConsumer(consumerId);
        consumer.setBrokerId(brokerId);
        consumer.setSubscribedTopic(topicName);
        consumerRepo.saveConsumer(consumer);
        
        // Clear existing partitions and assign new ones
        consumerRepo.clearPartitions(consumerId);
        for (Integer partitionId : partitionIds) {
            consumerRepo.assignPartition(consumerId, partitionId);
            consumerRepo.saveOffset(consumerId, partitionId, 0L);
        }
    }
    
    /**
     * Subscribe to a topic with consumer group (automatic partition assignment)
     */
    public void subscribe(String consumerId, String brokerId, String topicName, String groupId) {
        // Validate topic exists
        Topic topic = brokerDB.getTopic(brokerId, topicName);
        if (topic == null) {
            throw new RuntimeException("Topic not found: " + topicName);
        }
        
        // Update consumer data
        ConsumerData consumer = consumerRepo.getConsumer(consumerId);
        consumer.setBrokerId(brokerId);
        consumer.setSubscribedTopic(topicName);
        consumer.setGroupId(groupId);
        consumerRepo.saveConsumer(consumer);
        
        // Get or create consumer group
        ConsumerGroupManager manager = ConsumerGroupManager.getInstance();
        ConsumerGroup group = manager.getOrCreateGroup(brokerId, groupId, topicName);
        
        // Add consumer to group (this will trigger rebalance)
        consumerRepo.addConsumerToGroup(groupId, topicName, consumerId);
        
        // Rebalance will assign partitions
        rebalanceGroup(brokerId, groupId, topicName);
    }
    
    /**
     * Poll messages from assigned partitions
     */
    public List<Message> poll(String consumerId, int maxMessages) {
        ConsumerData consumer = consumerRepo.getConsumer(consumerId);
        if (consumer == null) {
            throw new RuntimeException("Consumer not found: " + consumerId);
        }
        
        if (consumer.getSubscribedTopic() == null) {
            throw new RuntimeException("Consumer not subscribed to any topic");
        }
        
        List<Message> messages = new ArrayList<>();
        List<Integer> assignedPartitions = consumerRepo.getAssignedPartitions(consumerId);
        
        if (assignedPartitions.isEmpty()) {
            return messages; // No partitions assigned
        }
        
        // Round-robin across partitions
        int messagesPerPartition = maxMessages / assignedPartitions.size();
        int remainder = maxMessages % assignedPartitions.size();
        
        for (int i = 0; i < assignedPartitions.size(); i++) {
            Integer partitionId = assignedPartitions.get(i);
            long currentOffset = consumerRepo.getOffset(consumerId, partitionId);
            
            int messagesToFetch = messagesPerPartition + (i < remainder ? 1 : 0);
            
            // Fetch messages from this partition
            List<Message> partitionMessages = messageDB.getMessagesByPartitionAndOffsetRange(
                partitionId,
                currentOffset,
                messagesToFetch
            );
            
            messages.addAll(partitionMessages);
            
            // Update offset
            if (!partitionMessages.isEmpty()) {
                long newOffset = partitionMessages.get(partitionMessages.size() - 1).getOffset() + 1;
                consumerRepo.saveOffset(consumerId, partitionId, newOffset);
            }
        }
        
        return messages;
    }

    /**
     * Commit current offsets to consumer group
     */
    public void commit(String consumerId) {
        ConsumerData consumer = consumerRepo.getConsumer(consumerId);
        if (consumer.getGroupId() == null) {
            return; // Not part of a group, nothing to commit
        }

        // Get consumer group and commit offsets
        ConsumerGroupManager manager = ConsumerGroupManager.getInstance();
        ConsumerGroup group = manager.getGroup(consumer.getGroupId(), consumer.getSubscribedTopic());

        if (group != null) {
            Map<Integer, Long> offsets = consumerRepo.getAllOffsets(consumerId);
            for (Map.Entry<Integer, Long> entry : offsets.entrySet()) {
                group.commit(entry.getKey(), entry.getValue());
            }
        }
    }

    /**
     * Get consumer lag for each assigned partition
     */
    public Map<Integer, Long> getLag(String consumerId) {
        Map<Integer, Long> lag = new HashMap<>();

        ConsumerData consumer = consumerRepo.getConsumer(consumerId);
        if (consumer.getSubscribedTopic() == null) {
            return lag;
        }

        List<Integer> assignedPartitions = consumerRepo.getAssignedPartitions(consumerId);
        Topic topic = brokerDB.getTopic(consumer.getBrokerId(), consumer.getSubscribedTopic());

        for (Integer partitionId : assignedPartitions) {
            Partition partition = topic.getPartition(partitionId);
            long latestOffset = partition.getLatestOffset();

            long committedOffset;
            if (consumer.getGroupId() != null) {
                ConsumerGroupManager manager = ConsumerGroupManager.getInstance();
                ConsumerGroup group = manager.getGroup(consumer.getGroupId(), consumer.getSubscribedTopic());
                committedOffset = group.getCommittedOffset(partitionId);
            } else {
                committedOffset = consumerRepo.getOffset(consumerId, partitionId);
            }

            if (latestOffset == -1) {
                lag.put(partitionId, 0L);
            } else {
                lag.put(partitionId, latestOffset - committedOffset + 1);
            }
        }

        return lag;
    }

    /**
     * Unsubscribe from topic
     */
    public void unsubscribe(String consumerId) {
        ConsumerData consumer = consumerRepo.getConsumer(consumerId);

        if (consumer.getGroupId() != null) {
            consumerRepo.removeConsumerFromGroup(
                consumer.getGroupId(),
                consumer.getSubscribedTopic(),
                consumerId
            );
            rebalanceGroup(consumer.getBrokerId(), consumer.getGroupId(), consumer.getSubscribedTopic());
        }

        consumer.setSubscribedTopic(null);
        consumer.setGroupId(null);
        consumerRepo.saveConsumer(consumer);
        consumerRepo.clearPartitions(consumerId);
    }

    /**
     * Seek to a specific offset in a partition
     */
    public void seek(String consumerId, int partitionId, long offset) {
        List<Integer> assignedPartitions = consumerRepo.getAssignedPartitions(consumerId);

        if (!assignedPartitions.contains(partitionId)) {
            throw new RuntimeException("Partition " + partitionId + " not assigned to this consumer");
        }

        if (offset < 0) {
            throw new RuntimeException("Offset cannot be negative");
        }

        consumerRepo.saveOffset(consumerId, partitionId, offset);
    }

    /**
     * Get assigned partitions for a consumer
     */
    public List<Integer> getAssignedPartitions(String consumerId) {
        return consumerRepo.getAssignedPartitions(consumerId);
    }

    /**
     * Get current offsets for a consumer
     */
    public Map<Integer, Long> getCurrentOffsets(String consumerId) {
        return consumerRepo.getAllOffsets(consumerId);
    }

    /**
     * Rebalance a consumer group
     */
    private void rebalanceGroup(String brokerId, String groupId, String topicName) {
        ConsumerGroupManager manager = ConsumerGroupManager.getInstance();
        ConsumerGroup group = manager.getGroup(groupId, topicName);

        if (group == null) {
            return;
        }

        // Get all consumers in the group
        List<String> consumerIds = consumerRepo.getConsumersInGroup(groupId, topicName);

        // Clear all partition assignments
        for (String consumerId : consumerIds) {
            consumerRepo.clearPartitions(consumerId);
        }

        if (consumerIds.isEmpty()) {
            return;
        }

        // Get topic partitions
        Topic topic = brokerDB.getTopic(brokerId, topicName);
        int numPartitions = topic.getPartitions().size();

        // Round-robin assignment
        for (int partitionId = 0; partitionId < numPartitions; partitionId++) {
            int consumerIndex = partitionId % consumerIds.size();
            String consumerId = consumerIds.get(consumerIndex);

            consumerRepo.assignPartition(consumerId, partitionId);

            // Set offset from committed offset
            long committedOffset = group.getCommittedOffset(partitionId);
            consumerRepo.saveOffset(consumerId, partitionId, committedOffset);
        }
    }
}
