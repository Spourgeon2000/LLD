import data.*;
import repo.KafkaBrokerDB;
import repo.MessageDb;
import service.ConsumerService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== PHASE 1 TESTS: Basic Message Storage ===\n");

        testPartitionCreation();
        testTopicWithMultiplePartitions();
        testBrokerWithMultipleTopics();
        testMessageCreationAndStorage();
        testOffsetTracking();

        System.out.println("\n=== ALL PHASE 1 TESTS COMPLETED ===\n");

        System.out.println("=== PHASE 2 TESTS: Producer with Partition Assignment ===\n");

        testProducerKeyBasedPartitioning();
        testProducerRoundRobinPartitioning();
        testProducerOffsetReturn();
        testProducerMessageStorage();
        testProducerMultipleMessages();

        System.out.println("\n=== ALL PHASE 2 TESTS COMPLETED ===\n");

        System.out.println("=== PHASE 3 TESTS: Basic Consumer ===\n");

        testConsumerSubscribe();
        testConsumerPoll();
        testConsumerSequentialPolling();
        testConsumerMultiplePartitions();
        testConsumerOffsetTracking();

        System.out.println("\n=== ALL PHASE 3 TESTS COMPLETED ===\n");

        System.out.println("=== PHASE 5 TESTS: Consumer Lag ===\n");

        testConsumerLagCalculation();
        testConsumerLagAfterCommit();
        testConsumerLagMultiplePartitions();

        System.out.println("\n=== ALL PHASE 5 TESTS COMPLETED ===\n");

        System.out.println("=== PHASE 6 TESTS: Edge Cases & Utilities ===\n");

        testListTopics();
        testDeleteTopic();
        testConsumerUnsubscribe();
        testConsumerSeek();
        testMoreConsumersThanPartitions();

        System.out.println("\n=== ALL PHASE 6 TESTS COMPLETED ===");
        System.out.println("\n🎉 ALL TESTS PASSED! KAFKA IMPLEMENTATION COMPLETE! 🎉");
    }

    // Test 1: Partition creation and offset tracking
    static void testPartitionCreation() {
        System.out.println("Test 1: Partition Creation and Offset Tracking");

        Partition partition = new Partition(0);

        System.out.println("  Partition ID: " + partition.getPartitionId() + " (expected: 0)");
        System.out.println("  Initial next offset: " + partition.getNextOffset() + " (expected: 0)");

        // Simulate adding messages by incrementing offset
        partition.setNextOffset(partition.getNextOffset() + 1);
        partition.setNextOffset(partition.getNextOffset() + 1);
        partition.setNextOffset(partition.getNextOffset() + 1);

        System.out.println("  After 3 messages, next offset: " + partition.getNextOffset() + " (expected: 3)");

        assert partition.getPartitionId() == 0 : "Partition ID should be 0";
        assert partition.getNextOffset() == 3 : "Next offset should be 3";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 2: Topic with multiple partitions
    static void testTopicWithMultiplePartitions() {
        System.out.println("Test 2: Topic with Multiple Partitions");

        Topic topic = new Topic();
        topic.setName("orders");
        topic.setPartitions(new ArrayList<>());

        // Add 3 partitions
        topic.addPartition(new Partition(0));
        topic.addPartition(new Partition(1));
        topic.addPartition(new Partition(2));

        System.out.println("  Topic name: " + topic.getName());
        System.out.println("  Number of partitions: " + topic.getPartitions().size() + " (expected: 3)");

        // Get partitions
        Partition p0 = topic.getPartition(0);
        Partition p1 = topic.getPartition(1);
        Partition p2 = topic.getPartition(2);

        System.out.println("  Partition 0 ID: " + p0.getPartitionId() + " (expected: 0)");
        System.out.println("  Partition 1 ID: " + p1.getPartitionId() + " (expected: 1)");
        System.out.println("  Partition 2 ID: " + p2.getPartitionId() + " (expected: 2)");

        assert topic.getPartitions().size() == 3 : "Should have 3 partitions";
        assert p0.getPartitionId() == 0 : "Partition 0 ID should be 0";
        assert p1.getPartitionId() == 1 : "Partition 1 ID should be 1";
        assert p2.getPartitionId() == 2 : "Partition 2 ID should be 2";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 3: Broker with multiple topics
    static void testBrokerWithMultipleTopics() {
        System.out.println("Test 3: Broker with Multiple Topics");

        KafkaBrokerDB db = KafkaBrokerDB.getInstance();

        // Create broker
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        System.out.println("  Broker ID: " + broker.getId());

        // Create topic 1: orders with 3 partitions
        Topic ordersTopic = new Topic();
        ordersTopic.setName("orders");
        ordersTopic.setPartitions(new ArrayList<>());
        ordersTopic.addPartition(new Partition(0));
        ordersTopic.addPartition(new Partition(1));
        ordersTopic.addPartition(new Partition(2));
        db.addTopic(broker.getId(), ordersTopic);

        // Create topic 2: payments with 2 partitions
        Topic paymentsTopic = new Topic();
        paymentsTopic.setName("payments");
        paymentsTopic.setPartitions(new ArrayList<>());
        paymentsTopic.addPartition(new Partition(0));
        paymentsTopic.addPartition(new Partition(1));
        db.addTopic(broker.getId(), paymentsTopic);

        // Retrieve topics
        Topic retrievedOrders = db.getTopic(broker.getId(), "orders");
        Topic retrievedPayments = db.getTopic(broker.getId(), "payments");

        System.out.println("  Orders topic partitions: " + retrievedOrders.getPartitions().size() + " (expected: 3)");
        System.out.println("  Payments topic partitions: " + retrievedPayments.getPartitions().size() + " (expected: 2)");

        assert retrievedOrders.getPartitions().size() == 3 : "Orders should have 3 partitions";
        assert retrievedPayments.getPartitions().size() == 2 : "Payments should have 2 partitions";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 4: Message creation and storage in MessageDb
    static void testMessageCreationAndStorage() {
        System.out.println("Test 4: Message Creation and Storage");

        MessageDb messageDb = MessageDb.getInstance();

        // Create messages
        Message msg1 = new Message("user123", "order-1", System.currentTimeMillis(), null, 0L, 0);

        Message msg2 = new Message("user456", "order-2", System.currentTimeMillis(), null, 1L, 0);

        Message msg3 = new Message("user789", "order-3", System.currentTimeMillis(), null, 2L, 1);
        // Add to MessageDb
        messageDb.addMessage(msg1);
        messageDb.addMessage(msg2);
        messageDb.addMessage(msg3);

        System.out.println("  Message 1:");
        System.out.println("    ID: " + msg1.getId() + " (auto-generated)");
        System.out.println("    Key: " + msg1.getKey() + " (expected: user123)");
        System.out.println("    Value: " + msg1.getValue() + " (expected: order-1)");
        System.out.println("    Offset: " + msg1.getOffset() + " (expected: 0)");
        System.out.println("    Partition: " + msg1.getPartitionId() + " (expected: 0)");

        System.out.println("  Message 2:");
        System.out.println("    ID: " + msg2.getId() + " (auto-generated)");
        System.out.println("    Key: " + msg2.getKey() + " (expected: user456)");
        System.out.println("    Offset: " + msg2.getOffset() + " (expected: 1)");

        System.out.println("  Message 3:");
        System.out.println("    ID: " + msg3.getId() + " (auto-generated)");
        System.out.println("    Partition: " + msg3.getPartitionId() + " (expected: 1)");

        assert msg1.getId() != null : "Message 1 should have auto-generated ID";
        assert msg2.getId() != null : "Message 2 should have auto-generated ID";
        assert msg3.getId() != null : "Message 3 should have auto-generated ID";
        assert msg1.getKey().equals("user123") : "Message 1 key should be user123";
        assert msg2.getOffset() == 1L : "Message 2 offset should be 1";
        assert msg3.getPartitionId() == 1 : "Message 3 partition should be 1";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 5: Offset tracking in partitions
    static void testOffsetTracking() {
        System.out.println("Test 5: Offset Tracking in Partitions");

        Partition partition = new Partition(0);
        MessageDb messageDb = MessageDb.getInstance();

        System.out.println("  Initial next offset: " + partition.getNextOffset() + " (expected: 0)");

        // Simulate adding 10 messages
        for (int i = 0; i < 10; i++) {
            Message msg = new Message("key" + i, "value" + i, System.currentTimeMillis(), null, partition.getNextOffset(), partition.getPartitionId());

            messageDb.addMessage(msg);

            System.out.println("    Message " + i + " -> Offset: " + msg.getOffset());

            // Increment offset
            partition.setNextOffset(partition.getNextOffset() + 1);
        }

        System.out.println("  Final next offset: " + partition.getNextOffset() + " (expected: 10)");

        assert partition.getNextOffset() == 10 : "Next offset should be 10 after adding 10 messages";

        System.out.println("  ✅ PASSED\n");
    }

    // ========== PHASE 2 TESTS ==========

    // Test 6: Producer with Key-Based Partitioning
    static void testProducerKeyBasedPartitioning() {
        System.out.println("Test 6: Producer with Key-Based Partitioning");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("user-events");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        topic.addPartition(new Partition(1));
        topic.addPartition(new Partition(2));
        db.addTopic(broker.getId(), topic);

        Producer producer = Producer.getInstance();

        // Send messages with same key - should go to same partition
        long offset1 = producer.send(broker.getId(), "user-events", "user123", "event1", SelectionType.KEY_BASED);
        long offset2 = producer.send(broker.getId(), "user-events", "user123", "event2", SelectionType.KEY_BASED);
        long offset3 = producer.send(broker.getId(), "user-events", "user123", "event3", SelectionType.KEY_BASED);

        // Get the partition for user123
        int expectedPartition = Math.abs("user123".hashCode()) % 3;
        Partition partition = db.getTopic(broker.getId(), "user-events").getPartition(expectedPartition);

        System.out.println("  Key: user123");
        System.out.println("  Expected partition: " + expectedPartition);
        System.out.println("  Partition next offset: " + partition.getNextOffset() + " (expected: 3)");
        System.out.println("  Offset 1: " + offset1 + " (expected: 0)");
        System.out.println("  Offset 2: " + offset2 + " (expected: 1)");
        System.out.println("  Offset 3: " + offset3 + " (expected: 2)");

        assert partition.getNextOffset() == 3 : "Partition should have 3 messages";
        assert offset1 == 0 : "First offset should be 0";
        assert offset2 == 1 : "Second offset should be 1";
        assert offset3 == 2 : "Third offset should be 2";

        // Send messages with different key - should go to different partition
        long offset4 = producer.send(broker.getId(), "user-events", "user456", "event4", SelectionType.KEY_BASED);
        int partition2 = Math.abs("user456".hashCode()) % 3;

        System.out.println("  Key: user456");
        System.out.println("  Expected partition: " + partition2);
        System.out.println("  Offset: " + offset4 + " (expected: 0)");

        assert offset4 == 0 : "First message in new partition should have offset 0";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 7: Producer with Round-Robin Partitioning
    static void testProducerRoundRobinPartitioning() {
        System.out.println("Test 7: Producer with Round-Robin Partitioning");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("logs");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        topic.addPartition(new Partition(1));
        topic.addPartition(new Partition(2));
        db.addTopic(broker.getId(), topic);

        Producer producer = Producer.getInstance();

        // Send messages without key - should distribute round-robin
        System.out.println("  Sending 6 messages with round-robin...");
        for (int i = 0; i < 6; i++) {
            long offset = producer.send(broker.getId(), "logs", null, "log-" + i, SelectionType.ROUND_ROBIN);
            System.out.println("    Message " + i + " -> Offset: " + offset);
        }

        // Check distribution - each partition should have 2 messages
        Partition p0 = db.getTopic(broker.getId(), "logs").getPartition(0);
        Partition p1 = db.getTopic(broker.getId(), "logs").getPartition(1);
        Partition p2 = db.getTopic(broker.getId(), "logs").getPartition(2);

        System.out.println("  Partition 0 next offset: " + p0.getNextOffset() + " (expected: 2)");
        System.out.println("  Partition 1 next offset: " + p1.getNextOffset() + " (expected: 2)");
        System.out.println("  Partition 2 next offset: " + p2.getNextOffset() + " (expected: 2)");

        assert p0.getNextOffset() == 2 : "Partition 0 should have 2 messages";
        assert p1.getNextOffset() == 2 : "Partition 1 should have 2 messages";
        assert p2.getNextOffset() == 2 : "Partition 2 should have 2 messages";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 8: Producer returns correct offset
    static void testProducerOffsetReturn() {
        System.out.println("Test 8: Producer Returns Correct Offset");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("transactions");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        db.addTopic(broker.getId(), topic);

        Producer producer = Producer.getInstance();

        // Send 5 messages and verify returned offsets
        System.out.println("  Sending 5 messages and checking returned offsets...");
        for (int i = 0; i < 5; i++) {
            long returnedOffset = producer.send(broker.getId(), "transactions", "key" + i, "value" + i, SelectionType.KEY_BASED);
            System.out.println("    Message " + i + " returned offset: " + returnedOffset);

            // Since all messages go to partition 0, offsets should be sequential
            // But we can't predict exact offset due to previous tests
            assert returnedOffset >= 0 : "Offset should be non-negative";
        }

        System.out.println("  ✅ PASSED\n");
    }

    // Test 9: Producer stores messages in MessageDb
    static void testProducerMessageStorage() {
        System.out.println("Test 9: Producer Stores Messages in MessageDb");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        MessageDb messageDb = MessageDb.getInstance();

        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("notifications");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        topic.addPartition(new Partition(1));
        db.addTopic(broker.getId(), topic);

        Producer producer = Producer.getInstance();

        // Send messages
        long offset1 = producer.send(broker.getId(), "notifications", "email", "Welcome email", SelectionType.KEY_BASED);
        long offset2 = producer.send(broker.getId(), "notifications", "sms", "OTP message", SelectionType.KEY_BASED);

        System.out.println("  Message 1:");
        System.out.println("    Key: email");
        System.out.println("    Value: Welcome email");
        System.out.println("    Offset: " + offset1);

        System.out.println("  Message 2:");
        System.out.println("    Key: sms");
        System.out.println("    Value: OTP message");
        System.out.println("    Offset: " + offset2);

        System.out.println("  Messages stored in MessageDb with auto-generated IDs");
        System.out.println("  ✅ PASSED\n");
    }

    // Test 10: Producer handles multiple messages correctly
    static void testProducerMultipleMessages() {
        System.out.println("Test 10: Producer Handles Multiple Messages");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("metrics");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        topic.addPartition(new Partition(1));
        topic.addPartition(new Partition(2));
        db.addTopic(broker.getId(), topic);

        Producer producer = Producer.getInstance();

        // Send 20 messages with key-based partitioning
        System.out.println("  Sending 20 messages with key-based partitioning...");
        Map<String, Integer> keyToPartition = new HashMap<>();

        for (int i = 0; i < 20; i++) {
            String key = "metric-" + (i % 5);  // 5 different keys
            long offset = producer.send(broker.getId(), "metrics", key, "value-" + i, SelectionType.KEY_BASED);

            // Track which partition each key goes to
            int partition = Math.abs(key.hashCode()) % 3;
            keyToPartition.put(key, partition);
        }

        System.out.println("  Key distribution:");
        for (Map.Entry<String, Integer> entry : keyToPartition.entrySet()) {
            System.out.println("    " + entry.getKey() + " -> Partition " + entry.getValue());
        }

        // Verify total messages across all partitions
        Partition p0 = db.getTopic(broker.getId(), "metrics").getPartition(0);
        Partition p1 = db.getTopic(broker.getId(), "metrics").getPartition(1);
        Partition p2 = db.getTopic(broker.getId(), "metrics").getPartition(2);

        long totalMessages = p0.getNextOffset() + p1.getNextOffset() + p2.getNextOffset();
        System.out.println("  Total messages across all partitions: " + totalMessages + " (expected: 20)");

        assert totalMessages == 20 : "Should have 20 messages total";

        System.out.println("  ✅ PASSED\n");
    }

    // ========== PHASE 3 TESTS ==========

    // Test 11: Consumer Subscribe
    static void testConsumerSubscribe() {
        System.out.println("Test 11: Consumer Subscribe");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("events");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        topic.addPartition(new Partition(1));
        topic.addPartition(new Partition(2));
        db.addTopic(broker.getId(), topic);

        // Create consumer and subscribe
        ConsumerService consumerService = ConsumerService.getInstance();
        ConsumerData consumer = consumerService.createConsumer();
        consumerService.subscribe(consumer.getId(), broker.getId(), "events", java.util.Arrays.asList(0, 1, 2));

        System.out.println("  Subscribed topic: " + consumer.getSubscribedTopic() + " (expected: events)");
        System.out.println("  Assigned partitions: " + consumerService.getAssignedPartitions(consumer.getId()) + " (expected: [0, 1, 2])");
        System.out.println("  Current offsets: " + consumerService.getCurrentOffsets(consumer.getId()));

        assert consumer.getSubscribedTopic().equals("events") : "Should be subscribed to events";
        assert consumerService.getAssignedPartitions(consumer.getId()).size() == 3 : "Should have 3 partitions";
        assert consumerService.getCurrentOffsets(consumer.getId()).get(0) == 0L : "Offset should start at 0";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 12: Consumer Poll
    static void testConsumerPoll() {
        System.out.println("Test 12: Consumer Poll");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("orders");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        db.addTopic(broker.getId(), topic);

        // Produce 10 messages
        Producer producer = Producer.getInstance();
        System.out.println("  Producing 10 messages...");
        for (int i = 0; i < 10; i++) {
            producer.send(broker.getId(), "orders", "key" + i, "order-" + i, SelectionType.KEY_BASED);
        }

        // Create consumer and poll
        ConsumerService consumerService = ConsumerService.getInstance();
        ConsumerData consumer = consumerService.createConsumer();
        consumerService.subscribe(consumer.getId(), broker.getId(), "orders", java.util.Arrays.asList(0));

        List<Message> messages = consumerService.poll(consumer.getId(), 5);

        System.out.println("  Polled messages: " + messages.size() + " (expected: 5)");
        for (int i = 0; i < messages.size(); i++) {
            System.out.println("    Message " + i + ": offset=" + messages.get(i).getOffset() +
                             ", value=" + messages.get(i).getValue());
        }

        assert messages.size() == 5 : "Should poll 5 messages";
        assert messages.get(0).getOffset() == 0L : "First message should have offset 0";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 13: Consumer Sequential Polling
    static void testConsumerSequentialPolling() {
        System.out.println("Test 13: Consumer Sequential Polling");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("logs");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        db.addTopic(broker.getId(), topic);

        // Produce 20 messages
        Producer producer = Producer.getInstance();
        System.out.println("  Producing 20 messages...");
        for (int i = 0; i < 20; i++) {
            producer.send(broker.getId(), "logs", "key" + i, "log-" + i, SelectionType.KEY_BASED);
        }

        // Create consumer
        ConsumerService consumerService = ConsumerService.getInstance();
        ConsumerData consumer = consumerService.createConsumer();
        consumerService.subscribe(consumer.getId(), broker.getId(), "logs", java.util.Arrays.asList(0));

        // Poll 3 times
        System.out.println("  Poll 1: Get 5 messages");
        List<Message> batch1 = consumerService.poll(consumer.getId(), 5);
        System.out.println("    Got " + batch1.size() + " messages, offsets: " +
                         batch1.get(0).getOffset() + " to " + batch1.get(batch1.size()-1).getOffset());

        System.out.println("  Poll 2: Get next 5 messages");
        List<Message> batch2 = consumerService.poll(consumer.getId(), 5);
        System.out.println("    Got " + batch2.size() + " messages, offsets: " +
                         batch2.get(0).getOffset() + " to " + batch2.get(batch2.size()-1).getOffset());

        System.out.println("  Poll 3: Get next 5 messages");
        List<Message> batch3 = consumerService.poll(consumer.getId(), 5);
        System.out.println("    Got " + batch3.size() + " messages, offsets: " +
                         batch3.get(0).getOffset() + " to " + batch3.get(batch3.size()-1).getOffset());

        System.out.println("  Poll 4: Get remaining messages");
        List<Message> batch4 = consumerService.poll(consumer.getId(), 10);
        System.out.println("    Got " + batch4.size() + " messages");

        System.out.println("  Poll 5: Should be empty");
        List<Message> batch5 = consumerService.poll(consumer.getId(), 10);
        System.out.println("    Got " + batch5.size() + " messages (expected: 0)");

        assert batch1.size() == 5 : "Batch 1 should have 5 messages";
        assert batch2.size() == 5 : "Batch 2 should have 5 messages";
        assert batch3.size() == 5 : "Batch 3 should have 5 messages";
        assert batch4.size() == 5 : "Batch 4 should have 5 messages";
        assert batch5.size() == 0 : "Batch 5 should be empty";

        // Verify sequential offsets
        assert batch2.get(0).getOffset() == batch1.get(batch1.size()-1).getOffset() + 1 :
               "Batch 2 should continue from where batch 1 left off";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 14: Consumer Multiple Partitions
    static void testConsumerMultiplePartitions() {
        System.out.println("Test 14: Consumer Multiple Partitions");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("metrics");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        topic.addPartition(new Partition(1));
        topic.addPartition(new Partition(2));
        db.addTopic(broker.getId(), topic);

        // Produce 30 messages with round-robin
        Producer producer = Producer.getInstance();
        System.out.println("  Producing 30 messages with round-robin...");
        for (int i = 0; i < 30; i++) {
            producer.send(broker.getId(), "metrics", null, "metric-" + i, SelectionType.ROUND_ROBIN);
        }

        // Consumer subscribes to all 3 partitions
        ConsumerService consumerService = ConsumerService.getInstance();
        ConsumerData consumer = consumerService.createConsumer();
        consumerService.subscribe(consumer.getId(), broker.getId(), "metrics", java.util.Arrays.asList(0, 1, 2));

        // Poll all messages
        List<Message> allMessages = consumerService.poll(consumer.getId(), 30);

        System.out.println("  Total messages polled: " + allMessages.size() + " (expected: 30)");
        System.out.println("  Current offsets: " + consumerService.getCurrentOffsets(consumer.getId()));

        assert allMessages.size() == 30 : "Should poll all 30 messages";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 15: Consumer Offset Tracking
    static void testConsumerOffsetTracking() {
        System.out.println("Test 15: Consumer Offset Tracking");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("tracking-test");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        db.addTopic(broker.getId(), topic);

        // Produce 15 messages
        Producer producer = Producer.getInstance();
        for (int i = 0; i < 15; i++) {
            producer.send(broker.getId(), "tracking-test", "key", "msg-" + i, SelectionType.KEY_BASED);
        }

        // Create consumer
        ConsumerService consumerService = ConsumerService.getInstance();
        ConsumerData consumer = consumerService.createConsumer();
        consumerService.subscribe(consumer.getId(), broker.getId(), "tracking-test", java.util.Arrays.asList(0));

        System.out.println("  Initial offset: " + consumerService.getCurrentOffsets(consumer.getId()).get(0) + " (expected: 0)");

        // Poll 7 messages
        consumerService.poll(consumer.getId(), 7);
        System.out.println("  After polling 7 messages, offset: " + consumerService.getCurrentOffsets(consumer.getId()).get(0) + " (expected: 7)");
        assert consumerService.getCurrentOffsets(consumer.getId()).get(0) == 7L : "Offset should be 7 after reading 7 messages";

        // Poll 5 more
        consumerService.poll(consumer.getId(), 5);
        System.out.println("  After polling 5 more, offset: " + consumerService.getCurrentOffsets(consumer.getId()).get(0) + " (expected: 12)");
        assert consumerService.getCurrentOffsets(consumer.getId()).get(0) == 12L : "Offset should be 12";

        // Poll remaining
        List<Message> remaining = consumerService.poll(consumer.getId(), 10);
        System.out.println("  Remaining messages: " + remaining.size() + " (expected: 3)");
        System.out.println("  Final offset: " + consumerService.getCurrentOffsets(consumer.getId()).get(0) + " (expected: 15)");

        assert remaining.size() == 3 : "Should have 3 remaining messages";
        assert consumerService.getCurrentOffsets(consumer.getId()).get(0) == 15L : "Final offset should be 15";

        System.out.println("  ✅ PASSED\n");
    }

    // ========== PHASE 5 TESTS ==========

    // Test 16: Consumer Lag Calculation
    static void testConsumerLagCalculation() {
        System.out.println("Test 16: Consumer Lag Calculation");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("lag-test");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        db.addTopic(broker.getId(), topic);

        // Produce 100 messages
        Producer producer = Producer.getInstance();
        System.out.println("  Producing 100 messages...");
        for (int i = 0; i < 100; i++) {
            producer.send(broker.getId(), "lag-test", "key", "msg-" + i, SelectionType.KEY_BASED);
        }

        // Create consumer and subscribe with group
        ConsumerService consumerService = ConsumerService.getInstance();
        ConsumerData consumer = consumerService.createConsumer();
        consumerService.subscribe(consumer.getId(), broker.getId(), "lag-test", "lag-group");

        // Initial lag (no messages consumed yet)
        Map<Integer, Long> initialLag = consumerService.getLag(consumer.getId());
        System.out.println("  Initial lag: " + initialLag + " (expected: {0=100})");

        // Consume 20 messages
        consumerService.poll(consumer.getId(), 20);
        consumerService.commit(consumer.getId());

        // Check lag after consuming 20
        Map<Integer, Long> lagAfter20 = consumerService.getLag(consumer.getId());
        System.out.println("  Lag after consuming 20: " + lagAfter20 + " (expected: {0=80})");

        // Consume 50 more
        consumerService.poll(consumer.getId(), 50);
        consumerService.commit(consumer.getId());

        Map<Integer, Long> lagAfter70 = consumerService.getLag(consumer.getId());
        System.out.println("  Lag after consuming 70 total: " + lagAfter70 + " (expected: {0=30})");

        assert initialLag.get(0) == 100L : "Initial lag should be 100";
        assert lagAfter20.get(0) == 80L : "Lag after 20 should be 80";
        assert lagAfter70.get(0) == 30L : "Lag after 70 should be 30";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 17: Consumer Lag After Commit
    static void testConsumerLagAfterCommit() {
        System.out.println("Test 17: Consumer Lag After Commit");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("commit-lag-test");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        db.addTopic(broker.getId(), topic);

        // Produce 50 messages
        Producer producer = Producer.getInstance();
        for (int i = 0; i < 50; i++) {
            producer.send(broker.getId(), "commit-lag-test", "key", "msg-" + i, SelectionType.KEY_BASED);
        }

        ConsumerService consumerService = ConsumerService.getInstance();
        ConsumerData consumer = consumerService.createConsumer();
        consumerService.subscribe(consumer.getId(), broker.getId(), "commit-lag-test", "commit-group");

        // Poll without commit
        consumerService.poll(consumer.getId(), 10);
        Map<Integer, Long> lagBeforeCommit = consumerService.getLag(consumer.getId());
        System.out.println("  Lag before commit: " + lagBeforeCommit);

        // Commit
        consumerService.commit(consumer.getId());
        Map<Integer, Long> lagAfterCommit = consumerService.getLag(consumer.getId());
        System.out.println("  Lag after commit: " + lagAfterCommit + " (expected: {0=40})");

        assert lagAfterCommit.get(0) == 40L : "Lag after commit should be 40";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 18: Consumer Lag Multiple Partitions
    static void testConsumerLagMultiplePartitions() {
        System.out.println("Test 18: Consumer Lag Multiple Partitions");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("multi-partition-lag");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        topic.addPartition(new Partition(1));
        topic.addPartition(new Partition(2));
        db.addTopic(broker.getId(), topic);

        // Produce 90 messages with round-robin (30 per partition)
        Producer producer = Producer.getInstance();
        for (int i = 0; i < 90; i++) {
            producer.send(broker.getId(), "multi-partition-lag", null, "msg-" + i, SelectionType.ROUND_ROBIN);
        }

        ConsumerService consumerService = ConsumerService.getInstance();
        ConsumerData consumer = consumerService.createConsumer();
        consumerService.subscribe(consumer.getId(), broker.getId(), "multi-partition-lag", "multi-lag-group");

        // Initial lag
        Map<Integer, Long> initialLag = consumerService.getLag(consumer.getId());
        System.out.println("  Initial lag: " + initialLag);
        System.out.println("    Partition 0: " + initialLag.get(0) + " (expected: 30)");
        System.out.println("    Partition 1: " + initialLag.get(1) + " (expected: 30)");
        System.out.println("    Partition 2: " + initialLag.get(2) + " (expected: 30)");

        // Consume 45 messages (15 from each partition)
        consumerService.poll(consumer.getId(), 45);
        consumerService.commit(consumer.getId());

        Map<Integer, Long> lagAfter = consumerService.getLag(consumer.getId());
        System.out.println("  Lag after consuming 45: " + lagAfter);

        long totalLag = lagAfter.values().stream().mapToLong(Long::longValue).sum();
        System.out.println("  Total lag: " + totalLag + " (expected: 45)");

        assert totalLag == 45L : "Total lag should be 45";

        System.out.println("  ✅ PASSED\n");
    }

    // ========== PHASE 6 TESTS ==========

    // Test 19: List Topics
    static void testListTopics() {
        System.out.println("Test 19: List Topics");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        // Create 3 topics
        Topic topic1 = new Topic();
        topic1.setName("topic-a");
        topic1.setPartitions(new ArrayList<>());
        topic1.addPartition(new Partition(0));
        db.addTopic(broker.getId(), topic1);

        Topic topic2 = new Topic();
        topic2.setName("topic-b");
        topic2.setPartitions(new ArrayList<>());
        topic2.addPartition(new Partition(0));
        db.addTopic(broker.getId(), topic2);

        Topic topic3 = new Topic();
        topic3.setName("topic-c");
        topic3.setPartitions(new ArrayList<>());
        topic3.addPartition(new Partition(0));
        db.addTopic(broker.getId(), topic3);

        // List topics
        List<String> topics = db.listTopics(broker.getId());
        System.out.println("  Topics: " + topics);
        System.out.println("  Count: " + topics.size() + " (expected: 3)");

        assert topics.size() == 3 : "Should have 3 topics";
        assert topics.contains("topic-a") : "Should contain topic-a";
        assert topics.contains("topic-b") : "Should contain topic-b";
        assert topics.contains("topic-c") : "Should contain topic-c";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 20: Delete Topic
    static void testDeleteTopic() {
        System.out.println("Test 20: Delete Topic");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("delete-me");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        db.addTopic(broker.getId(), topic);

        System.out.println("  Topics before delete: " + db.listTopics(broker.getId()));

        // Delete topic
        db.deleteTopic(broker.getId(), "delete-me");

        System.out.println("  Topics after delete: " + db.listTopics(broker.getId()));

        assert !db.topicExists(broker.getId(), "delete-me") : "Topic should be deleted";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 21: Consumer Unsubscribe
    static void testConsumerUnsubscribe() {
        System.out.println("Test 21: Consumer Unsubscribe");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("unsub-test");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        topic.addPartition(new Partition(1));
        db.addTopic(broker.getId(), topic);

        ConsumerService consumerService = ConsumerService.getInstance();
        ConsumerData consumer = consumerService.createConsumer();
        consumerService.subscribe(consumer.getId(), broker.getId(), "unsub-test", "unsub-group");

        System.out.println("  Before unsubscribe:");
        System.out.println("    Subscribed topic: " + consumer.getSubscribedTopic());
        System.out.println("    Assigned partitions: " + consumerService.getAssignedPartitions(consumer.getId()));

        // Unsubscribe
        consumerService.unsubscribe(consumer.getId());

        System.out.println("  After unsubscribe:");
        System.out.println("    Subscribed topic: " + consumer.getSubscribedTopic() + " (expected: null)");
        System.out.println("    Assigned partitions: " + consumerService.getAssignedPartitions(consumer.getId()) + " (expected: [])");

        assert consumer.getSubscribedTopic() == null : "Should not be subscribed";
        assert consumerService.getAssignedPartitions(consumer.getId()).isEmpty() : "Should have no partitions";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 22: Consumer Seek
    static void testConsumerSeek() {
        System.out.println("Test 22: Consumer Seek");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("seek-test");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        db.addTopic(broker.getId(), topic);

        // Produce 50 messages
        Producer producer = Producer.getInstance();
        for (int i = 0; i < 50; i++) {
            producer.send(broker.getId(), "seek-test", "key", "msg-" + i, SelectionType.KEY_BASED);
        }

        ConsumerService consumerService = ConsumerService.getInstance();
        ConsumerData consumer = consumerService.createConsumer();
        consumerService.subscribe(consumer.getId(), broker.getId(), "seek-test", java.util.Arrays.asList(0));

        // Poll 10 messages
        consumerService.poll(consumer.getId(), 10);
        System.out.println("  Current offset after polling 10: " + consumerService.getCurrentOffsets(consumer.getId()).get(0));

        // Seek to offset 25
        consumerService.seek(consumer.getId(), 0, 25);
        System.out.println("  Offset after seek(0, 25): " + consumerService.getCurrentOffsets(consumer.getId()).get(0) + " (expected: 25)");

        // Poll next message should be at offset 25
        List<Message> messages = consumerService.poll(consumer.getId(), 1);
        System.out.println("  Next message offset: " + messages.get(0).getOffset() + " (expected: 25)");

        assert consumerService.getCurrentOffsets(consumer.getId()).get(0) == 25L : "Offset should be 25 after seek";
        assert messages.get(0).getOffset() == 25L : "Next message should be at offset 25";

        System.out.println("  ✅ PASSED\n");
    }

    // Test 23: More Consumers Than Partitions
    static void testMoreConsumersThanPartitions() {
        System.out.println("Test 23: More Consumers Than Partitions");

        // Setup
        KafkaBrokerDB db = KafkaBrokerDB.getInstance();
        KafkaBroker broker = new KafkaBroker();
        broker.setTopics(new HashMap<>());
        broker = db.addBroker(broker);

        Topic topic = new Topic();
        topic.setName("edge-case-test");
        topic.setPartitions(new ArrayList<>());
        topic.addPartition(new Partition(0));
        topic.addPartition(new Partition(1));
        topic.addPartition(new Partition(2));
        db.addTopic(broker.getId(), topic);

        // Create 5 consumers for 3 partitions
        ConsumerService consumerService = ConsumerService.getInstance();
        ConsumerData c1 = consumerService.createConsumer();
        ConsumerData c2 = consumerService.createConsumer();
        ConsumerData c3 = consumerService.createConsumer();
        ConsumerData c4 = consumerService.createConsumer();
        ConsumerData c5 = consumerService.createConsumer();

        consumerService.subscribe(c1.getId(), broker.getId(), "edge-case-test", "edge-group");
        consumerService.subscribe(c2.getId(), broker.getId(), "edge-case-test", "edge-group");
        consumerService.subscribe(c3.getId(), broker.getId(), "edge-case-test", "edge-group");
        consumerService.subscribe(c4.getId(), broker.getId(), "edge-case-test", "edge-group");
        consumerService.subscribe(c5.getId(), broker.getId(), "edge-case-test", "edge-group");

        System.out.println("  Consumer 1 partitions: " + consumerService.getAssignedPartitions(c1.getId()));
        System.out.println("  Consumer 2 partitions: " + consumerService.getAssignedPartitions(c2.getId()));
        System.out.println("  Consumer 3 partitions: " + consumerService.getAssignedPartitions(c3.getId()));
        System.out.println("  Consumer 4 partitions: " + consumerService.getAssignedPartitions(c4.getId()) + " (expected: [])");
        System.out.println("  Consumer 5 partitions: " + consumerService.getAssignedPartitions(c5.getId()) + " (expected: [])");

        // Consumers 4 and 5 should have no partitions
        assert consumerService.getAssignedPartitions(c4.getId()).isEmpty() : "Consumer 4 should have no partitions";
        assert consumerService.getAssignedPartitions(c5.getId()).isEmpty() : "Consumer 5 should have no partitions";

        // Total partitions assigned should be 3
        int totalAssigned = consumerService.getAssignedPartitions(c1.getId()).size() +
                           consumerService.getAssignedPartitions(c2.getId()).size() +
                           consumerService.getAssignedPartitions(c3.getId()).size() +
                           consumerService.getAssignedPartitions(c4.getId()).size() +
                           consumerService.getAssignedPartitions(c5.getId()).size();

        System.out.println("  Total partitions assigned: " + totalAssigned + " (expected: 3)");
        assert totalAssigned == 3 : "Should assign exactly 3 partitions total";

        System.out.println("  ✅ PASSED\n");
    }
}