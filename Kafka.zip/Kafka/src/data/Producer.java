package data;

import repo.KafkaBrokerDB;
import repo.MessageDb;
import strategy.PartitionSelectionStrategyFactory;


public class Producer {

    private static Producer instance = null;
    private Producer() {
    }
    public static Producer getInstance() {
        if (instance == null) {
            instance = new Producer();
        }
        return instance;
    }
    private final KafkaBrokerDB kafkaBrokerDB = KafkaBrokerDB.getInstance();
    private final MessageDb messageDb = MessageDb.getInstance();
    private final PartitionSelectionStrategyFactory partitionSelectionStrategyFactory = PartitionSelectionStrategyFactory.getInstance();

    public long send(String brokerId, String topicName, String key, String value, SelectionType selectionType) {
        Topic topic = kafkaBrokerDB.getTopic(brokerId, topicName);
        Partition partition = partitionSelectionStrategyFactory.getStrategy(selectionType).selectPartition(topic, key);
        long assignedOffset = partition.getNextOffset();
        Message message = new Message(key, value, System.currentTimeMillis(), null, assignedOffset, partition.getPartitionId());
        messageDb.addMessage(message);
        partition.setNextOffset(partition.getNextOffset() + 1);
        kafkaBrokerDB.updatePartition(brokerId, topicName, partition);
        return assignedOffset;
    }
}
