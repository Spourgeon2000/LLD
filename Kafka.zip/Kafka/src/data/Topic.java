package data;

import java.util.List;

public class Topic {
    private String name;
    private List<Partition> partitions;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Partition> getPartitions() {
        return partitions;
    }

    public void setPartitions(List<Partition> partitions) {
        this.partitions = partitions;
    }

    public Topic addPartition(Partition partition) {
        this.partitions.add(partition);
        return this;
    }

    public Topic removePartition(Partition partition) {
        this.partitions.remove(partition);
        return this;
    }

    public Partition getPartition(int partitionId) {
        for (Partition partition : partitions) {
            if (partition.getPartitionId() == partitionId) {
                return partition;
            }
        }
        return null;
    }
}
