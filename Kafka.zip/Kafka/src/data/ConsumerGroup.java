package data;

import java.util.HashMap;
import java.util.Map;

/**
 * Consumer Group - manages committed offsets for a group
 * Simplified to not depend on Consumer objects
 */
public class ConsumerGroup {
    private String groupId;
    private String brokerId;
    private String topicName;
    private Map<Integer, Long> committedOffsets;  // partitionId → committed offset

    public ConsumerGroup(String brokerId, String groupId, String topicName) {
        this.brokerId = brokerId;
        this.groupId = groupId;
        this.topicName = topicName;
        this.committedOffsets = new HashMap<>();
    }

    /**
     * Commit offset for a partition
     */
    public void commit(int partitionId, long offset) {
        committedOffsets.put(partitionId, offset);
    }

    /**
     * Get committed offset for a partition
     */
    public long getCommittedOffset(int partitionId) {
        return committedOffsets.getOrDefault(partitionId, 0L);
    }

    /**
     * Get all committed offsets
     */
    public Map<Integer, Long> getCommittedOffsets() {
        return new HashMap<>(committedOffsets);
    }

    /**
     * Get group ID
     */
    public String getGroupId() {
        return groupId;
    }

    /**
     * Get broker ID
     */
    public String getBrokerId() {
        return brokerId;
    }

    /**
     * Get topic name
     */
    public String getTopicName() {
        return topicName;
    }
}
