package data;

public enum SelectionType {
    KEY_BASED,
    ROUND_ROBIN
}
