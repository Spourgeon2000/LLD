package data;

public class Message {
    private String key;
    private String value;
    private Long timestamp;
    private String id;
    private Long offset;
    private Integer partitionId;

    public Message(String key, String value, Long timestamp, String id, Long offset, Integer partitionId) {
        this.key = key;
        this.value = value;
        this.timestamp = timestamp;
        this.id = id;
        this.offset = offset;
        this.partitionId = partitionId;
    }

    public Integer getPartitionId() {
        return partitionId;
    }

    public void setPartitionId(Integer partitionId) {
        this.partitionId = partitionId;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getOffset() {
        return offset;
    }

    public void setOffset(Long offset) {
        this.offset = offset;
    }
}
