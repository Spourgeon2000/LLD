package data;

import java.util.HashMap;
import java.util.Map;

/**
 * Singleton to manage all consumer groups
 */
public class ConsumerGroupManager {
    private static ConsumerGroupManager instance = null;
    
    private Map<String, ConsumerGroup> consumerGroups;  // groupId → ConsumerGroup
    
    private ConsumerGroupManager() {
        this.consumerGroups = new HashMap<>();
    }
    
    public static ConsumerGroupManager getInstance() {
        if (instance == null) {
            instance = new ConsumerGroupManager();
        }
        return instance;
    }
    
    /**
     * Get or create a consumer group
     */
    public ConsumerGroup getOrCreateGroup(String brokerId, String groupId, String topicName) {
        String key = groupId + "-" + topicName;
        
        if (!consumerGroups.containsKey(key)) {
            ConsumerGroup group = new ConsumerGroup(brokerId, groupId, topicName);
            consumerGroups.put(key, group);
        }
        
        return consumerGroups.get(key);
    }
    
    /**
     * Get a consumer group
     */
    public ConsumerGroup getGroup(String groupId, String topicName) {
        String key = groupId + "-" + topicName;
        return consumerGroups.get(key);
    }
    
    /**
     * Get all consumer groups
     */
    public Map<String, ConsumerGroup> getAllGroups() {
        return new HashMap<>(consumerGroups);
    }
}

