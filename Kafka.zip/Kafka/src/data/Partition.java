package data;

public class Partition {
    private Integer partitionId;
    private Long nextOffset;
    public Partition(Integer partitionId) {
        this.partitionId = partitionId;
        this.nextOffset = 0L;
    }

    public Integer getPartitionId() {
        return partitionId;
    }

    public void setPartitionId(Integer partitionId) {
        this.partitionId = partitionId;
    }

    public Long getNextOffset() {
        return nextOffset;
    }

    public void setNextOffset(Long nextOffset) {
        this.nextOffset = nextOffset;
    }

    /**
     * Get the latest offset (last assigned offset)
     * @return Latest offset, or -1 if no messages
     */
    public long getLatestOffset() {
        if (nextOffset == 0) {
            return -1; // No messages yet
        }
        return nextOffset - 1; // Last assigned offset
    }
}
