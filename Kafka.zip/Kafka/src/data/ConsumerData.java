package data;

import java.util.UUID;

/**
 * Pure data model for Consumer
 * Follows Single Responsibility Principle - only holds data, no business logic
 */
public class ConsumerData {
    private String id;
    private String brokerId;
    private String subscribedTopic;
    private String groupId;
    
    public ConsumerData() {
        this.id = UUID.randomUUID().toString();
    }
    
    public ConsumerData(String id) {
        this.id = id;
    }
    
    // Getters and Setters
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getBrokerId() {
        return brokerId;
    }
    
    public void setBrokerId(String brokerId) {
        this.brokerId = brokerId;
    }
    
    public String getSubscribedTopic() {
        return subscribedTopic;
    }
    
    public void setSubscribedTopic(String subscribedTopic) {
        this.subscribedTopic = subscribedTopic;
    }
    
    public String getGroupId() {
        return groupId;
    }
    
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }
    
    @Override
    public String toString() {
        return "Consumer{" +
                "id='" + id + '\'' +
                ", brokerId='" + brokerId + '\'' +
                ", topic='" + subscribedTopic + '\'' +
                ", groupId='" + groupId + '\'' +
                '}';
    }
}

