package strategy;

public class UPIStrategy implements PaymentStrategy{

    public void pay(double amount){
        //some exterbal code
        System.out.println("Paid " + amount + " via UPI");
    }
}
