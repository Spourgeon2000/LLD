package strategy;

public class CardStrategy implements PaymentStrategy {

    public void pay(double amount) {
        //some external code
        System.out.println("Paid " + amount + " via Card");
    }
}
