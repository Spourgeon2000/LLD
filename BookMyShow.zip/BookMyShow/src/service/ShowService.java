package service;

import data.ScreenShow;
import data.ShowSeat;
import repo.ScreenShowRepo;

import java.util.List;

public class ShowService {

    private static ShowService instance = null;

    public static ShowService getInstance() {
        if (instance == null) {
            instance = new ShowService();
            return instance;
        }
        return instance;
    }

    ScreenShowRepo screenShowRepo = ScreenShowRepo.getInstance();

    public ScreenShow addShow(ScreenShow screenShow) {
        return screenShowRepo.addScreenShow(screenShow);
    }

// users can see in particular show what are the seats left for them to book
    //users can see what all the movies are present in screens so that they can book

    public void getAllShowsForAScreen(String screenId) {
        List<ScreenShow> screenShows = screenShowRepo.getScreenShowsForScreenId(screenId);
        for (ScreenShow screenShow : screenShows) {
            System.out.println("Movie Id " + screenShow.getMovieId());
        }
    }

    public void getAllSeatStausforShow(String screenShowId) {
        ScreenShow screenShow = screenShowRepo.getScreenShow(screenShowId);
        for (ShowSeat showSeat : screenShow.getShowSeats()) {
            System.out.println("Seat Id " + showSeat.getSeatId() + " is Available " + showSeat.isAvailable());
        }
    }
}
