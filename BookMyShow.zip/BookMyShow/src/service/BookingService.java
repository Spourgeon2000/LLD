package service;

import data.Booking;
import data.PaymentMode;
import data.ScreenShow;
import data.Seat;
import data.ShowSeat;
import data.factory.PaymentFactory;
import repo.BookingRepo;
import repo.ScreenShowRepo;
import strategy.PaymentStrategy;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

public class BookingService {

    private static BookingService instance = null;

    public static BookingService getInstance() {
        if (instance == null) {
            instance = new BookingService();
            return instance;
        }
        return instance;
    }

    ScreenShowRepo screenShowRepo = ScreenShowRepo.getInstance();
    BookingRepo bookingRepo = BookingRepo.getInstance();
    PaymentFactory paymentFactory = PaymentFactory.getInstance();

    Map<String, ReentrantLock> showSeatIdToLock = new HashMap<>();


    public Booking createBooking(String userId, String screenShowId, List<Seat> seats, PaymentMode
            mode, double amount) {
        checkLocking(screenShowId, seats);
        ScreenShow screenShow = screenShowRepo.getScreenShow(screenShowId);
        List<ShowSeat> showSeats = screenShow.getShowSeats();
        List<String> seatIds = seats.stream()
                .map(Seat::getSeatId)
                .toList();
        for (ShowSeat showSeat : showSeats) {
            if (seatIds.contains(showSeat.getSeatId())) {
                screenShowRepo.updateShowSeatStatus(screenShowId, showSeat.getShowSeatId(), false);
            }
        }
        PaymentStrategy paymentStrategy = paymentFactory.paymentStrategy(mode);
        paymentStrategy.pay(amount);
        Booking booking = bookingRepo.addBooking(screenShowId, seats, userId, mode);
        removeLocking(seats, screenShowId);
        return booking;
    }

    public void getBookings(String userId) {
        List<Booking> bookings = bookingRepo.getBookings(userId);
        for (Booking booking : bookings) {
            System.out.println(booking.getBookingId() + " " + booking.getShowId() + " " + booking.getSeats());
        }
    }

    void checkLocking(String screenShowId, List<Seat> seats) {
        ScreenShow screenShow = screenShowRepo.getScreenShow(screenShowId);
        List<ShowSeat> showSeats = screenShow.getShowSeats();
        List<String> seatIds = seats.stream()
                .map(Seat::getSeatId)
                .toList();
        for (ShowSeat showSeat : showSeats) {
            if (!seatIds.contains(showSeat.getSeatId())) {
                continue;
            }
            String showSeatId = showSeat.getShowSeatId();
            if (showSeatIdToLock.containsKey(showSeatId)) {
                System.out.println("this Seat is already getting booked by another person " + showSeat.getSeatId());
                throw new RuntimeException("Seat is locked , please try to book another seats");
            }
        }
        synchronized (this) {
            for (ShowSeat showSeat : showSeats) {
                if (!seatIds.contains(showSeat.getSeatId())) {
                    continue;
                }
                String showSeatId = showSeat.getShowSeatId();
                showSeatIdToLock.put(showSeatId, new ReentrantLock());
            }
        }
    }

    void removeLocking(List<Seat> seats, String screenShowId) {
        ScreenShow screenShow = screenShowRepo.getScreenShow(screenShowId);
        List<ShowSeat> showSeats = screenShow.getShowSeats();
        List<String> seatIds = seats.stream()
                .map(Seat::getSeatId)
                .toList();
        for (ShowSeat showSeat : showSeats) {
            if (!seatIds.contains(showSeat.getSeatId())) {
                continue;
            }
            showSeatIdToLock.remove(showSeat.getShowSeatId());
        }

    }


}