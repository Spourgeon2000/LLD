package service;

import data.Movie;
import data.ScreenShow;
import repo.MovieRepo;
import repo.ScreenShowRepo;

import java.util.List;

public class MovieService {
    private static MovieService instance = null;

    public static MovieService getInstance() {
        if (instance == null) {
            instance = new MovieService();
            return instance;
        }
        return instance;
    }

    MovieRepo movieRepo = MovieRepo.getInstance();
    ScreenShowRepo screenShowRepo = ScreenShowRepo.getInstance();

    public List<Movie> getMoviesByName(String movieName) {
        return movieRepo.getMovieByNames(movieName);
    }

    public void getAlltheShowScreenWhereMovieIsPresent(String movieId) {
        List<ScreenShow> screenShows = screenShowRepo.getScreenShowsForMovieId(movieId);
        for (ScreenShow screenShow : screenShows) {
            System.out.println("ScreenId " + screenShow.getScreenId() + " ShowId " + screenShow.getScreenShowId());
        }
    }
}
