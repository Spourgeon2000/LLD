package service;

import data.Screen;
import data.Theatre;
import repo.TheatreRepo;

public class TheatreService {
    private static TheatreService instance = null;

    public static TheatreService getInstance() {
        if (instance == null) {
            instance = new TheatreService();
            return instance;
        }
        return instance;
    }

    TheatreRepo theatreRepo = TheatreRepo.getInstance();

    public Theatre addScreen(String theatreId, Screen screen) {
        return theatreRepo.addScreen(theatreId, screen);
    }
}
