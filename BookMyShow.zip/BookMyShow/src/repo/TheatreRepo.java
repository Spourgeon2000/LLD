package repo;

import data.Screen;
import data.Theatre;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class TheatreRepo {
    private static TheatreRepo instance = null;

    public static TheatreRepo getInstance() {
        if (instance == null) {
            instance = new TheatreRepo();
            return instance;
        }
        return instance;
    }

    Map<String, Theatre> theatreMap = new HashMap<>();

    public Theatre addTheatre(Theatre theatre) {
        if (theatre.getTheatreId() == null) {
            theatre.setTheatreId(UUID.randomUUID().toString());
        }
        theatreMap.put(theatre.getTheatreId(), theatre);
        return theatreMap.get(theatre.getTheatreId());
    }

    public Theatre addScreen(String theatreId, Screen screen) {
        if (!theatreMap.containsKey(theatreId)) {
            throw new RuntimeException("theatre not found");
        }
        Theatre theatre = theatreMap.get(theatreId);
        List<Screen> screens = theatre.getScreens();
        screens.add(screen);
        theatre.setScreens(screens);
        theatreMap.put(theatre.getTheatreId(), theatre);
        return theatreMap.get(theatre.getTheatreId());
    }
}
