package repo;

import data.Movie;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

public class MovieRepo {
    private static MovieRepo instance = null;

    public static MovieRepo getInstance() {
        if (instance == null) {
            instance = new MovieRepo();
            return instance;
        }
        return instance;
    }

    Map<String, Movie> movieMap = new HashMap<>();

    public Movie addMove(Movie movie) {
        if (movie.getMovieId() == null) {
            movie.setMovieId(UUID.randomUUID().toString());
        }
        movieMap.put(movie.getMovieId(), movie);
        return movie;
    }

    public List<Movie> getMovieByNames(String movieName) {
        return movieMap.values().stream().filter(movie -> Objects.equals(movieName, movie.getName())).toList();
    }
}
