package repo;

import data.ScreenShow;
import data.ShowSeat;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

public class ScreenShowRepo {
    private static ScreenShowRepo instance = null;

    public static ScreenShowRepo getInstance() {
        if (instance == null) {
            instance = new ScreenShowRepo();
            return instance;
        }
        return instance;
    }

    Map<String, ScreenShow> screenShowMap = new HashMap<>();

    public ScreenShow addScreenShow(ScreenShow screenShow) {
        if (screenShow.getScreenShowId() == null) {
            screenShow.setScreenShowId(UUID.randomUUID().toString());
        }
        screenShowMap.put(screenShow.getScreenShowId(), screenShow);
        return screenShowMap.get(screenShow.getScreenShowId());
    }

    public ScreenShow getScreenShow(String screenShowId) {
        return screenShowMap.get(screenShowId);
    }

    public boolean updateShowSeatStatus(String screenShowId, String showSeatId, boolean isAvailable) {
        ScreenShow screenShow = screenShowMap.get(screenShowId);
        List<ShowSeat> showSeatList = screenShow.getShowSeats();
        boolean updated = false;
        for (ShowSeat showSeat : showSeatList) {
            if (showSeat.isAvailable() && showSeat.getShowSeatId().equals(showSeatId)) {
                showSeat.setAvailable(isAvailable);
                updated = true;
                break;
            }
        }
        screenShow.setShowSeats(showSeatList);
        screenShowMap.put(screenShowId, screenShow);
        return updated;
    }

    public List<ScreenShow> getScreenShowsForScreenId(String screenId) {
        List<ScreenShow> screenShows = (List<ScreenShow>) screenShowMap.values();
        return screenShows.stream().filter(screenShow -> Objects.equals(screenShow.getScreenId(), screenId)).toList();

    }

    public List<ScreenShow> getScreenShowsForMovieId(String movieId) {
        List<ScreenShow> screenShows = (List<ScreenShow>) screenShowMap.values();
        return screenShows.stream().filter(screenShow -> Objects.equals(screenShow.getMovieId(), movieId)).toList();
    }
}
