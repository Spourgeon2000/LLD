package repo;

import data.Booking;
import data.PaymentMode;
import data.PaymentStatus;
import data.Seat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class BookingRepo {
    private static BookingRepo instance = null;

    public static BookingRepo getInstance() {
        if (instance == null) {
            instance = new BookingRepo();
            return instance;
        }
        return instance;
    }

    Map<String, Booking> bookingMap = new HashMap<>();


    public Booking addBooking(String showId, List<Seat> seats, String userId, PaymentMode paymentMode) {
        Booking booking = new Booking();
        booking.setBookingId(UUID.randomUUID().toString());
        booking.setPaymentMode(paymentMode);
        booking.setShowId(showId);
        booking.setSeats(seats);
        booking.setUserId(userId);
        booking.setPaymentStatus(PaymentStatus.PENDING);
        bookingMap.put(booking.getBookingId(), booking);
        return booking;
    }

    public List<Booking> getBookings(String userId){
        List<Booking> bookings = new ArrayList<>();
        for (Booking booking : bookingMap.values()) {
            if (booking.getUserId().equals(userId)) {
                bookings.add(booking);
            }
        }
        return bookings;
    }

}
