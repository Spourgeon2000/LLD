book my show

we can book for a movie 
we can book a seat for particular show 
admin can add shows everyday 
admin can add screens 
users can see what all the movies are present in screens so that they can book
users can see all the booking they have done 
users can see in particular show what are the seats left for them to book
users can search movies by name  etc
each theatre can have multiple screens 
in each screen there are different types of seats like GOLD,SILVER etc

users can pay in multiple ways like cash or card :- this is an extra feature 
two users cannot book the same seat for a particular show :- this is an extra feature as this is not multi threading round
