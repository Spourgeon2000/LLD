package data;

public enum SeatType {
    GOLD,
    SILVER,
    NORMAL
}
