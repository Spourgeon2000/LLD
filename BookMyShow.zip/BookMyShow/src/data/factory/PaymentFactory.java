package data.factory;

import data.PaymentMode;
import strategy.CardStrategy;
import strategy.PaymentStrategy;
import strategy.UPIStrategy;

public class PaymentFactory {

    public static PaymentFactory instance = null;

    public static PaymentFactory getInstance() {
        if (instance == null) {
            instance = new PaymentFactory();
            return instance;
        }
        return instance;
    }

    public PaymentStrategy paymentStrategy(PaymentMode paymentMode) {
        if (paymentMode.equals(PaymentMode.CARD)) {
            return new CardStrategy();
        } else if (paymentMode.equals(PaymentMode.UPI)) {
            return new UPIStrategy();
        }
        throw new IllegalArgumentException("Unsupported payment mode: " + paymentMode);
    }
}
