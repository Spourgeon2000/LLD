package data;

public enum PaymentStatus {
    FAILED,
    SUCCESS,
    PENDING
}
