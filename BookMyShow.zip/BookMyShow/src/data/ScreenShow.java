package data;

import java.util.List;

public class ScreenShow {
    private String screenShowId;
    private String movieId;
    private List<ShowSeat> showSeats;

    public String getScreenShowId() {
        return screenShowId;
    }

    public void setScreenShowId(String screenShowId) {
        this.screenShowId = screenShowId;
    }

    public String getMovieId() {
        return movieId;
    }

    public void setMovieId(String movieId) {
        this.movieId = movieId;
    }

    public List<ShowSeat> getShowSeats() {
        return showSeats;
    }

    public void setShowSeats(List<ShowSeat> showSeats) {
        this.showSeats = showSeats;
    }

    public String getScreenId() {
        return screenId;
    }

    public void setScreenId(String screenId) {
        this.screenId = screenId;
    }

    public String getTheatreId() {
        return theatreId;
    }

    public void setTheatreId(String theatreId) {
        this.theatreId = theatreId;
    }

    private String screenId;
    private String theatreId;



}
