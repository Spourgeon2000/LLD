package data;

public class ShowSeat {
    private boolean isAvailable = true;
    private String showSeatId;
    private SeatType seatType;
    private String seatId;

    public String getSeatId() {
        return seatId;
    }

    public void setSeatId(String seatId) {
        this.seatId = seatId;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public String getShowSeatId() {
        return showSeatId;
    }

    public void setShowSeatId(String showSeatId) {
        this.showSeatId = showSeatId;
    }

    public SeatType getSeatType() {
        return seatType;
    }

    public void setSeatType(SeatType seatType) {
        this.seatType = seatType;
    }
}
