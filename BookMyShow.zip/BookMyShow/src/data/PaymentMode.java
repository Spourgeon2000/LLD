package data;

public enum PaymentMode {
    UPI,
    CARD
}
