# Task Execution Model - How nextExecutionTime Works

## Core Concept

Each task has a `nextExecutionTime` field that determines **when** it should be executed. The scheduler continuously fetches tasks where `nextExecutionTime <= currentTime` and executes them.

---

## Task Types and nextExecutionTime

### 1. Immediate Tasks
```
nextExecutionTime = null (or current time)
```
- Execute as soon as a worker is available
- Go directly to pending queue

### 2. Scheduled Tasks (One-time)
```
nextExecutionTime = specific timestamp (e.g., 2026-01-18 15:30:00)
```
- Wait in scheduled queue until `currentTime >= nextExecutionTime`
- Then move to pending queue and execute once
- After execution: status = COMPLETED

### 3. Recurring Tasks
```
Initial: nextExecutionTime = firstExecutionTime
After each execution: nextExecutionTime = lastExecutionTime + intervalMs
```
- Execute at regular intervals
- After each execution, calculate next execution time
- Keep repeating until cancelled

---

## Execution Flow

### Step 1: Task Submission
```java
// Immediate task
submitTask("task1", HIGH, 1000)
→ nextExecutionTime = null → goes to pending queue

// Scheduled task (run after 5 seconds)
scheduleTaskWithDelay("task2", MEDIUM, 1000, 5000)
→ nextExecutionTime = currentTime + 5000 → goes to scheduled queue

// Recurring task (run every 10 seconds)
submitRecurringTask("task3", LOW, 1000, 10000)
→ nextExecutionTime = currentTime + 10000 → goes to scheduled queue
```

### Step 2: Scheduled Task Checker (Background Thread)
```java
while (running) {
    // Every 100-500ms, check for ready tasks
    long currentTime = System.currentTimeMillis();
    
    // Fetch all tasks where nextExecutionTime <= currentTime
    List<Task> readyTasks = scheduledQueue.getReadyTasks(currentTime);
    
    // Move them to pending queue
    for (Task task : readyTasks) {
        pendingQueue.add(task);
    }
    
    Thread.sleep(100); // Check every 100ms
}
```

### Step 3: Main Scheduler (Assigns Tasks to Workers)
```java
while (running) {
    // Get highest priority task from pending queue
    Task task = pendingQueue.poll();
    
    if (task != null) {
        // Find available worker
        Worker worker = workerPool.getAvailableWorker();
        
        if (worker != null) {
            // Assign task to worker
            worker.executeTask(task);
        }
    }
}
```

### Step 4: Task Execution
```java
// Worker executes the task
void executeTask(Task task) {
    task.setStatus(RUNNING);
    task.setStartedAt(System.currentTimeMillis());
    
    // Simulate execution
    Thread.sleep(task.getExecutionTimeMs());
    
    // Simulate 10% failure
    if (Math.random() < 0.1) {
        task.setStatus(FAILED);
    } else {
        task.setStatus(COMPLETED);
    }
    
    task.setCompletedAt(System.currentTimeMillis());
    
    // Handle recurring tasks
    if (task.isRecurring()) {
        handleRecurringTask(task);
    }
}
```

### Step 5: Recurring Task Rescheduling
```java
void handleRecurringTask(Task task) {
    // Update last execution time
    task.setLastExecutionTime(System.currentTimeMillis());
    
    // Calculate next execution time
    long nextExecTime = task.getLastExecutionTime() + task.getIntervalMs();
    task.setNextExecutionTime(nextExecTime);
    
    // Reset status and re-add to scheduled queue
    task.setStatus(SCHEDULED);
    scheduledQueue.add(task);
    
    // Note: We keep the same task object, just update its nextExecutionTime
}
```

---

## Data Structures

### Pending Queue (Priority-based)
```java
PriorityBlockingQueue<Task> pendingQueue;
// Comparator: priority (HIGH > MEDIUM > LOW), then FIFO
```
- Contains tasks ready to execute NOW
- Ordered by priority

### Scheduled Queue (Time-based)
```java
PriorityQueue<Task> scheduledQueue;
// Comparator: nextExecutionTime (earliest first)
```
- Contains tasks waiting for their execution time
- Ordered by `nextExecutionTime`
- Efficiently fetch tasks where `nextExecutionTime <= currentTime`

### All Tasks Map
```java
ConcurrentHashMap<String, Task> allTasks;
```
- Quick lookup by taskId
- Track all tasks regardless of status

---

## Example Timeline

```
Time: 0ms
- Submit immediate task T1 (priority: HIGH)
  → nextExecutionTime = null → pending queue
  
- Schedule task T2 to run at 5000ms (priority: MEDIUM)
  → nextExecutionTime = 5000 → scheduled queue
  
- Submit recurring task T3, interval 10000ms (priority: LOW)
  → nextExecutionTime = 10000 → scheduled queue

Time: 100ms
- Scheduler assigns T1 to Worker1
- T1 starts executing

Time: 1100ms
- T1 completes (execution time was 1000ms)
- Worker1 becomes IDLE

Time: 5000ms
- Scheduled task checker runs
- Finds T2 (nextExecutionTime = 5000 <= currentTime = 5000)
- Moves T2 to pending queue

Time: 5100ms
- Scheduler assigns T2 to Worker1
- T2 starts executing

Time: 6100ms
- T2 completes
- Worker1 becomes IDLE

Time: 10000ms
- Scheduled task checker runs
- Finds T3 (nextExecutionTime = 10000 <= currentTime = 10000)
- Moves T3 to pending queue

Time: 10100ms
- Scheduler assigns T3 to Worker1
- T3 starts executing

Time: 11100ms
- T3 completes
- Since T3 is recurring:
  - lastExecutionTime = 11100
  - nextExecutionTime = 11100 + 10000 = 21100
  - status = SCHEDULED
  - Re-add to scheduled queue

Time: 21100ms
- Scheduled task checker runs
- Finds T3 again (nextExecutionTime = 21100 <= currentTime = 21100)
- Moves T3 to pending queue
- ... cycle repeats
```

---

## Key Benefits

1. **Efficient Lookup**: Scheduled queue sorted by `nextExecutionTime` allows quick fetching of ready tasks
2. **Single Task Object**: Recurring tasks reuse the same object, just update `nextExecutionTime`
3. **Separation of Concerns**: 
   - Scheduled queue: time-based ordering
   - Pending queue: priority-based ordering
4. **Scalability**: Can handle thousands of scheduled/recurring tasks efficiently
5. **Precision**: Check every 100ms for tasks ready to execute

---

## Implementation Tips

1. Use `DelayQueue<Task>` for scheduled queue (built-in support for time-based retrieval)
2. Make Task implement `Delayed` interface for DelayQueue
3. Use `PriorityBlockingQueue<Task>` for pending queue
4. Always use `System.currentTimeMillis()` for consistency
5. Handle edge cases:
   - Task scheduled in the past (execute immediately)
   - Recurring task execution takes longer than interval
   - Cancelled recurring tasks (remove from scheduled queue)

