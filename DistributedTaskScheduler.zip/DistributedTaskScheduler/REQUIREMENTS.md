# Distributed Task Scheduler - Requirements

## Overview
Build a distributed task scheduler system that manages and executes tasks across multiple worker nodes with priority-based scheduling and fault tolerance.

---

## Functional Requirements

### 1. Task Management

#### 1.1 Task Creation
- Create tasks with unique ID, name/description, and execution logic
- Each task must have a priority level: `HIGH`, `MEDIUM`, `LOW`
- Task execution time should be configurable (for simulation)
- Support three types of tasks:
  - **Immediate tasks**: Execute as soon as worker is available
  - **Scheduled tasks**: Execute at a specific time or after a delay
  - **Recurring tasks**: Execute periodically at fixed intervals
- Task fields:
  - `nextExecutionTime` (Long) - timestamp when task should execute next (null for immediate tasks)
  - `isRecurring` (boolean) - whether task repeats
  - `intervalMs` (Long, optional) - interval between executions for recurring tasks
  - `lastExecutionTime` (Long, optional) - timestamp of last execution (for recurring tasks)

#### 1.2 Task States
Tasks must transition through the following states:
- `PENDING` - Task submitted but not yet assigned
- `SCHEDULED` - Task assigned to a worker
- `RUNNING` - Task currently executing
- `COMPLETED` - Task finished successfully
- `FAILED` - Task execution failed

#### 1.3 Task Operations
- `submitTask(taskId, priority, executionTimeMs)` - Submit an immediate task
- `scheduleTask(taskId, priority, executionTimeMs, scheduledTime)` - Submit a scheduled task
- `scheduleTaskWithDelay(taskId, priority, executionTimeMs, delayMs)` - Submit task with delay
- `submitRecurringTask(taskId, priority, executionTimeMs, intervalMs)` - Submit recurring task
- `submitRecurringTaskWithDelay(taskId, priority, executionTimeMs, initialDelayMs, intervalMs)` - Recurring with initial delay
- `getTaskStatus(taskId)` - Query current status of a task
- `listTasksByStatus(status)` - Get all tasks with a specific status
- `cancelTask(taskId)` - Cancel a pending/scheduled/recurring task
- `cancelRecurringTask(taskId)` - Stop recurring task from creating new instances

---

### 2. Worker Management

#### 2.1 Worker Registration
- `registerWorker(workerId)` - Add a new worker to the pool
- `deregisterWorker(workerId)` - Remove a worker from the pool
- Each worker can execute one task at a time

#### 2.2 Worker States
- `IDLE` - Worker available for task assignment
- `BUSY` - Worker currently executing a task
- `OFFLINE` - Worker disconnected or unavailable

#### 2.3 Worker Operations
- `getWorkerStatus(workerId)` - Get current status of a worker
- `listAvailableWorkers()` - Get all idle workers
- Workers should execute tasks asynchronously

---

### 3. Scheduler

#### 3.1 Task Assignment
- Automatically assign pending tasks to available workers
- Use priority-based scheduling: `HIGH > MEDIUM > LOW`
- Within same priority, use FIFO (First In First Out)
- **Scheduled/Recurring tasks**: Only assign to workers when `currentTime >= nextExecutionTime`
- Periodically query all tasks where `nextExecutionTime <= currentTime` and move them to pending queue
- Use efficient data structure (e.g., `DelayQueue` or sorted queue by `nextExecutionTime`) for quick lookup

#### 3.2 Load Balancing
- Distribute tasks evenly across available workers
- Use round-robin or least-loaded strategy

#### 3.3 Scheduling Policies
- Non-preemptive: Running tasks cannot be interrupted
- Fair scheduling: Prevent starvation of low-priority tasks (optional)

---

### 4. Task Execution

#### 4.1 Execution Flow
1. Scheduler assigns task to idle worker (only if `currentTime >= nextExecutionTime`)
2. Worker updates task status to `RUNNING`
3. Worker executes task (simulate with `Thread.sleep`)
4. Worker updates status to `COMPLETED` or `FAILED`
5. **For recurring tasks**: After completion:
   - Update `lastExecutionTime = currentTime`
   - Calculate `nextExecutionTime = currentTime + intervalMs`
   - Reset status to `SCHEDULED` and re-add to scheduled queue
6. Worker becomes `IDLE` again

#### 4.2 Failure Simulation
- Simulate random task failures (10% failure rate)
- Failed tasks should update status appropriately
- **Recurring tasks**: Continue scheduling next instance even if current execution fails

---

### 5. Retry Mechanism (Bonus)

- Automatically retry failed tasks
- Maximum retry attempts: 2
- Track retry count per task
- Optional: Exponential backoff between retries

---

### 6. Task Dependencies (Bonus)

- Support task dependencies: Task B depends on Task A
- Dependent tasks execute only after parent completes successfully
- Handle dependency chains: A → B → C

---

### 7. Metrics and Monitoring (Bonus)

- Total tasks submitted
- Total tasks completed
- Total tasks failed
- Average task execution time
- Worker utilization percentage
- Current queue size

---

## Non-Functional Requirements

### 1. Concurrency
- System must be thread-safe
- Support concurrent task submissions
- Support multiple workers executing tasks simultaneously
- Use appropriate synchronization mechanisms

### 2. Performance
- Handle at least 100+ tasks
- Support 5-10 concurrent workers
- Minimal scheduling latency (<100ms)

### 3. Scalability
- Easy to add/remove workers dynamically
- Queue should handle growing number of tasks

### 4. Reliability
- No task should be lost
- Handle worker failures gracefully
- Ensure task state consistency

---

## Technical Constraints

### Language & Framework
- Java (use concurrent utilities from `java.util.concurrent`)
- No external frameworks (Spring, etc.)
- Standard library only

### Data Structures
- Use thread-safe collections: `ConcurrentHashMap`, `PriorityBlockingQueue`, etc.
- Use `ExecutorService` or `ThreadPool` for worker management

### Design Principles
- Follow OOP principles
- Clean separation of concerns
- Extensible design for future enhancements

---

## Expected Deliverables

### Core Classes
1. **Task** - Model representing a task
2. **Worker** - Executes tasks asynchronously
3. **TaskScheduler** - Core scheduling logic
4. **DistributedTaskScheduler** - Main API/Facade

### Demo Application
- Driver code demonstrating:
  - Submitting 10-15 tasks with different priorities
  - Registering 3-5 workers
  - Tasks being executed concurrently
  - Status queries and monitoring
  - Failure scenarios

### Testing
- Handle edge cases (no workers, no tasks, etc.)
- Demonstrate priority scheduling
- Show concurrent execution
- Verify thread-safety

---

## Success Criteria

✅ Tasks are executed based on priority
✅ Multiple workers execute tasks concurrently
✅ Thread-safe implementation with no race conditions
✅ Proper state transitions for tasks and workers
✅ Clean, readable, and well-structured code
✅ Working demo showing all core features

