# Distributed Task Scheduler - Phased Implementation Plan

## Phase 1: Foundation & Models (15-20 minutes)
**Goal:** Create basic data models and enums

### Tasks:
1. Create `TaskPriority` enum (HIGH, MEDIUM, LOW)
2. Create `TaskStatus` enum (PENDING, SCHEDULED, RUNNING, COMPLETED, FAILED)
3. Create `WorkerStatus` enum (IDLE, BUSY, OFFLINE)
4. Create `Task` class with:
   - Fields: taskId, priority, status, executionTimeMs, createdAt, startedAt, completedAt
   - Fields for scheduling: `nextExecutionTime` (Long, nullable - null means immediate execution)
   - Fields for recurring: isRecurring (boolean), intervalMs (Long, nullable), lastExecutionTime (Long)
   - Constructor and getters/setters (multiple constructors for different task types)
   - Method to update status
   - Method: `isReadyToExecute()` - checks if `System.currentTimeMillis() >= nextExecutionTime`
   - Method: `scheduleNextExecution()` - for recurring tasks, updates `nextExecutionTime = currentTime + intervalMs`
5. Create `Worker` class skeleton with:
   - Fields: workerId, status, currentTask
   - Constructor and basic getters/setters

### Deliverables:
- [ ] `TaskPriority.java`
- [ ] `TaskStatus.java`
- [ ] `WorkerStatus.java`
- [ ] `Task.java`
- [ ] `Worker.java` (basic structure)

### Validation:
- All classes compile
- Can create Task and Worker objects
- Enums have all required values

---

## Phase 2: Task Storage & Repository (15-20 minutes)
**Goal:** Implement thread-safe task storage with query-based fetching (distributed approach)

### Tasks:
1. Create `TaskDb` class (repository pattern):
   - `ConcurrentHashMap<String, Task>` for all tasks (single source of truth)
   - Method: `addTask(Task task)` - add new task, auto-generate ID if needed
   - Method: `getTask(String taskId)` - retrieve task by ID
   - Method: `updateTask(Task task)` - update existing task
   - Method: `fetchTasksToExecute(Long currentTime)` - fetch tasks ready to execute
2. Implement `fetchTasksToExecute()` logic:
   - Filter: `status == PENDING`
   - Filter: `nextExecutionTime == null OR nextExecutionTime <= currentTime`
   - Sort: Priority (HIGH → MEDIUM → LOW), then FIFO (by createdAt)
   - Return sorted list
3. Use Singleton pattern for TaskDb (simulates single database instance)
4. Ensure thread-safety with ConcurrentHashMap

### Deliverables:
- [ ] `TaskDb.java` in `repo` package
- [ ] `addTask()`, `getTask()`, `updateTask()` methods
- [ ] `fetchTasksToExecute()` with filtering and sorting
- [ ] Singleton pattern implementation

### Validation:
- Tasks are fetched based on time (immediate + scheduled tasks ready to run)
- Fetched tasks are ordered by priority (HIGH → MEDIUM → LOW)
- Within same priority, FIFO order is maintained
- Thread-safe operations work correctly
- Can query tasks by ID

---

## Phase 3: Task Service Layer (10-15 minutes)
**Goal:** Create service layer to abstract business logic

### Tasks:
1. Create `TaskService` class:
   - Reference to `TaskDb`
   - Method: `addTask(Task task)` - delegates to TaskDb
   - Method: `getTask(String taskId)` - delegates to TaskDb
   - Method: `fetchTasksToExecute(Long currentTime)` - delegates to TaskDb
   - Use Singleton pattern
2. This layer can add business logic, validation, etc. in the future

### Deliverables:
- [ ] `TaskService.java` in `service` package
- [ ] Delegation methods to TaskDb
- [ ] Singleton pattern

### Validation:
- TaskService correctly delegates to TaskDb
- Can fetch tasks through service layer

---

## Phase 4: Cron Service (Scheduler) (20-25 minutes)
**Goal:** Implement the scheduler that continuously fetches and executes tasks

### Tasks:
1. Create `CronService` class:
   - Reference to `TaskService` and `TaskDb`
   - Boolean flag: `isRunning`
   - Method: `start()` - starts the scheduling loop
   - Method: `stop()` - stops the scheduler
   - Use Singleton pattern
2. Implement scheduling loop in `start()`:
   - While `isRunning == true`:
     - Fetch tasks ready to execute: `taskService.fetchTasksToExecute(currentTime)`
     - For each task:
       - Set status to RUNNING
       - Set `startedAt` timestamp
       - Execute `task.getTaskLogic().run()`
       - Set status to COMPLETED or FAILED (with try-catch)
       - Set `completedAt` timestamp
       - If recurring task: call `scheduleNextExecution()` and reset status to PENDING
       - Update task in database
     - Sleep for 100-500ms before next iteration
3. Handle exceptions during task execution
4. Handle recurring task rescheduling

### Deliverables:
- [ ] `CronService.java` in `service` package
- [ ] Continuous scheduling loop with sleep
- [ ] Task execution logic
- [ ] Recurring task rescheduling
- [ ] Exception handling

### Validation:
- Scheduler runs in background continuously
- Tasks are fetched based on time and priority
- Tasks execute their logic
- Recurring tasks are rescheduled after completion
- Failed tasks are marked as FAILED
- Scheduler can be stopped gracefully

---

## Phase 5: Worker Pool & Async Execution (20-25 minutes)
**Goal:** Add worker pool for concurrent task execution

### Tasks:
1. Create `WorkerPool` class:
   - `ExecutorService` thread pool (fixed size, e.g., 5 workers)
   - Method: `submitTask(Task task)` - submits task to thread pool for async execution
   - Method: `shutdown()` - gracefully shutdown thread pool
   - Use Singleton pattern
2. Create worker execution logic:
   - Wrap task execution in a `Runnable` or `Callable`
   - Set task status to RUNNING
   - Set `startedAt` timestamp
   - Execute `task.getTaskLogic().run()`
   - Set `completedAt` timestamp
   - Set status to COMPLETED or FAILED
   - Handle recurring task rescheduling
   - Update task in database
3. Integrate WorkerPool with CronService:
   - Instead of executing tasks synchronously in CronService
   - Submit tasks to WorkerPool for async execution
4. Optional: Add failure simulation (10% random failure)

### Deliverables:
- [ ] `WorkerPool.java` in `service` package
- [ ] ExecutorService thread pool
- [ ] Async task execution logic
- [ ] Integration with CronService

### Validation:
- Multiple tasks execute concurrently
- Task status transitions correctly
- Thread pool manages worker threads
- Graceful shutdown works

---

## Phase 6: Main API & Facade (10-15 minutes)
**Goal:** Create user-facing API

### Tasks:
1. Create `DistributedTaskScheduler` class (main facade):
   - Initialize TaskDb, TaskService, CronService, WorkerPool
   - Method: `submitTask(taskId, priority, taskLogic)` - immediate task
   - Method: `scheduleTask(taskId, priority, taskLogic, scheduledTime)` - scheduled task
   - Method: `scheduleTaskWithDelay(taskId, priority, taskLogic, delayMs)` - delayed task
   - Method: `submitRecurringTask(taskId, priority, taskLogic, intervalMs)` - recurring task
   - Method: `submitRecurringTaskWithDelay(taskId, priority, taskLogic, initialDelayMs, intervalMs)`
   - Method: `cancelTask(taskId)` - cancel/stop task
   - Method: `getTaskStatus(taskId)` - get task status
   - Method: `getAllTasks()` - get all tasks
   - Method: `start()` - start the scheduler
   - Method: `shutdown()` - graceful shutdown
2. Wire all components together
3. Create appropriate Task objects (OneTimeTask, RecurringTask) based on method called

### Deliverables:
- [ ] `DistributedTaskScheduler.java`
- [ ] All public API methods
- [ ] Component initialization and wiring

### Validation:
- Can submit immediate tasks via API
- Can schedule tasks via API
- Can submit recurring tasks via API
- Can query task status
- System starts and stops cleanly

---

## Phase 7: Demo & Testing (10-15 minutes)
**Goal:** Create comprehensive demo and test edge cases

### Tasks:
1. Create `Main.java` or `Demo.java`:
   - Initialize DistributedTaskScheduler
   - Submit 5-10 immediate tasks with different priorities
   - Submit 2-3 scheduled tasks (with delay)
   - Submit 1-2 recurring tasks
   - Start the scheduler
   - Wait for tasks to execute
   - Query and display task statuses
   - Shutdown gracefully
2. Test scenarios:
   - HIGH priority tasks execute before MEDIUM/LOW
   - Scheduled tasks execute at correct time
   - Recurring tasks execute multiple times
   - Failed tasks are handled correctly
   - Task status transitions are correct

### Deliverables:
- [ ] `Main.java` or `Demo.java`
- [ ] Comprehensive test scenarios
- [ ] Console output showing execution

### Validation:
- Demo runs without errors
- Priority scheduling works correctly
- Scheduled tasks execute at right time
- Recurring tasks repeat correctly
- Clean shutdown

---

## Phase 8: Bonus Features (If Time Permits)

### Option A: Worker Pool with Actual Workers (15-20 minutes)
1. Create `Worker` class that tracks individual worker state
2. Create `WorkerPool` to manage multiple workers
3. Track worker status (IDLE, BUSY, OFFLINE)
4. Assign tasks to specific workers
5. Display which worker executed which task

### Option B: Retry Mechanism (10-15 minutes)
1. Add `retryCount` and `maxRetries` fields to Task
2. Modify execution logic to retry failed tasks (max 2 retries)
3. Re-queue failed tasks with retry count incremented

### Option C: Task Dependencies (15-20 minutes)
1. Add `dependsOn` field to Task (list of task IDs)
2. Modify fetchTasksToExecute to check dependencies
3. Only fetch tasks whose dependencies are COMPLETED

### Option D: Metrics & Monitoring (10-15 minutes)
1. Create `MetricsCollector` class
2. Track: total submitted, completed, failed, avg execution time
3. Add `getMetrics()` method to main API
4. Display metrics in demo

---

## Quick Reference: Time Allocation

| Phase | Time | Cumulative |
|-------|------|------------|
| Phase 1: Models | 15-20 min | 20 min |
| Phase 2: TaskDb (Repository) | 15-20 min | 40 min |
| Phase 3: TaskService | 10-15 min | 55 min |
| Phase 4: CronService (Scheduler) | 20-25 min | 80 min |
| Phase 5: WorkerPool (Optional) | 20-25 min | 105 min |
| Phase 6: Main API | 10-15 min | 120 min |
| Phase 7: Demo | 10-15 min | 135 min |
| **Buffer/Bonus** | 15-25 min | 150-160 min |

**For 60-minute LLD round:** Focus on design, class diagrams, API design
**For 90-minute round:** Complete Phases 1-4, 6-7 (skip WorkerPool, execute synchronously)
**For 120-minute round:** Complete Phases 1-7, add WorkerPool for async execution
**For 150-minute round:** Complete all phases + one bonus feature

---

## Tips for Success

1. **Start Simple:** Get basic functionality working before adding complexity
2. **Test Incrementally:** Test each phase before moving to the next
3. **Use Print Statements:** Add logging to see what's happening
4. **Thread Safety First:** Use concurrent collections from the start
5. **Don't Over-Engineer:** Focus on working code over perfect design
6. **Time Management:** If stuck on one phase >10 min, move on and come back

---

## Checklist for Completion

- [ ] All core classes implemented
- [ ] Thread-safe operations
- [ ] Priority-based scheduling works
- [ ] Multiple workers execute concurrently
- [ ] Task state transitions correctly
- [ ] Demo shows all features
- [ ] Code is clean and readable
- [ ] No compilation errors
- [ ] Graceful shutdown implemented

