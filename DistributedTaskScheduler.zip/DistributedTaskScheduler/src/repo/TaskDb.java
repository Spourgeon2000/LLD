package repo;

import data.Task;
import data.TaskStatus;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TaskDb {
    private static TaskDb instance;

    public static TaskDb getInstance() {
        if (instance == null) {
            instance = new TaskDb();
        }
        return instance;
    }

    private TaskDb() {
    }

    public Map<String, Task> tasks = new ConcurrentHashMap<>();

    public static void setInstance(TaskDb instance) {
        TaskDb.instance = instance;
    }

    public Map<String, Task> getTasks() {
        return tasks;
    }

    public void setTasks(Map<String, Task> tasks) {
        this.tasks = tasks;
    }

    public Task addTask(Task task) {
        if (task.getTaskId() == null || task.getTaskId().isEmpty()) {
            task.setTaskId("task_" + System.currentTimeMillis());
        }
        tasks.put(task.getTaskId(), task);
        return task;
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    public Task updateTask(Task task) {
        tasks.put(task.getTaskId(), task);
        return task;
    }

    public List<Task> fetchTasksToExecute(Long currentTime) {

        List<Task> allTasks = new ArrayList<>(tasks.values());
        return allTasks.stream()
                .filter(task -> task.getStatus() == TaskStatus.PENDING)
                .filter(task -> {
                    Long nextExecutionTime = task.getNextExecutionTime();
                    if (nextExecutionTime == null) {
                        return true;
                    }
                    return currentTime >= nextExecutionTime;
                })
                // FAANG Feature: Check task dependencies (DAG support)
                // Note: We'll check dependencies in TaskService to avoid circular dependency
                .sorted(Comparator.comparing(Task::getPriority).reversed()
                        .thenComparing(Task::getCreatedAt))
                .toList();
    }

}
