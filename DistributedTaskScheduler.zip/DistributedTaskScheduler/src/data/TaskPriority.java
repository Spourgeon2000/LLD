package data;

public enum TaskPriority {
    HIGH,
    MEDIUM,
    LOW
}
