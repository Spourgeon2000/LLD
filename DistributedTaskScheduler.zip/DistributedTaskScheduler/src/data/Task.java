package data;

import repo.TaskDb;
import java.util.ArrayList;
import java.util.List;

public abstract class Task {
    private String taskId;
    private TaskPriority priority;
    private TaskStatus status;
    private TaskType taskType;
    private Runnable taskLogic;
    private Long createdAt;
    private Long startedAt;
    private Long completedAt;
    private int retryCount = 0;
    private int maxRetries = 3;
    private Long lastFailureTime;

    // FAANG Feature 1: Task Dependencies (DAG support)
    private List<String> dependsOn = new ArrayList<>();

    // FAANG Feature 2: Heartbeat & Timeout Detection
    private Long claimedAt;
    private Long lastHeartbeat;
    private static final long TASK_TIMEOUT_MS = 30000; // 30 seconds

    // FAANG Feature 3: Execution tracking
    private String executedBy; // Which worker/scheduler executed this

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public int getMaxRetries() {
        return maxRetries;
    }

    public void setMaxRetries(int maxRetries) {
        this.maxRetries = maxRetries;
    }

    public Long getLastFailureTime() {
        return lastFailureTime;
    }

    public void setLastFailureTime(Long lastFailureTime) {
        this.lastFailureTime = lastFailureTime;
    }

    // Constructor
    public Task() {
        this.createdAt = System.currentTimeMillis();
        this.status = TaskStatus.PENDING;
    }

    public Task(String taskId, TaskPriority priority, Runnable taskLogic) {
        this.taskId = taskId;
        this.priority = priority;
        this.taskLogic = taskLogic;
        this.createdAt = System.currentTimeMillis();
        this.status = TaskStatus.PENDING;
    }
    // Abstract method to get the next execution time (for scheduling)
    // Returns null for immediate tasks
    public abstract Long getNextExecutionTime();

    // Getters and Setters
    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public TaskPriority getPriority() {
        return priority;
    }

    public void setPriority(TaskPriority priority) {
        this.priority = priority;
    }

    public TaskStatus getStatus() {
        return status;
    }

    public void setStatus(TaskStatus status) {
        this.status = status;
    }

    public TaskType getTaskType() {
        return taskType;
    }

    public void setTaskType(TaskType taskType) {
        this.taskType = taskType;
    }

    public Runnable getTaskLogic() {
        return taskLogic;
    }

    public void setTaskLogic(Runnable taskLogic) {
        this.taskLogic = taskLogic;
    }

    public Long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Long createdAt) {
        this.createdAt = createdAt;
    }

    public Long getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(Long startedAt) {
        this.startedAt = startedAt;
    }

    public Long getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(Long completedAt) {
        this.completedAt = completedAt;
    }

    // FAANG Feature 1: Task Dependencies
    public List<String> getDependsOn() {
        return dependsOn;
    }

    public void setDependsOn(List<String> dependsOn) {
        this.dependsOn = dependsOn;
    }

    // Removed areDependenciesMet - moved to TaskService (better separation of concerns)

    // FAANG Feature 2: Heartbeat & Timeout Detection
    public Long getClaimedAt() {
        return claimedAt;
    }

    public void setClaimedAt(Long claimedAt) {
        this.claimedAt = claimedAt;
    }

    public Long getLastHeartbeat() {
        return lastHeartbeat;
    }

    public void setLastHeartbeat(Long lastHeartbeat) {
        this.lastHeartbeat = lastHeartbeat;
    }

    public boolean isTimedOut() {
        if (status == TaskStatus.RUNNING && lastHeartbeat != null) {
            return System.currentTimeMillis() - lastHeartbeat > TASK_TIMEOUT_MS;
        }
        if (status == TaskStatus.CLAIMED && claimedAt != null) {
            return System.currentTimeMillis() - claimedAt > TASK_TIMEOUT_MS;
        }
        return false;
    }

    // FAANG Feature 3: Execution tracking
    public String getExecutedBy() {
        return executedBy;
    }

    public void setExecutedBy(String executedBy) {
        this.executedBy = executedBy;
    }
}
