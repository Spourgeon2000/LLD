package data;

public enum TaskType {
    RECURRING,
    ONE_TIME
}
