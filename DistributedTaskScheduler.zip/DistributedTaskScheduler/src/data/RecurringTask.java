package data;

public class RecurringTask extends Task {
    private Long nextExecutionTime;
    private Long lastExecutionTime;
    private Long intervalMs;

    public RecurringTask() {
        super();
        this.setTaskType(TaskType.RECURRING);
    }

    public RecurringTask(String taskId, TaskPriority priority, Runnable taskLogic, Long intervalMs) {
        super(taskId, priority, taskLogic);
        this.intervalMs = intervalMs;
        this.nextExecutionTime = System.currentTimeMillis();
        this.setTaskType(TaskType.RECURRING);
    }

    public RecurringTask(String taskId, TaskPriority priority, Runnable taskLogic, Long intervalMs, Long initialDelay) {
        super(taskId, priority, taskLogic);
        this.intervalMs = intervalMs;
        this.nextExecutionTime = System.currentTimeMillis() + initialDelay;
        this.setTaskType(TaskType.RECURRING);
    }

    public void scheduleNextExecution() {
        this.lastExecutionTime = System.currentTimeMillis();
        this.nextExecutionTime = this.lastExecutionTime + this.intervalMs;
    }

    public Long getNextExecutionTime() {
        return nextExecutionTime;
    }

    public void setNextExecutionTime(Long nextExecutionTime) {
        this.nextExecutionTime = nextExecutionTime;
    }

    public Long getLastExecutionTime() {
        return lastExecutionTime;
    }

    public void setLastExecutionTime(Long lastExecutionTime) {
        this.lastExecutionTime = lastExecutionTime;
    }

    public Long getIntervalMs() {
        return intervalMs;
    }

    public void setIntervalMs(Long intervalMs) {
        this.intervalMs = intervalMs;
    }
}
