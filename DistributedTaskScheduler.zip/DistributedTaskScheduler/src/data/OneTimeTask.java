package data;

public class OneTimeTask extends Task {
    private Long scheduledTime; 
    
    public OneTimeTask() {
        super();
        this.scheduledTime = null;
        this.setTaskType(TaskType.ONE_TIME);
    }
    
    public OneTimeTask(String taskId, TaskPriority priority, Runnable taskLogic) {
        super(taskId, priority, taskLogic);
        this.scheduledTime = null;
        this.setTaskType(TaskType.ONE_TIME);
    }
    
    public OneTimeTask(String taskId, TaskPriority priority, Runnable taskLogic, Long scheduledTime) {
        super(taskId, priority, taskLogic);
        this.scheduledTime = scheduledTime;
        this.setTaskType(TaskType.ONE_TIME);
    }

    @Override
    public Long getNextExecutionTime() {
        return scheduledTime; // Returns scheduledTime (null for immediate tasks)
    }

    public Long getScheduledTime() {
        return scheduledTime;
    }

    public void setScheduledTime(Long scheduledTime) {
        this.scheduledTime = scheduledTime;
    }
}
