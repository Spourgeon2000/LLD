package data;

public enum WorkerStatus {
    IDLE,
    BUSY,
    OFFLINE
}
