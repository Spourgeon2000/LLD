package data;

public enum TaskStatus {
    PENDING,      // Task created, waiting to be picked
    CLAIMED,      // Task picked by scheduler (prevents duplicate execution)
    RUNNING,      // Task executing on worker
    COMPLETED,    // Task finished successfully
    FAILED,       // Task failed
    CANCELLED,    // Task cancelled by user
    DEAD_LETTER   // Task failed after max retries
}
