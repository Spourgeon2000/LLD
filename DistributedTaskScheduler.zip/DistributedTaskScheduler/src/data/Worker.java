package data;

public class Worker {
    private String workerId;
    private WorkerStatus status;
    private Task currentTask;

    public Worker() {
        this.status = WorkerStatus.IDLE;
    }

    public Worker(String workerId) {
        this.workerId = workerId;
        this.status = WorkerStatus.IDLE;
    }

    public String getWorkerId() {
        return workerId;
    }

    public void setWorkerId(String workerId) {
        this.workerId = workerId;
    }

    public WorkerStatus getStatus() {
        return status;
    }

    public void setStatus(WorkerStatus status) {
        this.status = status;
    }

    public Task getCurrentTask() {
        return currentTask;
    }

    public void setCurrentTask(Task currentTask) {
        this.currentTask = currentTask;
    }
}
