package service;

import data.Task;
import data.TaskStatus;
import repo.TaskDb;

import java.util.ArrayList;
import java.util.List;

public class TaskService {

    private static TaskService instance = null;

    private TaskService() {
    }

    public static TaskService getInstance() {
        if (instance == null) {
            instance = new TaskService();
        }
        return instance;
    }

    TaskDb taskDb = TaskDb.getInstance();

    public List<Task> fetchTasksToExecute(Long currentTime) {
        return taskDb.fetchTasksToExecute(currentTime);
    }

    public void updateTask(Task task) {
        taskDb.updateTask(task);
    }

    public List<Task> getAllTasks() {
        return new ArrayList<>(taskDb.tasks.values());
    }

    /**
     * FAANG Feature: Check if task dependencies are met (DAG support)
     * This belongs in the SERVICE layer, not the DATA layer!
     */
    public boolean areDependenciesMet(Task task) {
        List<String> dependsOn = task.getDependsOn();

        if (dependsOn == null || dependsOn.isEmpty()) {
            return true;
        }

        for (String depTaskId : dependsOn) {
            Task depTask = taskDb.getTask(depTaskId);
            if (depTask == null || depTask.getStatus() != TaskStatus.COMPLETED) {
                return false; // Dependency not met
            }
        }
        return true;
    }
}
