package service;

import data.Task;
import data.TaskStatus;
import repo.TaskDb;

/**
 * FAANG Feature: Heartbeat & Timeout Detection
 * 
 * Monitors running tasks and detects:
 * - Tasks that have timed out (worker crashed or stuck)
 * - Tasks that have been claimed but never started
 * 
 * In production, workers would send heartbeats every few seconds.
 * If heartbeat stops, we assume the worker died and retry the task.
 */
public class HeartbeatService {
    private static HeartbeatService instance = null;
    
    public static HeartbeatService getInstance() {
        if (instance == null) {
            instance = new HeartbeatService();
        }
        return instance;
    }
    
    private TaskDb taskDb = TaskDb.getInstance();
    private MetricsCollector metrics = MetricsCollector.getInstance();
    
    /**
     * Check all tasks for timeouts and recover them
     */
    public void checkTimeouts() {
        taskDb.getTasks().values().stream()
            .filter(Task::isTimedOut)
            .forEach(this::handleTimeout);
    }
    
    /**
     * Handle a timed-out task
     */
    private void handleTimeout(Task task) {
        System.out.println("⏰ [TIMEOUT] Task " + task.getTaskId() + 
                         " timed out in status " + task.getStatus());
        
        metrics.recordTaskTimeout();
        
        // Unlock the task so another scheduler can pick it up
        DistributedLock.unlock(task.getTaskId());
        
        // Increment retry count
        task.setRetryCount(task.getRetryCount() + 1);
        
        if (task.getRetryCount() < task.getMaxRetries()) {
            // Retry with exponential backoff
            long backoffMs = calculateBackoff(task.getRetryCount());
            task.setStatus(TaskStatus.PENDING);
            
            // For OneTimeTask, set nextExecutionTime
            if (task instanceof data.OneTimeTask) {
                ((data.OneTimeTask) task).setScheduledTime(System.currentTimeMillis() + backoffMs);
            }
            // For RecurringTask, set nextExecutionTime
            else if (task instanceof data.RecurringTask) {
                ((data.RecurringTask) task).setNextExecutionTime(System.currentTimeMillis() + backoffMs);
            }
            
            System.out.println("  ↻ Retrying task in " + backoffMs + "ms (attempt " + 
                             task.getRetryCount() + "/" + task.getMaxRetries() + ")");
            metrics.recordTaskRetry();
        } else {
            // Max retries exceeded
            task.setStatus(TaskStatus.DEAD_LETTER);
            System.out.println("  ☠️  Task moved to DEAD_LETTER after " + 
                             task.getMaxRetries() + " retries");
            metrics.recordTaskDeadLetter();
        }
        
        taskDb.updateTask(task);
    }
    
    /**
     * Calculate exponential backoff delay
     * Retry 1: 2 seconds
     * Retry 2: 4 seconds
     * Retry 3: 8 seconds
     */
    private long calculateBackoff(int retryCount) {
        return (long) Math.pow(2, retryCount) * 1000;
    }
    
    /**
     * Simulate a heartbeat from a worker
     * In production, workers would call this every 5-10 seconds
     */
    public void recordHeartbeat(String taskId) {
        Task task = taskDb.getTask(taskId);
        if (task != null) {
            task.setLastHeartbeat(System.currentTimeMillis());
            taskDb.updateTask(task);
        }
    }
}

