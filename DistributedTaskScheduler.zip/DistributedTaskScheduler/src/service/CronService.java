package service;

import data.Task;
import data.TaskStatus;

import java.util.List;

public class CronService {
    private static CronService instance = null;

    private CronService() {
    }

    public static CronService getInstance() {
        if (instance == null) {
            instance = new CronService();
        }
        return instance;
    }

    private volatile boolean isRunning = false;
    private TaskService taskService = TaskService.getInstance();
    private final WorkerPool workerPool = WorkerPool.getInstance(5);
    private final MetricsCollector metrics = MetricsCollector.getInstance();
    private final String schedulerId = "scheduler-" + System.currentTimeMillis(); // Unique ID

    public void start() throws InterruptedException {
        isRunning = true;
        int iteration = 0;

        System.out.println("🚀 [SCHEDULER] Starting with ID: " + schedulerId);

        while (isRunning) {
            // Fetch tasks ready to execute
            List<Task> tasks = taskService.fetchTasksToExecute(System.currentTimeMillis());

            for (Task task : tasks) {
                // FAANG: Check dependencies BEFORE trying to lock (better design!)
                if (!taskService.areDependenciesMet(task)) {
                    continue; // Skip tasks with unmet dependencies
                }

                // FAANG: Distributed Lock - prevent duplicate execution
                if (DistributedLock.tryLock(task.getTaskId(), schedulerId)) {
                    // Successfully claimed the task
                    task.setStatus(TaskStatus.CLAIMED);
                    task.setClaimedAt(System.currentTimeMillis());
                    taskService.updateTask(task);

                    metrics.recordTaskClaimed();

                    // Submit to worker pool
                    workerPool.submitTask(task);
                } else {
                    // Another scheduler already claimed this task
                    metrics.recordDuplicatePrevented();
                }
            }

            // FAANG: Periodically check for timed-out tasks (every 1 second)
            if (iteration++ % 10 == 0) {
                checkTimeouts();
            }

            Thread.sleep(100);
        }

        System.out.println("🛑 [SCHEDULER] Stopped");
    }

    /**
     * FAANG Feature: Check for timed-out tasks and recover them
     */
    private void checkTimeouts() {
        taskService.getAllTasks().stream()
            .filter(Task::isTimedOut)
            .forEach(task -> {
                System.out.println("⏰ [TIMEOUT] Task " + task.getTaskId() +
                                 " timed out, unlocking for retry");
                DistributedLock.unlock(task.getTaskId());
                task.setStatus(TaskStatus.PENDING);
                task.setRetryCount(task.getRetryCount() + 1);
                taskService.updateTask(task);
                metrics.recordTaskTimeout();
            });
    }

    public void stop() {
        isRunning = false;
    }

    public String getSchedulerId() {
        return schedulerId;
    }
}
