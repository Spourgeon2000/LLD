package service;

import java.util.concurrent.atomic.AtomicLong;

/**
 * FAANG Feature: Metrics & Monitoring
 * 
 * In production, this would integrate with:
 * - Prometheus
 * - Datadog
 * - CloudWatch
 * - Grafana
 * 
 * Tracks key performance indicators for the task scheduler.
 */
public class MetricsCollector {
    private static MetricsCollector instance = null;
    
    public static MetricsCollector getInstance() {
        if (instance == null) {
            instance = new MetricsCollector();
        }
        return instance;
    }
    
    private MetricsCollector() {}
    
    // Counters (thread-safe)
    private AtomicLong totalSubmitted = new AtomicLong(0);
    private AtomicLong totalClaimed = new AtomicLong(0);
    private AtomicLong totalCompleted = new AtomicLong(0);
    private AtomicLong totalFailed = new AtomicLong(0);
    private AtomicLong totalRetries = new AtomicLong(0);
    private AtomicLong totalDeadLetters = new AtomicLong(0);
    private AtomicLong totalTimeouts = new AtomicLong(0);
    private AtomicLong totalDuplicatePrevented = new AtomicLong(0);
    
    // Timing
    private AtomicLong totalExecutionTimeMs = new AtomicLong(0);
    
    // Recording methods
    public void recordTaskSubmitted() { 
        totalSubmitted.incrementAndGet(); 
    }
    
    public void recordTaskClaimed() { 
        totalClaimed.incrementAndGet(); 
    }
    
    public void recordTaskCompleted(long executionTimeMs) { 
        totalCompleted.incrementAndGet();
        totalExecutionTimeMs.addAndGet(executionTimeMs);
    }
    
    public void recordTaskFailed() { 
        totalFailed.incrementAndGet(); 
    }
    
    public void recordTaskRetry() { 
        totalRetries.incrementAndGet(); 
    }
    
    public void recordTaskDeadLetter() { 
        totalDeadLetters.incrementAndGet(); 
    }
    
    public void recordTaskTimeout() { 
        totalTimeouts.incrementAndGet(); 
    }
    
    public void recordDuplicatePrevented() {
        totalDuplicatePrevented.incrementAndGet();
    }
    
    // Getters
    public long getTotalSubmitted() { return totalSubmitted.get(); }
    public long getTotalCompleted() { return totalCompleted.get(); }
    public long getTotalFailed() { return totalFailed.get(); }
    public long getTotalRetries() { return totalRetries.get(); }
    
    // Calculated metrics
    public double getSuccessRate() {
        long submitted = totalSubmitted.get();
        if (submitted == 0) return 0.0;
        return (100.0 * totalCompleted.get()) / submitted;
    }
    
    public double getAverageExecutionTimeMs() {
        long completed = totalCompleted.get();
        if (completed == 0) return 0.0;
        return (double) totalExecutionTimeMs.get() / completed;
    }
    
    /**
     * Print comprehensive metrics report
     */
    public void printMetrics() {
        System.out.println("\n" + "=".repeat(70));
        System.out.println("📊 DISTRIBUTED TASK SCHEDULER METRICS");
        System.out.println("=".repeat(70));
        
        System.out.println("\n📈 Task Lifecycle:");
        System.out.println("  Total Submitted:        " + totalSubmitted.get());
        System.out.println("  Total Claimed:          " + totalClaimed.get());
        System.out.println("  Total Completed:        " + totalCompleted.get());
        System.out.println("  Total Failed:           " + totalFailed.get());
        System.out.println("  Total Dead Letters:     " + totalDeadLetters.get());
        
        System.out.println("\n🔄 Reliability:");
        System.out.println("  Total Retries:          " + totalRetries.get());
        System.out.println("  Total Timeouts:         " + totalTimeouts.get());
        System.out.println("  Duplicates Prevented:   " + totalDuplicatePrevented.get());
        
        System.out.println("\n⚡ Performance:");
        System.out.printf("  Success Rate:           %.2f%%\n", getSuccessRate());
        System.out.printf("  Avg Execution Time:     %.2f ms\n", getAverageExecutionTimeMs());
        
        System.out.println("\n🔒 Distributed System:");
        System.out.println("  Active Locks:           " + DistributedLock.getActiveLockCount());
        
        System.out.println("=".repeat(70) + "\n");
    }
    
    /**
     * Reset all metrics (useful for testing)
     */
    public void reset() {
        totalSubmitted.set(0);
        totalClaimed.set(0);
        totalCompleted.set(0);
        totalFailed.set(0);
        totalRetries.set(0);
        totalDeadLetters.set(0);
        totalTimeouts.set(0);
        totalDuplicatePrevented.set(0);
        totalExecutionTimeMs.set(0);
    }
}

