package service;

import data.RecurringTask;
import data.Task;
import data.TaskStatus;
import repo.TaskDb;

import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WorkerPool {
    private static WorkerPool instance = null;

    private WorkerPool() {
    }

    public static WorkerPool getInstance(Integer workers) {
        if (instance == null) {
            instance = new WorkerPool(workers);
        }
        return instance;
    }

    private WorkerPool(Integer workers) {
        this.workers = workers;
        executorService = Executors.newFixedThreadPool(workers);
    }

    Integer workers;
    ExecutorService executorService;
    TaskDb taskDb = TaskDb.getInstance();
    MetricsCollector metrics = MetricsCollector.getInstance(); // FAANG: Metrics

    public void submitTask(Task task) {
        executorService.submit(() -> {
            String workerId = Thread.currentThread().getName();
            long startTime = System.currentTimeMillis();

            try {
                // FAANG: Track execution
                task.setExecutedBy(workerId);
                task.setStatus(TaskStatus.RUNNING);
                task.setStartedAt(startTime);
                task.setLastHeartbeat(startTime);
                taskDb.updateTask(task);

                System.out.println("  ▶️  [EXECUTE] Task " + task.getTaskId() + " on " + workerId);

                // Execute task
                task.getTaskLogic().run();

                // Success
                long endTime = System.currentTimeMillis();
                task.setCompletedAt(endTime);
                task.setStatus(TaskStatus.COMPLETED);
                metrics.recordTaskCompleted(endTime - startTime);

                System.out.println("  ✅ [SUCCESS] Task " + task.getTaskId() +
                                 " completed in " + (endTime - startTime) + "ms");

            } catch (Exception e) {
                // FAANG: Enhanced failure handling
                task.setStatus(TaskStatus.FAILED);
                task.setLastFailureTime(System.currentTimeMillis());
                task.setRetryCount(task.getRetryCount() + 1);
                metrics.recordTaskFailed();

                System.out.println("  ❌ [FAILED] Task " + task.getTaskId() + ": " + e.getMessage());

                if (task.getRetryCount() < task.getMaxRetries()) {
                    // Exponential backoff retry
                    long backoffMs = (long) Math.pow(2, task.getRetryCount()) * 1000;

                    if (task instanceof RecurringTask) {
                        ((RecurringTask) task).setNextExecutionTime(System.currentTimeMillis() + backoffMs);
                    } else if (task instanceof data.OneTimeTask) {
                        ((data.OneTimeTask) task).setScheduledTime(System.currentTimeMillis() + backoffMs);
                    }

                    task.setStatus(TaskStatus.PENDING);
                    metrics.recordTaskRetry();
                    System.out.println("  ↻ [RETRY] in " + backoffMs + "ms (attempt " +
                                     task.getRetryCount() + "/" + task.getMaxRetries() + ")");
                } else {
                    task.setStatus(TaskStatus.DEAD_LETTER);
                    metrics.recordTaskDeadLetter();
                    System.out.println("  ☠️  [DEAD_LETTER] after " + task.getMaxRetries() + " retries");
                }
                e.printStackTrace();

            } finally {
                // FAANG: Always unlock
                DistributedLock.unlock(task.getTaskId());

                // Handle recurring tasks
                if (Objects.equals(task.getStatus(), TaskStatus.COMPLETED)) {
                    if (task instanceof RecurringTask recurringTask) {
                        recurringTask.scheduleNextExecution();
                        recurringTask.setStatus(TaskStatus.PENDING);
                        System.out.println("  🔄 [RECURRING] Rescheduled for " +
                                         recurringTask.getNextExecutionTime());
                    }
                }

                taskDb.updateTask(task);
            }
        });
    }

    public void shutdown() {
        executorService.shutdown();
    }
}
