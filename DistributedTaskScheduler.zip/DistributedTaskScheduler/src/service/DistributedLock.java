package service;

import java.util.concurrent.ConcurrentHashMap;

/**
 * FAANG Feature: Distributed Lock Simulation
 * 
 * In production, this would be implemented using:
 * - Redis SETNX (Set if Not Exists)
 * - Zookeeper
 * - etcd
 * - Database with optimistic locking
 * 
 * This prevents multiple schedulers from picking the same task in a distributed system.
 */
public class DistributedLock {
    // Simulates Redis: key = taskId, value = timestamp when locked
    private static ConcurrentHashMap<String, LockInfo> locks = new ConcurrentHashMap<>();
    private static final long LOCK_TIMEOUT_MS = 30000; // 30 seconds
    
    static class LockInfo {
        String ownerId;
        long timestamp;
        
        LockInfo(String ownerId, long timestamp) {
            this.ownerId = ownerId;
            this.timestamp = timestamp;
        }
    }
    
    /**
     * Try to acquire a lock for a task
     * @param taskId The task to lock
     * @param ownerId The scheduler/worker trying to acquire the lock
     * @return true if lock acquired, false if already locked by someone else
     */
    public static boolean tryLock(String taskId, String ownerId) {
        long now = System.currentTimeMillis();
        
        // Clean up expired locks (simulates Redis TTL)
        locks.entrySet().removeIf(entry -> 
            now - entry.getValue().timestamp > LOCK_TIMEOUT_MS
        );
        
        // Try to acquire lock (atomic operation - simulates Redis SETNX)
        LockInfo existingLock = locks.putIfAbsent(taskId, new LockInfo(ownerId, now));
        
        if (existingLock == null) {
            // Successfully acquired lock
            System.out.println("🔒 [LOCK] Task " + taskId + " locked by " + ownerId);
            return true;
        } else if (existingLock.ownerId.equals(ownerId)) {
            // We already own this lock (re-entrant)
            return true;
        } else {
            // Lock held by someone else
            System.out.println("⏭️  [SKIP] Task " + taskId + " already locked by " + existingLock.ownerId);
            return false;
        }
    }
    
    /**
     * Release a lock
     * @param taskId The task to unlock
     */
    public static void unlock(String taskId) {
        LockInfo removed = locks.remove(taskId);
        if (removed != null) {
            System.out.println("🔓 [UNLOCK] Task " + taskId + " unlocked");
        }
    }
    
    /**
     * Check if a task is currently locked
     */
    public static boolean isLocked(String taskId) {
        return locks.containsKey(taskId);
    }
    
    /**
     * Get lock statistics (for monitoring)
     */
    public static int getActiveLockCount() {
        return locks.size();
    }
}

