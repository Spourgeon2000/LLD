package facade;

import data.OneTimeTask;
import data.RecurringTask;
import data.TaskPriority;
import data.TaskStatus;
import data.TaskType;
import repo.TaskDb;
import service.CronService;
import service.TaskService;
import service.WorkerPool;

public class DistributedTaskScheduler {
    private static DistributedTaskScheduler instance = null;

    private DistributedTaskScheduler() {
    }

    public static DistributedTaskScheduler getInstance() {
        if (instance == null) {
            instance = new DistributedTaskScheduler();
        }
        return instance;
    }

    CronService cronService = CronService.getInstance();
    TaskDb taskDb = TaskDb.getInstance();
    WorkerPool workerPool = WorkerPool.getInstance(5);
    service.MetricsCollector metrics = service.MetricsCollector.getInstance();

    public void submitTask(String taskId, TaskPriority priority, Runnable taskLogic, TaskType taskType) {
        if (taskType == TaskType.ONE_TIME) {
            OneTimeTask task = new OneTimeTask(taskId, priority, taskLogic);
            taskDb.addTask(task);
            metrics.recordTaskSubmitted();
        } else if (taskType == TaskType.RECURRING) {
            RecurringTask task = new RecurringTask(taskId, priority, taskLogic, 10000L);
            taskDb.addTask(task);
            metrics.recordTaskSubmitted();
        }
    }

    public void scheduleTask(String taskId, TaskPriority priority, Runnable taskLogic, Long scheduledTime) {
        OneTimeTask task = new OneTimeTask(taskId, priority, taskLogic, scheduledTime);
        taskDb.addTask(task);
        metrics.recordTaskSubmitted();
    }

    public void scheduleTaskWithDelay(String taskId, TaskPriority priority, Runnable taskLogic, Long delayMs) {
        OneTimeTask task = new OneTimeTask(taskId, priority, taskLogic, System.currentTimeMillis() + delayMs);
        taskDb.addTask(task);
        metrics.recordTaskSubmitted();
    }

    public void submitRecurringTask(String taskId, TaskPriority priority, Runnable taskLogic, Long intervalMs) {
        RecurringTask task = new RecurringTask(taskId, priority, taskLogic, intervalMs);
        taskDb.addTask(task);
        metrics.recordTaskSubmitted();
    }

    public void submitRecurringTaskWithDelay(String taskId, TaskPriority priority, Runnable taskLogic, Long initialDelayMs, Long intervalMs) {
        RecurringTask task = new RecurringTask(taskId, priority, taskLogic, intervalMs, initialDelayMs);
        taskDb.addTask(task);
        metrics.recordTaskSubmitted();
    }

    // FAANG Feature: Submit task with dependencies (DAG support)
    public void submitTaskWithDependencies(String taskId, TaskPriority priority, Runnable taskLogic, java.util.List<String> dependsOn) {
        OneTimeTask task = new OneTimeTask(taskId, priority, taskLogic);
        task.setDependsOn(dependsOn);
        taskDb.addTask(task);
        metrics.recordTaskSubmitted();
    }

    public void cancelTask(String taskId) {
        if(taskDb.getTask(taskId) == null) {
            throw new RuntimeException("Task not found");
        }
        taskDb.getTask(taskId).setStatus(TaskStatus.CANCELLED);
    }

    public TaskStatus getTaskStatus(String taskId) {
        if(taskDb.getTask(taskId) == null) {
            throw new RuntimeException("Task not found");
        }
        return taskDb.getTask(taskId).getStatus();
    }

    public void start() throws InterruptedException {
        cronService.start();
    }

    public void shutdown() {
        cronService.stop();
        workerPool.shutdown();
    }

    public void printMetrics() {
        metrics.printMetrics();
    }
}
