import data.TaskPriority;
import facade.DistributedTaskScheduler;
import repo.TaskDb;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("\n" + "=".repeat(70));
        System.out.println("🚀 DISTRIBUTED TASK SCHEDULER - FAANG EDITION");
        System.out.println("=".repeat(70) + "\n");

        DistributedTaskScheduler scheduler = DistributedTaskScheduler.getInstance();
        TaskDb taskDb = TaskDb.getInstance();

        // ========== Test 1: Immediate Tasks with Different Priorities ==========
        System.out.println("📋 Submitting 8 immediate tasks with different priorities...");

        // HIGH priority tasks (should execute first)
        scheduler.submitTask("task-high-1", TaskPriority.HIGH, () -> {
            System.out.println("  ✅ [HIGH] Task 1 executing on thread: " + Thread.currentThread().getName());
            sleep(500);
        }, data.TaskType.ONE_TIME);

        scheduler.submitTask("task-high-2", TaskPriority.HIGH, () -> {
            System.out.println("  ✅ [HIGH] Task 2 executing on thread: " + Thread.currentThread().getName());
            sleep(500);
        }, data.TaskType.ONE_TIME);

        // MEDIUM priority tasks
        scheduler.submitTask("task-med-1", TaskPriority.MEDIUM, () -> {
            System.out.println("  ✅ [MEDIUM] Task 1 executing on thread: " + Thread.currentThread().getName());
            sleep(500);
        }, data.TaskType.ONE_TIME);

        scheduler.submitTask("task-med-2", TaskPriority.MEDIUM, () -> {
            System.out.println("  ✅ [MEDIUM] Task 2 executing on thread: " + Thread.currentThread().getName());
            sleep(500);
        }, data.TaskType.ONE_TIME);

        scheduler.submitTask("task-med-3", TaskPriority.MEDIUM, () -> {
            System.out.println("  ✅ [MEDIUM] Task 3 executing on thread: " + Thread.currentThread().getName());
            sleep(500);
        }, data.TaskType.ONE_TIME);

        // LOW priority tasks (should execute last)
        scheduler.submitTask("task-low-1", TaskPriority.LOW, () -> {
            System.out.println("  ✅ [LOW] Task 1 executing on thread: " + Thread.currentThread().getName());
            sleep(500);
        }, data.TaskType.ONE_TIME);

        scheduler.submitTask("task-low-2", TaskPriority.LOW, () -> {
            System.out.println("  ✅ [LOW] Task 2 executing on thread: " + Thread.currentThread().getName());
            sleep(500);
        }, data.TaskType.ONE_TIME);

        scheduler.submitTask("task-low-3", TaskPriority.LOW, () -> {
            System.out.println("  ✅ [LOW] Task 3 executing on thread: " + Thread.currentThread().getName());
            sleep(500);
        }, data.TaskType.ONE_TIME);

        // ========== Test 2: Scheduled Tasks with Delay ==========
        System.out.println("\n⏰ Submitting 3 scheduled tasks with delays...");

        scheduler.scheduleTaskWithDelay("task-delayed-1", TaskPriority.HIGH, () -> {
            System.out.println("  ⏰ [DELAYED 2s] Task executing at: " + System.currentTimeMillis());
        }, 2000L); // 2 seconds delay

        scheduler.scheduleTaskWithDelay("task-delayed-2", TaskPriority.MEDIUM, () -> {
            System.out.println("  ⏰ [DELAYED 3s] Task executing at: " + System.currentTimeMillis());
        }, 3000L); // 3 seconds delay

        scheduler.scheduleTaskWithDelay("task-delayed-3", TaskPriority.LOW, () -> {
            System.out.println("  ⏰ [DELAYED 4s] Task executing at: " + System.currentTimeMillis());
        }, 4000L); // 4 seconds delay

        // ========== Test 3: Recurring Tasks ==========
        System.out.println("\n🔄 Submitting 2 recurring tasks...");

        scheduler.submitRecurringTask("task-recurring-1", TaskPriority.HIGH, () -> {
            System.out.println("  🔄 [RECURRING 1.5s] Task executing at: " + System.currentTimeMillis());
        }, 1500L); // Every 1.5 seconds

        scheduler.submitRecurringTask("task-recurring-2", TaskPriority.MEDIUM, () -> {
            System.out.println("  🔄 [RECURRING 2s] Task executing at: " + System.currentTimeMillis());
        }, 2000L); // Every 2 seconds

        // ========== Test 4: Task with Failure & Retry ==========
        System.out.println("\n❌ Submitting 1 task that will fail and retry...");

        scheduler.submitTask("task-fail-retry", TaskPriority.HIGH, () -> {
            System.out.println("  ❌ [FAIL] Task starting...");
            throw new RuntimeException("Simulated task failure - will retry!");
        }, data.TaskType.ONE_TIME);

        // ========== Test 5: Task Dependencies (DAG) ==========
        System.out.println("\n🔗 Submitting tasks with dependencies (DAG)...");

        // Task A (no dependencies)
        scheduler.submitTask("task-A", TaskPriority.HIGH, () -> {
            System.out.println("  🔗 [TASK-A] Executing (no dependencies)");
            sleep(300);
        }, data.TaskType.ONE_TIME);

        // Task B depends on A
        scheduler.submitTaskWithDependencies("task-B", TaskPriority.HIGH, () -> {
            System.out.println("  🔗 [TASK-B] Executing (depends on A)");
            sleep(300);
        }, Arrays.asList("task-A"));

        // Task C depends on B
        scheduler.submitTaskWithDependencies("task-C", TaskPriority.HIGH, () -> {
            System.out.println("  🔗 [TASK-C] Executing (depends on B)");
            sleep(300);
        }, Arrays.asList("task-B"));

        // ========== Start the Scheduler ==========
        System.out.println("\n🚀 Starting the scheduler...\n");

        // Start scheduler in a separate thread so we can monitor
        Thread schedulerThread = new Thread(() -> {
            try {
                scheduler.start();
            } catch (InterruptedException e) {
                System.out.println("Scheduler interrupted");
            }
        });
        schedulerThread.start();

        // ========== Monitor Task Execution ==========
        System.out.println("⏳ Waiting for tasks to execute (10 seconds)...\n");
        Thread.sleep(10000); // Wait 10 seconds to see recurring tasks execute multiple times

        // ========== Display Task Statuses ==========
        System.out.println("\n\n📊 Final Task Status Report:");
        System.out.println("=" .repeat(80));

        taskDb.tasks.values().forEach(task -> {
            System.out.printf("%-20s | %-6s | %-12s | %-10s | Retries: %d | By: %s%n",
                    task.getTaskId(),
                    task.getPriority(),
                    task.getStatus(),
                    task.getTaskType(),
                    task.getRetryCount(),
                    task.getExecutedBy() != null ? task.getExecutedBy() : "N/A");
        });
        System.out.println("=" .repeat(80));

        // ========== FAANG Feature: Display Metrics ==========
        scheduler.printMetrics();

        // ========== Shutdown ==========
        System.out.println("\n🛑 Shutting down scheduler...");
        scheduler.shutdown();
        service.WorkerPool.getInstance(5).shutdown();

        System.out.println("\n✅ Demo completed successfully!");
        System.out.println("=" .repeat(70) + "\n");
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}