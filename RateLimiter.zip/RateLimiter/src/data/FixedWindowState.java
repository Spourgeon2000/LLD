package data;

public class FixedWindowState extends AlgorithmState {
    private Integer currentRequestCount;
    private Long windowStartTime;

    public Integer getCurrentRequestCount() {
        return currentRequestCount;
    }

    public void setCurrentRequestCount(Integer currentRequestCount) {
        this.currentRequestCount = currentRequestCount;
    }

    public Long getWindowStartTime() {
        return windowStartTime;
    }

    public void setWindowStartTime(Long windowStartTime) {
        this.windowStartTime = windowStartTime;
    }
}

