package data;

public class UserRateLimitConfig extends RateLimitConfig {
    private String company;

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }
}
