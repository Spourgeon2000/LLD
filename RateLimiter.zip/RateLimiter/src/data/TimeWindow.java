package data;

public enum TimeWindow {
    SECOND,
    HOUR,
    MINUTE
}
