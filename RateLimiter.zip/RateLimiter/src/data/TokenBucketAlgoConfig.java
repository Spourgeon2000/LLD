package data;

public class TokenBucketAlgoConfig extends AlgorithmConfig {
    private Integer capacity;
    private Integer refillRate;

    public Integer getRefillRate() {
        return refillRate;
    }

    public void setRefillRate(Integer refillRate) {
        this.refillRate = refillRate;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }
}
