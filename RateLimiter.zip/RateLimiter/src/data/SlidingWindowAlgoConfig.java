package data;

public class SlidingWindowAlgoConfig extends AlgorithmConfig {
    Integer maxRequests;
    Long windowSize;

    public Integer getMaxRequests() {
        return maxRequests;
    }

    public void setMaxRequests(Integer maxRequests) {
        this.maxRequests = maxRequests;
    }

    public Long getWindowSize() {
        return windowSize;
    }

    public void setWindowSize(Long windowSize) {
        this.windowSize = windowSize;
    }
}

