package data;

import java.util.List;

public class SlidingWindowState extends AlgorithmState {
    private List<Long> requestTimestamps;

    public List<Long> getRequestTimestamps() {
        return requestTimestamps;
    }

    public void setRequestTimestamps(List<Long> requestTimestamps) {
        this.requestTimestamps = requestTimestamps;
    }
}

