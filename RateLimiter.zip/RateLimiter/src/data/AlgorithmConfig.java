package data;

public abstract class AlgorithmConfig {
    private TimeWindow timeWindow;

    public TimeWindow getTimeWindow() {
        return timeWindow;
    }

    public void setTimeWindow(TimeWindow timeWindow) {
        this.timeWindow = timeWindow;
    }
}
