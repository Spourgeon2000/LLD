package data;

public class TokenBucketState extends AlgorithmState {
    private Integer currentTokens;
    private Long lastRefillTime;

    public Integer getCurrentTokens() {
        return currentTokens;
    }

    public void setCurrentTokens(Integer currentTokens) {
        this.currentTokens = currentTokens;
    }

    public Long getLastRefillTime() {
        return lastRefillTime;
    }

    public void setLastRefillTime(Long lastRefillTime) {
        this.lastRefillTime = lastRefillTime;
    }
}

