package data;

public abstract class RateLimitConfig {
    private String rateLimitConfigId;
    private RateLimitType type;
    private AlgorithmType algorithmType;
    private  AlgorithmConfig algorithmConfig;

    public AlgorithmConfig getAlgorithmConfig() {
        return algorithmConfig;
    }

    public void setAlgorithmConfig(AlgorithmConfig algorithmConfig) {
        this.algorithmConfig = algorithmConfig;
    }

    public String getRateLimitConfigId() {
        return rateLimitConfigId;
    }

    public void setRateLimitConfigId(String rateLimitConfigId) {
        this.rateLimitConfigId = rateLimitConfigId;
    }


    public RateLimitType getType() {
        return type;
    }

    public void setType(RateLimitType type) {
        this.type = type;
    }

    public AlgorithmType getAlgorithmType() {
        return algorithmType;
    }

    public void setAlgorithmType(AlgorithmType algorithmType) {
        this.algorithmType = algorithmType;
    }

}
