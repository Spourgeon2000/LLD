package data;

public class ApiRateLimitConfig extends RateLimitConfig {
    private String apiEndPoint;

    public String getApiEndPoint() {
        return apiEndPoint;
    }

    public void setApiEndPoint(String apiEndPoint) {
        this.apiEndPoint = apiEndPoint;
    }
}
