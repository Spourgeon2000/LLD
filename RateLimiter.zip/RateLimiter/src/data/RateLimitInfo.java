package data;

public abstract class RateLimitInfo {
    private String rateLimitConfigId;
    private RateLimitType rateLimitType;
    private AlgorithmState algorithmState;

    public String getRateLimitConfigId() {
        return rateLimitConfigId;
    }

    public AlgorithmState getAlgorithmState() {
        return algorithmState;
    }

    public void setAlgorithmState(AlgorithmState algorithmState) {
        this.algorithmState = algorithmState;
    }

    public void setRateLimitConfigId(String rateLimitConfigId) {
        this.rateLimitConfigId = rateLimitConfigId;
    }

    public RateLimitType getRateLimitType() {
        return rateLimitType;
    }

    public void setRateLimitType(RateLimitType rateLimitType) {
        this.rateLimitType = rateLimitType;
    }
}
