package data;

public class ApiRateLimitInfo extends RateLimitInfo {
    private String apiEndPoint;

    public String getApiEndPoint() {
        return apiEndPoint;
    }

    public void setApiEndPoint(String apiEndPoint) {
        this.apiEndPoint = apiEndPoint;
    }

}
