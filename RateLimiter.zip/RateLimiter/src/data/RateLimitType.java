package data;

public enum RateLimitType {
    USER,
    API,
    SERVICE
}
