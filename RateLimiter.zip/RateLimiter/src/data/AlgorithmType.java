package data;

public enum AlgorithmType {
    TOKEN_BUCKET,
    FIXED_WINDOW,
    SLIDING_WINDOW
}
