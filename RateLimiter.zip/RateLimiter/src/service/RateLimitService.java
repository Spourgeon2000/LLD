package service;

import data.RateLimitConfig;
import data.RateLimitInfo;
import data.RateLimitRequest;
import repo.RateLimitConfigRepo;
import repo.RateLimitInfoRepo;

public class RateLimitService {
    private static RateLimitService instance = null;

    public static RateLimitService getInstance() {
        if (instance == null) {
            instance = new RateLimitService();
        }
        return instance;
    }

    RateLimitConfigRepo rateLimitConfigRepo = RateLimitConfigRepo.getInstance();
    RateLimitInfoRepo rateLimitInfoRepo = RateLimitInfoRepo.getInstance();

    public RateLimitConfig addRateLimitConfig(RateLimitConfig rateLimitConfig) {
        return rateLimitConfigRepo.addRateLimitConfig(rateLimitConfig);
    }

    public RateLimitConfig getRateLimitConfig(String rateLimitConfigId) {
        return rateLimitConfigRepo.getRateLimitConfig(rateLimitConfigId);
    }

    public void updateRateLimitInfo(RateLimitRequest request, RateLimitInfo rateLimitInfo) {
        String key = getKeyForRequest(request);
        rateLimitInfoRepo.updateRateLimitInfo(key, rateLimitInfo);
    }

    private String getKeyForRequest(RateLimitRequest request) {
        switch (request.getRateLimitType()) {
            case USER:
                return request.getCompany();
            case API:
                return request.getApiEndpoint();
            case SERVICE:
                return request.getServiceName();
            default:
                throw new IllegalArgumentException("Unknown rate limit type");
        }
    }
}
