package service;

import data.*;
import factory.RateLimitAlgorithmStrategyFactory;
import factory.RateLimitStrategyFactory;
import strategy.RateLimitAlgorithmStrategy;
import strategy.RateLimitStrategyBundle;

public class RequestService {
    private static RequestService instance = null;

    public static RequestService getInstance() {
        if (instance == null) {
            instance = new RequestService();
        }
        return instance;
    }

    RateLimitService rateLimitService = RateLimitService.getInstance();
    RateLimitStrategyFactory rateLimitStrategyFactory = RateLimitStrategyFactory.getInstance();

    public boolean checkRequest(RateLimitRequest rateLimitRequest) {
        RateLimitType rateLimitType = rateLimitRequest.getRateLimitType();
        RateLimitStrategyBundle rateLimitStrategyBundle = rateLimitStrategyFactory.getStrategyBundle(rateLimitType);
        RateLimitConfig rateLimitConfig = rateLimitStrategyBundle.getRateLimitConfig(rateLimitRequest);
        RateLimitInfo rateLimitInfo = rateLimitStrategyBundle.getRateLimitInfo(rateLimitRequest);

        if (rateLimitConfig == null) {
            return true;
        }

        if (rateLimitInfo.getAlgorithmState() == null) {
            initializeAlgorithmState(rateLimitInfo, rateLimitConfig);
        }

        AlgorithmType algorithmType = rateLimitConfig.getAlgorithmType();
        RateLimitAlgorithmStrategy algorithmStrategy = RateLimitAlgorithmStrategyFactory.getStrategy(algorithmType);
        boolean allowed = algorithmStrategy.checkRequest(rateLimitConfig, rateLimitInfo);

        rateLimitService.updateRateLimitInfo(rateLimitRequest, rateLimitInfo);

        return allowed;
    }

    private void initializeAlgorithmState(RateLimitInfo rateLimitInfo, RateLimitConfig rateLimitConfig) {
        AlgorithmType algorithmType = rateLimitConfig.getAlgorithmType();
        AlgorithmConfig algorithmConfig = rateLimitConfig.getAlgorithmConfig();

        RateLimitAlgorithmStrategy algorithmStrategy = RateLimitAlgorithmStrategyFactory.getStrategy(algorithmType);
        AlgorithmState algorithmState = algorithmStrategy.initializeState(algorithmConfig);
        rateLimitInfo.setAlgorithmState(algorithmState);
    }
}

