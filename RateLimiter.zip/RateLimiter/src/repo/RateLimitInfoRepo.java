package repo;

import data.*;

import java.util.HashMap;
import java.util.Map;

public class RateLimitInfoRepo {
    private static RateLimitInfoRepo instance = null;

    public static RateLimitInfoRepo getInstance() {
        if (instance == null) {
            instance = new RateLimitInfoRepo();
        }
        return instance;
    }

    private RateLimitInfoRepo() {}

    private Map<String, RateLimitInfo> rateLimitInfoMap = new HashMap<>();

    public RateLimitInfo addRateLimitInfo(String key, RateLimitInfo rateLimitInfo) {
        rateLimitInfoMap.put(key, rateLimitInfo);
        return rateLimitInfo;
    }

    public RateLimitInfo getRateLimitInfo(String key) {
        return rateLimitInfoMap.get(key);
    }

    public RateLimitInfo updateRateLimitInfo(String key, RateLimitInfo rateLimitInfo) {
        rateLimitInfoMap.put(key, rateLimitInfo);
        return rateLimitInfo;
    }

    public RateLimitInfo getRateLimitInfoForUser(String company) {
        RateLimitInfo info = rateLimitInfoMap.get(company);
        if (info == null) {
            // Create new UserRateLimitInfo if doesn't exist
            UserRateLimitInfo userInfo = new UserRateLimitInfo();
            userInfo.setUserId(company);
            userInfo.setRateLimitType(RateLimitType.USER);
            rateLimitInfoMap.put(company, userInfo);
            return userInfo;
        }
        return info;
    }

    public RateLimitInfo getRateLimitInfoForApi(String apiEndpoint) {
        RateLimitInfo info = rateLimitInfoMap.get(apiEndpoint);
        if (info == null) {
            ApiRateLimitInfo apiInfo = new ApiRateLimitInfo();
            apiInfo.setApiEndPoint(apiEndpoint);
            apiInfo.setRateLimitType(RateLimitType.API);
            rateLimitInfoMap.put(apiEndpoint, apiInfo);
            return apiInfo;
        }
        return info;
    }

    public RateLimitInfo getRateLimitInfoForService(String serviceName) {
        RateLimitInfo info = rateLimitInfoMap.get(serviceName);
        if (info == null) {
            // Create new ServiceRateLimitInfo if doesn't exist
            ServiceRateLimitInfo serviceInfo = new ServiceRateLimitInfo();
            serviceInfo.setServiceName(serviceName);
            serviceInfo.setRateLimitType(RateLimitType.SERVICE);
            rateLimitInfoMap.put(serviceName, serviceInfo);
            return serviceInfo;
        }
        return info;
    }

    public RateLimitInfo getRateLimitInfoForRequest(RateLimitRequest request) {
        switch (request.getRateLimitType()) {
            case USER:
                return getRateLimitInfoForUser(request.getCompany());
            case API:
                return getRateLimitInfoForApi(request.getApiEndpoint());
            case SERVICE:
                return getRateLimitInfoForService(request.getServiceName());
            default:
                return null;
        }
    }
}

