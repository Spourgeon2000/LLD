package repo;

import data.ApiRateLimitConfig;
import data.RateLimitConfig;
import data.RateLimitRequest;
import data.RateLimitType;
import data.ServiceRateLimitConfig;
import data.UserRateLimitConfig;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class RateLimitConfigRepo {
    private static RateLimitConfigRepo instance = null;

    public static RateLimitConfigRepo getInstance() {
        if (instance == null) {
            instance = new RateLimitConfigRepo();
        }
        return instance;
    }
    private  RateLimitConfigRepo() {}

    Map<String, RateLimitConfig> rateLimitConfigMap = new HashMap<>();

    public RateLimitConfig addRateLimitConfig(RateLimitConfig rateLimitConfig) {
        if (rateLimitConfig.getRateLimitConfigId() == null) {
            rateLimitConfig.setRateLimitConfigId(UUID.randomUUID().toString());
        }
        rateLimitConfigMap.put(rateLimitConfig.getRateLimitConfigId(), rateLimitConfig);
        return rateLimitConfig;
    }

    public RateLimitConfig getRateLimitConfig(String rateLimitConfigID) {
        return rateLimitConfigMap.get(rateLimitConfigID);
    }

    public RateLimitConfig getRateLimitConfigForUsers(String company) {
        return rateLimitConfigMap.values().stream()
                .filter(rateLimitConfig -> rateLimitConfig.getType() == RateLimitType.USER)
                .filter(rateLimitConfig -> rateLimitConfig instanceof UserRateLimitConfig)
                .map(rateLimitConfig -> (UserRateLimitConfig) rateLimitConfig)
                .filter(userConfig -> userConfig.getCompany().equals(company))
                .findFirst()
                .orElse(null);
    }

    public RateLimitConfig getRateLimitConfigForApi(String apiEndpoint) {
        return rateLimitConfigMap.values().stream().filter(
                        rateLimitConfig -> rateLimitConfig.getType() == RateLimitType.API
                ).filter(rateLimitConfig -> rateLimitConfig instanceof ApiRateLimitConfig)
                .map(rateLimitConfig -> (ApiRateLimitConfig) rateLimitConfig).filter(
                        apiRateLimitConfig -> apiRateLimitConfig.getApiEndPoint().equals(apiEndpoint)
                ).findFirst().orElse(null);
    }

    public RateLimitConfig getRateLimitConfigForService(String serviceName) {
        return rateLimitConfigMap.values().stream()
                .filter(rateLimitConfig -> rateLimitConfig.getType() == RateLimitType.SERVICE)
                .filter(rateLimitConfig -> rateLimitConfig instanceof ServiceRateLimitConfig)
                .map(rateLimitConfig -> (ServiceRateLimitConfig) rateLimitConfig)
                .filter(serviceConfig -> serviceConfig.getServiceName().equals(serviceName))
                .findFirst()
                .orElse(null);
    }

    public RateLimitConfig updateRateLimitConfig(RateLimitConfig rateLimitConfig) {
        rateLimitConfigMap.put(rateLimitConfig.getRateLimitConfigId(), rateLimitConfig);
        return rateLimitConfig;
    }

    public RateLimitConfig getRateLimitConfigForRequest(RateLimitRequest request) {
        switch (request.getRateLimitType()) {
            case USER:
                return getRateLimitConfigForUsers(request.getCompany());
            case API:
                return getRateLimitConfigForApi(request.getApiEndpoint());
            case SERVICE:
                return getRateLimitConfigForService(request.getServiceName());
            default:
                return null;
        }
    }

}
