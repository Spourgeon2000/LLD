import data.*;
import service.RateLimitService;
import service.RequestService;

public class Main {
    public static void main(String[] args) {
        System.out.println("========== Rate Limiter Demo ==========\n");

        // Test 1: Token Bucket for User/Company
        testTokenBucketForCompany();

        // Test 2: Fixed Window for API
        testFixedWindowForAPI();

        // Test 3: Token Bucket for Service
        testTokenBucketForService();

        System.out.println("\n========== All Tests Completed ==========");
    }

    private static void testTokenBucketForCompany() {
        System.out.println("TEST 1: Token Bucket for Company (Google)");
        System.out.println("Config: 5 tokens capacity, 2 tokens/second refill rate\n");

        RateLimitService rateLimitService = RateLimitService.getInstance();
        RequestService requestService = RequestService.getInstance();

        // Create Token Bucket config for Google company
        UserRateLimitConfig userConfig = new UserRateLimitConfig();
        userConfig.setCompany("Google");
        userConfig.setType(RateLimitType.USER);
        userConfig.setAlgorithmType(AlgorithmType.TOKEN_BUCKET);

        TokenBucketAlgoConfig tbConfig = new TokenBucketAlgoConfig();
        tbConfig.setCapacity(5);
        tbConfig.setRefillRate(2);  // 2 tokens per second
        tbConfig.setTimeWindow(TimeWindow.SECOND);

        userConfig.setAlgorithmConfig(tbConfig);
        rateLimitService.addRateLimitConfig(userConfig);

        // Test requests
        RateLimitRequest request = new RateLimitRequest();
        request.setRateLimitType(RateLimitType.USER);
        request.setCompany("Google");

        // Make 7 requests quickly (should allow 5, reject 2)
        for (int i = 1; i <= 7; i++) {
            boolean allowed = requestService.checkRequest(request);
            System.out.println("Request " + i + ": " + (allowed ? "✅ ALLOWED" : "❌ REJECTED"));
        }

        // Wait 2 seconds for refill
        System.out.println("\n⏳ Waiting 2 seconds for token refill...");
        sleep(2000);

        // Make 5 more requests (should allow ~4 due to refill)
        System.out.println("After refill:");
        for (int i = 8; i <= 12; i++) {
            boolean allowed = requestService.checkRequest(request);
            System.out.println("Request " + i + ": " + (allowed ? "✅ ALLOWED" : "❌ REJECTED"));
        }

        System.out.println("\n" + "=".repeat(50) + "\n");
    }

    private static void testFixedWindowForAPI() {
        System.out.println("TEST 2: Fixed Window for API Endpoint");
        System.out.println("Config: 3 requests per 5 seconds window\n");

        RateLimitService rateLimitService = RateLimitService.getInstance();
        RequestService requestService = RequestService.getInstance();

        // Create Fixed Window config for /api/search
        ApiRateLimitConfig apiConfig = new ApiRateLimitConfig();
        apiConfig.setApiEndPoint("/api/search");
        apiConfig.setType(RateLimitType.API);
        apiConfig.setAlgorithmType(AlgorithmType.FIXED_WINDOW);

        FixedWindowAlgoConfig fwConfig = new FixedWindowAlgoConfig();
        fwConfig.setMaxRequests(3);
        fwConfig.setWindowSize(5000L);  // 5 seconds

        apiConfig.setAlgorithmConfig(fwConfig);
        rateLimitService.addRateLimitConfig(apiConfig);

        // Test requests
        RateLimitRequest request = new RateLimitRequest();
        request.setRateLimitType(RateLimitType.API);
        request.setApiEndpoint("/api/search");

        // Make 5 requests (should allow 3, reject 2)
        for (int i = 1; i <= 5; i++) {
            boolean allowed = requestService.checkRequest(request);
            System.out.println("Request " + i + ": " + (allowed ? "✅ ALLOWED" : "❌ REJECTED"));
        }

        // Wait 5 seconds for window reset
        System.out.println("\n⏳ Waiting 5 seconds for window reset...");
        sleep(5000);

        // Make 4 more requests (should allow 3, reject 1)
        System.out.println("After window reset:");
        for (int i = 6; i <= 9; i++) {
            boolean allowed = requestService.checkRequest(request);
            System.out.println("Request " + i + ": " + (allowed ? "✅ ALLOWED" : "❌ REJECTED"));
        }

        System.out.println("\n" + "=".repeat(50) + "\n");
    }

    private static void testTokenBucketForService() {
        System.out.println("TEST 3: Token Bucket for Service (PaymentService)");
        System.out.println("Config: 10 tokens capacity, 5 tokens/second refill rate\n");

        RateLimitService rateLimitService = RateLimitService.getInstance();
        RequestService requestService = RequestService.getInstance();

        // Create Token Bucket config for PaymentService
        ServiceRateLimitConfig serviceConfig = new ServiceRateLimitConfig();
        serviceConfig.setServiceName("PaymentService");
        serviceConfig.setType(RateLimitType.SERVICE);
        serviceConfig.setAlgorithmType(AlgorithmType.TOKEN_BUCKET);

        TokenBucketAlgoConfig tbConfig = new TokenBucketAlgoConfig();
        tbConfig.setCapacity(10);
        tbConfig.setRefillRate(5);  // 5 tokens per second
        tbConfig.setTimeWindow(TimeWindow.SECOND);

        serviceConfig.setAlgorithmConfig(tbConfig);
        rateLimitService.addRateLimitConfig(serviceConfig);

        // Test requests
        RateLimitRequest request = new RateLimitRequest();
        request.setRateLimitType(RateLimitType.SERVICE);
        request.setServiceName("PaymentService");

        // Make 12 requests quickly (should allow 10, reject 2)
        for (int i = 1; i <= 12; i++) {
            boolean allowed = requestService.checkRequest(request);
            System.out.println("Request " + i + ": " + (allowed ? "✅ ALLOWED" : "❌ REJECTED"));
        }

        System.out.println("\n" + "=".repeat(50) + "\n");
    }

    private static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}