package util;

import data.TimeWindow;

public class TimeWindowUtil {

    public static long toMilliseconds(TimeWindow timeWindow) {
        switch (timeWindow) {
            case SECOND:
                return 1000L;
            case MINUTE:
                return 60 * 1000L;
            case HOUR:
                return 60 * 60 * 1000L;
            default:
                throw new IllegalArgumentException("Unknown time window: " + timeWindow);
        }
    }

    public static long toMilliseconds(TimeWindow timeWindow, int count) {
        return toMilliseconds(timeWindow) * count;
    }
}

