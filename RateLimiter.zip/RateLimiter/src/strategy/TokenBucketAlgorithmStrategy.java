package strategy;

import data.AlgorithmConfig;
import data.AlgorithmState;
import data.AlgorithmType;
import data.RateLimitConfig;
import data.RateLimitInfo;
import data.TokenBucketAlgoConfig;
import data.TokenBucketState;
import util.TimeWindowUtil;

public class TokenBucketAlgorithmStrategy implements RateLimitAlgorithmStrategy {

    @Override
    public AlgorithmState initializeState(AlgorithmConfig algorithmConfig) {
        TokenBucketAlgoConfig tbConfig = (TokenBucketAlgoConfig) algorithmConfig;
        TokenBucketState tbState = new TokenBucketState();
        tbState.setAlgorithmType(AlgorithmType.TOKEN_BUCKET);
        tbState.setCurrentTokens(tbConfig.getCapacity());
        tbState.setLastRefillTime(System.currentTimeMillis());
        return tbState;
    }

    @Override
    public boolean checkRequest(RateLimitConfig rateLimitConfig, RateLimitInfo rateLimitInfo) {
        TokenBucketAlgoConfig config = (TokenBucketAlgoConfig) rateLimitConfig.getAlgorithmConfig();
        TokenBucketState state = (TokenBucketState) rateLimitInfo.getAlgorithmState();

        long currentTime = System.currentTimeMillis();
        long timePassed = currentTime - state.getLastRefillTime();

        // Get time window in milliseconds (SECOND, MINUTE, or HOUR)
        long timeWindowInMillis = TimeWindowUtil.toMilliseconds(config.getTimeWindow());

        // Refill tokens based on time passed
        // refillRate is tokens per timeWindow (e.g., 100 tokens per SECOND)
        int tokensToAdd = (int) (timePassed * config.getRefillRate() / timeWindowInMillis);
        int newTokens = Math.min(state.getCurrentTokens() + tokensToAdd, config.getCapacity());

        state.setCurrentTokens(newTokens);
        state.setLastRefillTime(currentTime);
        
        if (state.getCurrentTokens() > 0) {
            state.setCurrentTokens(state.getCurrentTokens() - 1);
            return true;
        }

        return false;
    }
}

