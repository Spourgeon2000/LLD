package strategy;

import data.RateLimitConfig;
import data.RateLimitRequest;

public interface RateLimitConfigStrategy {
    public RateLimitConfig getRateLimitConfig(RateLimitRequest request);
}
