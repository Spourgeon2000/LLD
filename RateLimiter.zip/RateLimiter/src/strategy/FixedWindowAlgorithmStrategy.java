package strategy;

import data.*;
import util.TimeWindowUtil;

public class FixedWindowAlgorithmStrategy implements RateLimitAlgorithmStrategy {

    @Override
    public AlgorithmState initializeState(AlgorithmConfig algorithmConfig) {
        FixedWindowState fwState = new FixedWindowState();
        fwState.setAlgorithmType(AlgorithmType.FIXED_WINDOW);
        fwState.setCurrentRequestCount(0);
        fwState.setWindowStartTime(System.currentTimeMillis());
        return fwState;
    }

    @Override
    public boolean checkRequest(RateLimitConfig rateLimitConfig, RateLimitInfo rateLimitInfo) {
        FixedWindowAlgoConfig config = (FixedWindowAlgoConfig) rateLimitConfig.getAlgorithmConfig();
        FixedWindowState state = (FixedWindowState) rateLimitInfo.getAlgorithmState();

        long currentTime = System.currentTimeMillis();
        long windowElapsed = currentTime - state.getWindowStartTime();

        // Get window size: if windowSize is set, use it; otherwise use TimeWindow
        long windowSizeInMillis;
        if (config.getWindowSize() != null && config.getWindowSize() > 0) {
            windowSizeInMillis = config.getWindowSize();
        } else {
            windowSizeInMillis = TimeWindowUtil.toMilliseconds(config.getTimeWindow());
        }

        // Check if window has expired
        if (windowElapsed >= windowSizeInMillis) {
            state.setWindowStartTime(currentTime);
            state.setCurrentRequestCount(0);
        }

        // Check if we're within limit
        if (state.getCurrentRequestCount() < config.getMaxRequests()) {
            state.setCurrentRequestCount(state.getCurrentRequestCount() + 1);
            return true;
        }

        return false;
    }
}

