package strategy;

import data.AlgorithmConfig;
import data.AlgorithmState;
import data.RateLimitConfig;
import data.RateLimitInfo;

public interface RateLimitAlgorithmStrategy {
    AlgorithmState initializeState(AlgorithmConfig algorithmConfig);
    boolean checkRequest(RateLimitConfig rateLimitConfig, RateLimitInfo rateLimitInfo);
}

