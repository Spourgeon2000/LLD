package strategy;

import data.RateLimitInfo;
import data.RateLimitRequest;
import data.RateLimitType;
import repo.RateLimitInfoRepo;

import java.util.Objects;

public class ApiRateLimitInfoStrategy implements RateLimitInfoStrategy {

    RateLimitInfoRepo rateLimitInfoRepo = RateLimitInfoRepo.getInstance();

    @Override
    public RateLimitInfo getRateLimitInfo(RateLimitRequest request) {
        if (!Objects.equals(request.getRateLimitType(), RateLimitType.API)) {
            throw new IllegalArgumentException("Invalid rate limit type");
        }
        return rateLimitInfoRepo.getRateLimitInfoForApi(request.getApiEndpoint());
    }
}

