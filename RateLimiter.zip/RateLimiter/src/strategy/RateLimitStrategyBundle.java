package strategy;

import data.RateLimitConfig;
import data.RateLimitInfo;
import data.RateLimitRequest;

public class RateLimitStrategyBundle {
    private RateLimitConfigStrategy configStrategy;
    private RateLimitInfoStrategy infoStrategy;

    public RateLimitStrategyBundle(RateLimitConfigStrategy configStrategy, RateLimitInfoStrategy infoStrategy) {
        this.configStrategy = configStrategy;
        this.infoStrategy = infoStrategy;
    }

    public RateLimitConfig getRateLimitConfig(RateLimitRequest request) {
        return configStrategy.getRateLimitConfig(request);
    }

    public RateLimitInfo getRateLimitInfo(RateLimitRequest request) {
        return infoStrategy.getRateLimitInfo(request);
    }

    public RateLimitConfigStrategy getConfigStrategy() {
        return configStrategy;
    }

    public RateLimitInfoStrategy getInfoStrategy() {
        return infoStrategy;
    }
}

