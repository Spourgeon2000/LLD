package strategy;

import data.RateLimitInfo;
import data.RateLimitRequest;
import data.RateLimitType;
import repo.RateLimitInfoRepo;

import java.util.Objects;

public class ServiceRateLimitInfoStrategy implements RateLimitInfoStrategy {

    RateLimitInfoRepo rateLimitInfoRepo = RateLimitInfoRepo.getInstance();

    @Override
    public RateLimitInfo getRateLimitInfo(RateLimitRequest request) {
        if (!Objects.equals(request.getRateLimitType(), RateLimitType.SERVICE)) {
            throw new IllegalArgumentException("Invalid rate limit type");
        }
        return rateLimitInfoRepo.getRateLimitInfoForService(request.getServiceName());
    }
}

