package strategy;

import data.RateLimitConfig;
import data.RateLimitRequest;
import data.RateLimitType;
import repo.RateLimitConfigRepo;

import java.util.Objects;

public class ApiRateLimitStrategy implements RateLimitConfigStrategy {

    RateLimitConfigRepo rateLimitConfigRepo = RateLimitConfigRepo.getInstance();

    public RateLimitConfig getRateLimitConfig(RateLimitRequest request) {
        if (!Objects.equals(request.getRateLimitType(), RateLimitType.API)) {
            throw new IllegalArgumentException("Invalid rate limit type");
        }
        return rateLimitConfigRepo.getRateLimitConfigForApi(request.getApiEndpoint());
    }
}

