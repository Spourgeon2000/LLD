package strategy;

import data.RateLimitInfo;
import data.RateLimitRequest;

public interface RateLimitInfoStrategy {
    RateLimitInfo getRateLimitInfo(RateLimitRequest request);
}

