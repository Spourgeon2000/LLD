package strategy;

import data.AlgorithmConfig;
import data.AlgorithmState;
import data.AlgorithmType;
import data.RateLimitConfig;
import data.RateLimitInfo;
import data.SlidingWindowState;

import java.util.ArrayList;

public class SlidingWindowAlgorithmStrategy implements RateLimitAlgorithmStrategy {

    @Override
    public AlgorithmState initializeState(AlgorithmConfig algorithmConfig) {
        SlidingWindowState swState = new SlidingWindowState();
        swState.setAlgorithmType(AlgorithmType.SLIDING_WINDOW);
        swState.setRequestTimestamps(new ArrayList<>());
        return swState;
    }

    @Override
    public boolean checkRequest(RateLimitConfig rateLimitConfig, RateLimitInfo rateLimitInfo) {
        return true;
    }
}

