package factory;

import data.RateLimitType;
import strategy.*;

public class RateLimitInfoStrategyFactory {

    public static RateLimitInfoStrategy getStrategy(RateLimitType rateLimitType) {
        switch (rateLimitType) {
            case USER:
                return new UserRateLimitInfoStrategy();
            case API:
                return new ApiRateLimitInfoStrategy();
            case SERVICE:
                return new ServiceRateLimitInfoStrategy();
            default:
                throw new IllegalArgumentException("Unknown rate limit type: " + rateLimitType);
        }
    }
}

