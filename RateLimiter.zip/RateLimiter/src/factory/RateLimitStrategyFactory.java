package factory;

import data.RateLimitType;
import strategy.RateLimitStrategyBundle;

public class RateLimitStrategyFactory {

    private static RateLimitStrategyFactory instance = null;
    private RateLimitStrategyFactory() {}
    public static RateLimitStrategyFactory getInstance() {
        if (instance == null) {
            instance = new RateLimitStrategyFactory();
        }
        return instance;
    }

    public RateLimitStrategyBundle getStrategyBundle(RateLimitType rateLimitType) {
        return new RateLimitStrategyBundle(
            RateLimitConfigStrategyFactory.getStrategy(rateLimitType),
            RateLimitInfoStrategyFactory.getStrategy(rateLimitType)
        );
    }
}

