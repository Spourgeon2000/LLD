package factory;

import data.AlgorithmType;
import strategy.FixedWindowAlgorithmStrategy;
import strategy.RateLimitAlgorithmStrategy;
import strategy.SlidingWindowAlgorithmStrategy;
import strategy.TokenBucketAlgorithmStrategy;

public class RateLimitAlgorithmStrategyFactory {

    public static RateLimitAlgorithmStrategy getStrategy(AlgorithmType algorithmType) {
        switch (algorithmType) {
            case TOKEN_BUCKET:
                return new TokenBucketAlgorithmStrategy();
            case FIXED_WINDOW:
                return new FixedWindowAlgorithmStrategy();
            case SLIDING_WINDOW:
                return new SlidingWindowAlgorithmStrategy();
            default:
                throw new IllegalArgumentException("Unknown algorithm type: " + algorithmType);
        }
    }
}

