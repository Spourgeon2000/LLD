package factory;

import data.RateLimitType;
import strategy.ApiRateLimitStrategy;
import strategy.RateLimitConfigStrategy;
import strategy.ServiceRateLimitStrategy;
import strategy.UserRateLimitStrategy;

public class RateLimitConfigStrategyFactory {

    public static RateLimitConfigStrategy getStrategy(RateLimitType rateLimitType) {
        switch (rateLimitType) {
            case USER:
                return new UserRateLimitStrategy();
            case API:
                return new ApiRateLimitStrategy();
            case SERVICE:
                return new ServiceRateLimitStrategy();
            default:
                throw new IllegalArgumentException("Unknown rate limit type: " + rateLimitType);
        }
    }
}

