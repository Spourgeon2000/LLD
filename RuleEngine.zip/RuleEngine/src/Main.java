import action.Action;
import action.LogAction;
import action.UpdateAction;
import condition.*;
import engine.RuleEngine;
import model.Context;
import rule.Rule;
import rule.SimpleRule;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== PHASE 1 TESTS ===\n");

        // Test 1: Context - Store and retrieve data
        testContext();

        // Test 2: EqualsCondition - Compare values
        testEqualsCondition();

        // Test 3: LogAction - Print message
        testLogAction();

        // Test 4: SimpleRule - Combine condition + action
        testSimpleRule();

        // Test 5: End-to-End Test (Phase 1 Requirement #8)
        testEndToEnd();

        System.out.println("\n=== PHASE 2 TESTS ===\n");

        // Test 6: RuleEngine - Manage multiple rules
        testRuleEngine();

        // Test 7: Phase 2 End-to-End (Requirement #10)
        testPhase2EndToEnd();

        System.out.println("\n=== PHASE 3 TESTS ===\n");

        // Test 8: All Comparison Operators
        testAllOperators();

        // Test 9: Phase 3 End-to-End (Requirement #13)
        testPhase3EndToEnd();

        System.out.println("\n=== PHASE 4 TESTS ===\n");

        // Test 10: UpdateAction - Modify context
        testUpdateAction();

        // Test 11: Phase 4 End-to-End (Requirement #15)
        testPhase4EndToEnd();

        System.out.println("\n=== PHASE 5 TESTS ===\n");

        // Test 12: AndCondition - Combine conditions with AND
        testAndCondition();

        // Test 13: OrCondition - Combine conditions with OR
        testOrCondition();

        // Test 14: Mixed AND/OR Conditions - Complex nested logic
        testMixedAndOrConditions();

        // Test 15: Phase 5 End-to-End (Requirement #18)
        testPhase5EndToEnd();

        System.out.println("\n=== ALL TESTS COMPLETED ===");
    }

    // Test 1: Context
    static void testContext() {
        System.out.println("Test 1: Context");
        Context context = new Context();

        // Test put and get
        context.put("age", 18);
        context.put("name", "John");

        Object age = context.get("age");
        Object name = context.get("name");

        System.out.println("  ✓ Put age=18, got: " + age);
        System.out.println("  ✓ Put name=John, got: " + name);

        // Test contains
        boolean hasAge = context.contains("age");
        boolean hasCity = context.contains("city");
        System.out.println("  ✓ Contains 'age': " + hasAge);
        System.out.println("  ✓ Contains 'city': " + hasCity);

        // Test null value
        Object missing = context.get("missing");
        System.out.println("  ✓ Get missing key: " + missing);
        System.out.println();
    }

    // Test 2: EqualsCondition
    static void testEqualsCondition() {
        System.out.println("Test 2: EqualsCondition");
        Context context = new Context();
        context.put("age", 18);
        context.put("name", "John");

        // Test EQUALS - should return true
        Condition ageEquals18 = new EqualsCondition("age", 18);
        boolean result1 = ageEquals18.check(context);
        System.out.println("  ✓ age EQUALS 18: " + result1 + " (expected: true)");

        // Test EQUALS - should return false
        Condition ageEquals20 = new EqualsCondition("age", 20);
        boolean result2 = ageEquals20.check(context);
        System.out.println("  ✓ age EQUALS 20: " + result2 + " (expected: false)");

        // Test with String
        Condition nameEqualsJohn = new EqualsCondition("name", "John");
        boolean result3 = nameEqualsJohn.check(context);
        System.out.println("  ✓ name EQUALS John: " + result3 + " (expected: true)");

        // Test with missing field
        Condition cityEqualsNY = new EqualsCondition("city", "NY");
        boolean result4 = cityEqualsNY.check(context);
        System.out.println("  ✓ city EQUALS NY (missing field): " + result4 + " (expected: false)");
        System.out.println();
    }

    // Test 3: LogAction
    static void testLogAction() {
        System.out.println("Test 3: LogAction");
        Context context = new Context();

        Action logAction1 = new LogAction("  ✓ This is a log message");
        logAction1.perform(context);

        Action logAction2 = new LogAction("  ✓ Another log message");
        logAction2.perform(context);
        System.out.println();
    }

    // Test 4: SimpleRule
    static void testSimpleRule() {
        System.out.println("Test 4: SimpleRule");
        Context context = new Context();
        context.put("age", 18);

        // Create rule: if age == 18, print message
        Condition condition = new EqualsCondition("age", 18);
        Action action = new LogAction("  ✓ Rule executed: Age is 18!");
        Rule rule = new SimpleRule(condition, action);

        // Test evaluate
        boolean shouldExecute = rule.evaluate(context);
        System.out.println("  ✓ Rule.evaluate(): " + shouldExecute + " (expected: true)");

        // Test execute
        rule.execute(context);

        // Test with different age
        context.put("age", 20);
        boolean shouldNotExecute = rule.evaluate(context);
        System.out.println("  ✓ Rule.evaluate() with age=20: " + shouldNotExecute + " (expected: false)");
        System.out.println();
    }

    // Test 5: End-to-End
    static void testEndToEnd() {
        System.out.println("Test 5: End-to-End (Phase 1 Requirement #8)");

        // Step 1: Create context
        Context context = new Context();
        context.put("age", 18);
        System.out.println("  ✓ Created context with age=18");

        // Step 2: Create condition
        Condition condition = new EqualsCondition("age", 18);
        System.out.println("  ✓ Created condition: age EQUALS 18");

        // Step 3: Create action
        Action action = new LogAction("  ✓ Output: You are 18!");
        System.out.println("  ✓ Created action: print 'You are 18!'");

        // Step 4: Create rule
        Rule rule = new SimpleRule(condition, action);
        System.out.println("  ✓ Created rule with condition + action");

        // Step 5: Execute rule
        System.out.println("  ✓ Executing rule...");
        if (rule.evaluate(context)) {
            rule.execute(context);
        }
        System.out.println();
    }

    // Test 6: RuleEngine
    static void testRuleEngine() {
        System.out.println("Test 6: RuleEngine");

        // Create context
        Context context = new Context();
        context.put("age", 25);

        // Create multiple rules
        Rule rule1 = new SimpleRule(
                new EqualsCondition("age", 25),
                new LogAction("  ✓ Rule 1 executed: Age is 25")
        );

        Rule rule2 = new SimpleRule(
                new EqualsCondition("age", 30),
                new LogAction("  ✓ Rule 2 executed: Age is 30")
        );

        Rule rule3 = new SimpleRule(
                new EqualsCondition("age", 25),
                new LogAction("  ✓ Rule 3 executed: Age is also 25")
        );

        // Create engine and add rules
        RuleEngine engine = new RuleEngine();
        System.out.println("  ✓ Created RuleEngine");

        engine.addRule(rule1);
        engine.addRule(rule2);
        engine.addRule(rule3);
        System.out.println("  ✓ Added 3 rules to engine");

        // Execute all rules
        System.out.println("  ✓ Executing all rules...");
        engine.executeRules(context);
        System.out.println("  ✓ Expected: Rule 1 and Rule 3 should execute (age=25)");
        System.out.println();
    }

    // Test 7: Phase 2 End-to-End
    static void testPhase2EndToEnd() {
        System.out.println("Test 7: Phase 2 End-to-End (Requirement #10)");

        // Test Case 1: age = 20
        System.out.println("  Test Case 1: age = 20");
        Context context1 = new Context();
        context1.put("age", 20);

        RuleEngine engine1 = new RuleEngine();
        engine1.addRule(new SimpleRule(
                new GreaterThanOrEqualCondition("age", 18),
                new LogAction("  ✓ Output: Adult")
        ));
        engine1.addRule(new SimpleRule(
                new LessThanCondition("age", 18),
                new LogAction("  ✓ Output: Minor")
        ));

        engine1.executeRules(context1);
        System.out.println("  ✓ Expected: Adult");

        // Test Case 2: age = 15
        System.out.println("\n  Test Case 2: age = 15");
        Context context2 = new Context();
        context2.put("age", 15);

        RuleEngine engine2 = new RuleEngine();
        engine2.addRule(new SimpleRule(
                new GreaterThanOrEqualCondition("age", 18),
                new LogAction("  ✓ Output: Adult")
        ));
        engine2.addRule(new SimpleRule(
                new LessThanCondition("age", 18),
                new LogAction("  ✓ Output: Minor")
        ));

        engine2.executeRules(context2);
        System.out.println("  ✓ Expected: Minor");

        // Test Case 3: age = 18
        System.out.println("\n  Test Case 3: age = 18");
        Context context3 = new Context();
        context3.put("age", 18);

        RuleEngine engine3 = new RuleEngine();
        engine3.addRule(new SimpleRule(
                new GreaterThanOrEqualCondition("age", 18),
                new LogAction("  ✓ Output: Adult")
        ));
        engine3.addRule(new SimpleRule(
                new LessThanCondition("age", 18),
                new LogAction("  ✓ Output: Minor")
        ));

        engine3.executeRules(context3);
        System.out.println("  ✓ Expected: Adult");
        System.out.println();
    }


    // Test 8: All Comparison Operators
    static void testAllOperators() {
        System.out.println("Test 8: All Comparison Operators");
        Context context = new Context();
        context.put("age", 20);
        context.put("score", 85);
        context.put("name", "John");

        // Test EQUALS
        Condition equals = new EqualsCondition("age", 20);
        System.out.println("  ✓ age EQUALS 20: " + equals.check(context) + " (expected: true)");

        // Test NOT_EQUALS
        Condition notEquals = new NotEqualsCondition("age", 18);
        System.out.println("  ✓ age NOT_EQUALS 18: " + notEquals.check(context) + " (expected: true)");

        // Test GREATER_THAN
        Condition greaterThan = new GreaterThanCondition("age", 18);
        System.out.println("  ✓ age GREATER_THAN 18: " + greaterThan.check(context) + " (expected: true)");

        // Test LESS_THAN
        Condition lessThan = new LessThanCondition("age", 25);
        System.out.println("  ✓ age LESS_THAN 25: " + lessThan.check(context) + " (expected: true)");

        // Test GREATER_THAN_OR_EQUAL
        Condition greaterThanOrEqual = new GreaterThanOrEqualCondition("age", 20);
        System.out.println("  ✓ age GREATER_THAN_OR_EQUAL 20: " + greaterThanOrEqual.check(context) + " (expected: true)");

        // Test LESS_THAN_OR_EQUAL
        Condition lessThanOrEqual = new LessThanOrEqualCondition("score", 85);
        System.out.println("  ✓ score LESS_THAN_OR_EQUAL 85: " + lessThanOrEqual.check(context) + " (expected: true)");

        // Test with String
        Condition stringEquals = new EqualsCondition("name", "John");
        System.out.println("  ✓ name EQUALS 'John': " + stringEquals.check(context) + " (expected: true)");

        System.out.println();
    }

    // Test 9: Phase 3 End-to-End
    static void testPhase3EndToEnd() {
        System.out.println("Test 9: Phase 3 End-to-End (Requirement #13)");

        // Test Case 1: age = 25
        System.out.println("  Test Case 1: age = 25");
        Context context1 = new Context();
        context1.put("age", 25);

        RuleEngine engine1 = new RuleEngine();
        engine1.addRule(new SimpleRule(
                new GreaterThanOrEqualCondition("age", 18),
                new LogAction("  ✓ Output: Can vote")
        ));

        engine1.executeRules(context1);
        System.out.println("  ✓ Expected: Can vote");

        // Test Case 2: name = 'John'
        System.out.println("\n  Test Case 2: name = 'John'");
        Context context2 = new Context();
        context2.put("name", "John");

        RuleEngine engine2 = new RuleEngine();
        engine2.addRule(new SimpleRule(
                new EqualsCondition("name", "John"),
                new LogAction("  ✓ Output: Hello John")
        ));

        engine2.executeRules(context2);
        System.out.println("  ✓ Expected: Hello John");

        // Test Case 3: age = 25, name = 'John'
        System.out.println("\n  Test Case 3: age = 25, name = 'John'");
        Context context3 = new Context();
        context3.put("age", 25);
        context3.put("name", "John");

        RuleEngine engine3 = new RuleEngine();
        engine3.addRule(new SimpleRule(
                new GreaterThanOrEqualCondition("age", 18),
                new LogAction("Can vote")
        ));
        engine3.addRule(new SimpleRule(
                new EqualsCondition("name", "John"),
                new LogAction("Hello John")
        ));

        System.out.println("  ✓ Output:");
        engine3.executeRules(context3);
        System.out.println("  ✓ Expected: Can vote, Hello John");
        System.out.println();
    }

    // Test 10: UpdateAction
    static void testUpdateAction() {
        System.out.println("Test 10: UpdateAction");
        Context context = new Context();
        context.put("age", 25);
        context.put("status", "pending");

        System.out.println("  Initial context:");
        System.out.println("    age = " + context.get("age"));
        System.out.println("    status = " + context.get("status"));
        System.out.println("    eligible = " + context.get("eligible"));

        // Test UpdateAction - change status
        Action updateStatus = new UpdateAction("status", "approved");
        updateStatus.perform(context);
        System.out.println("  ✓ After UpdateAction('status', 'approved'):");
        System.out.println("    status = " + context.get("status") + " (expected: approved)");

        // Test UpdateAction - add new field
        Action updateEligible = new UpdateAction("eligible", true);
        updateEligible.perform(context);
        System.out.println("  ✓ After UpdateAction('eligible', true):");
        System.out.println("    eligible = " + context.get("eligible") + " (expected: true)");

        // Test UpdateAction - update existing field
        Action updateAge = new UpdateAction("age", 30);
        updateAge.perform(context);
        System.out.println("  ✓ After UpdateAction('age', 30):");
        System.out.println("    age = " + context.get("age") + " (expected: 30)");

        System.out.println();
    }

    // Test 11: Phase 4 End-to-End
    static void testPhase4EndToEnd() {
        System.out.println("Test 11: Phase 4 End-to-End (Requirement #15)");

        // Test Case 1: age = 20
        System.out.println("  Test Case 1: age = 20");
        Context context1 = new Context();
        context1.put("age", 20);

        System.out.println("  Before rule execution:");
        System.out.println("    age = " + context1.get("age"));
        System.out.println("    eligible = " + context1.get("eligible"));

        RuleEngine engine1 = new RuleEngine();
        engine1.addRule(new SimpleRule(
                new GreaterThanOrEqualCondition("age", 18),
                new UpdateAction("eligible", true)
        ));

        engine1.executeRules(context1);

        System.out.println("  ✓ After rule execution:");
        System.out.println("    age = " + context1.get("age"));
        System.out.println("    eligible = " + context1.get("eligible") + " (expected: true)");

        // Test Case 2: age = 15
        System.out.println("\n  Test Case 2: age = 15");
        Context context2 = new Context();
        context2.put("age", 15);

        System.out.println("  Before rule execution:");
        System.out.println("    age = " + context2.get("age"));
        System.out.println("    eligible = " + context2.get("eligible"));

        RuleEngine engine2 = new RuleEngine();
        engine2.addRule(new SimpleRule(
                new GreaterThanOrEqualCondition("age", 18),
                new UpdateAction("eligible", true)
        ));
        engine2.addRule(new SimpleRule(
                new LessThanCondition("age", 18),
                new UpdateAction("eligible", false)
        ));

        engine2.executeRules(context2);

        System.out.println("  ✓ After rule execution:");
        System.out.println("    age = " + context2.get("age"));
        System.out.println("    eligible = " + context2.get("eligible") + " (expected: false)");

        // Test Case 3: Multiple updates
        System.out.println("\n  Test Case 3: Multiple updates");
        Context context3 = new Context();
        context3.put("score", 85);

        System.out.println("  Before rules:");
        System.out.println("    score = " + context3.get("score"));
        System.out.println("    grade = " + context3.get("grade"));
        System.out.println("    passed = " + context3.get("passed"));

        RuleEngine engine3 = new RuleEngine();
        engine3.addRule(new SimpleRule(
                new GreaterThanOrEqualCondition("score", 80),
                new UpdateAction("grade", "A")
        ));
        engine3.addRule(new SimpleRule(
                new GreaterThanOrEqualCondition("score", 60),
                new UpdateAction("passed", true)
        ));

        engine3.executeRules(context3);

        System.out.println("  ✓ After rules:");
        System.out.println("    score = " + context3.get("score"));
        System.out.println("    grade = " + context3.get("grade") + " (expected: A)");
        System.out.println("    passed = " + context3.get("passed") + " (expected: true)");
    }

    // Test 12: AndCondition
    static void testAndCondition() {
        System.out.println("Test 12: AndCondition");
        Context context = new Context();
        context.put("age", 25);
        context.put("country", "USA");
        context.put("score", 85);

        // Test AND - all conditions true
        java.util.List<Condition> andConditions1 = java.util.Arrays.asList(
                new GreaterThanCondition("age", 18),
                new EqualsCondition("country", "USA")
        );
        Condition andCondition1 = new AndCondition(andConditions1);
        boolean result1 = andCondition1.check(context);
        System.out.println("  ✓ (age > 18 AND country == USA): " + result1 + " (expected: true)");

        // Test AND - one condition false
        java.util.List<Condition> andConditions2 = java.util.Arrays.asList(
                new GreaterThanCondition("age", 18),
                new EqualsCondition("country", "Canada")
        );
        Condition andCondition2 = new AndCondition(andConditions2);
        boolean result2 = andCondition2.check(context);
        System.out.println("  ✓ (age > 18 AND country == Canada): " + result2 + " (expected: false)");

        // Test AND - multiple conditions
        java.util.List<Condition> andConditions3 = java.util.Arrays.asList(
                new GreaterThanCondition("age", 18),
                new EqualsCondition("country", "USA"),
                new GreaterThanOrEqualCondition("score", 80)
        );
        Condition andCondition3 = new AndCondition(andConditions3);
        boolean result3 = andCondition3.check(context);
        System.out.println("  ✓ (age > 18 AND country == USA AND score >= 80): " + result3 + " (expected: true)");

        System.out.println();
    }

    // Test 13: OrCondition
    static void testOrCondition() {
        System.out.println("Test 13: OrCondition");
        Context context = new Context();
        context.put("age", 15);
        context.put("hasPermission", true);
        context.put("score", 45);

        // Test OR - one condition true
        java.util.List<Condition> orConditions1 = java.util.Arrays.asList(
                new GreaterThanCondition("age", 18),
                new EqualsCondition("hasPermission", true)
        );
        Condition orCondition1 = new OrCondition(orConditions1);
        boolean result1 = orCondition1.check(context);
        System.out.println("  ✓ (age > 18 OR hasPermission == true): " + result1 + " (expected: true)");

        // Test OR - all conditions false
        java.util.List<Condition> orConditions2 = java.util.Arrays.asList(
                new GreaterThanCondition("age", 18),
                new GreaterThanOrEqualCondition("score", 60)
        );
        Condition orCondition2 = new OrCondition(orConditions2);
        boolean result2 = orCondition2.check(context);
        System.out.println("  ✓ (age > 18 OR score >= 60): " + result2 + " (expected: false)");

        // Test OR - multiple conditions, at least one true
        java.util.List<Condition> orConditions3 = java.util.Arrays.asList(
                new GreaterThanCondition("age", 18),
                new GreaterThanOrEqualCondition("score", 60),
                new EqualsCondition("hasPermission", true)
        );
        Condition orCondition3 = new OrCondition(orConditions3);
        boolean result3 = orCondition3.check(context);
        System.out.println("  ✓ (age > 18 OR score >= 60 OR hasPermission == true): " + result3 + " (expected: true)");

        System.out.println();
    }

    // Test 14: Mixed AND/OR Conditions
    static void testMixedAndOrConditions() {
        System.out.println("Test 14: Mixed AND/OR Conditions");

        // Test Case 1: (A AND B) OR C
        // (age > 18 AND country == "USA") OR hasPermission == true
        System.out.println("  Test Case 1: (age > 18 AND country == USA) OR hasPermission == true");
        Context context1 = new Context();
        context1.put("age", 15);
        context1.put("country", "Canada");
        context1.put("hasPermission", true);

        java.util.List<Condition> andPart1 = java.util.Arrays.asList(
                new GreaterThanCondition("age", 18),
                new EqualsCondition("country", "USA")
        );

        java.util.List<Condition> orPart1 = java.util.Arrays.asList(
                new AndCondition(andPart1),
                new EqualsCondition("hasPermission", true)
        );

        Condition mixed1 = new OrCondition(orPart1);
        boolean result1 = mixed1.check(context1);
        System.out.println("    age=15, country=Canada, hasPermission=true");
        System.out.println("    Result: " + result1 + " (expected: true - because hasPermission is true)");

        // Test Case 2: (A OR B) AND C
        // (age < 18 OR score >= 90) AND country == "USA"
        System.out.println("\n  Test Case 2: (age < 18 OR score >= 90) AND country == USA");
        Context context2 = new Context();
        context2.put("age", 25);
        context2.put("score", 95);
        context2.put("country", "USA");

        java.util.List<Condition> orPart2 = java.util.Arrays.asList(
                new LessThanCondition("age", 18),
                new GreaterThanOrEqualCondition("score", 90)
        );

        java.util.List<Condition> andPart2 = java.util.Arrays.asList(
                new OrCondition(orPart2),
                new EqualsCondition("country", "USA")
        );

        Condition mixed2 = new AndCondition(andPart2);
        boolean result2 = mixed2.check(context2);
        System.out.println("    age=25, score=95, country=USA");
        System.out.println("    Result: " + result2 + " (expected: true - score >= 90 AND country is USA)");

        // Test Case 3: (A AND B) OR (C AND D)
        // (age > 18 AND country == "USA") OR (score >= 90 AND hasScholarship == true)
        System.out.println("\n  Test Case 3: (age > 18 AND country == USA) OR (score >= 90 AND hasScholarship == true)");
        Context context3 = new Context();
        context3.put("age", 16);
        context3.put("country", "Canada");
        context3.put("score", 95);
        context3.put("hasScholarship", true);

        java.util.List<Condition> andLeft = java.util.Arrays.asList(
                new GreaterThanCondition("age", 18),
                new EqualsCondition("country", "USA")
        );

        java.util.List<Condition> andRight = java.util.Arrays.asList(
                new GreaterThanOrEqualCondition("score", 90),
                new EqualsCondition("hasScholarship", true)
        );

        java.util.List<Condition> orBoth = java.util.Arrays.asList(
                new AndCondition(andLeft),
                new AndCondition(andRight)
        );

        Condition mixed3 = new OrCondition(orBoth);
        boolean result3 = mixed3.check(context3);
        System.out.println("    age=16, country=Canada, score=95, hasScholarship=true");
        System.out.println("    Result: " + result3 + " (expected: true - right side is true)");

        // Test Case 4: Complex 3-level nesting
        // ((age > 18 OR hasGuardian == true) AND country == "USA") OR isVIP == true
        System.out.println("\n  Test Case 4: ((age > 18 OR hasGuardian == true) AND country == USA) OR isVIP == true");
        Context context4 = new Context();
        context4.put("age", 15);
        context4.put("hasGuardian", false);
        context4.put("country", "USA");
        context4.put("isVIP", true);

        java.util.List<Condition> innerOr = java.util.Arrays.asList(
                new GreaterThanCondition("age", 18),
                new EqualsCondition("hasGuardian", true)
        );

        java.util.List<Condition> middleAnd = java.util.Arrays.asList(
                new OrCondition(innerOr),
                new EqualsCondition("country", "USA")
        );

        java.util.List<Condition> outerOr = java.util.Arrays.asList(
                new AndCondition(middleAnd),
                new EqualsCondition("isVIP", true)
        );

        Condition mixed4 = new OrCondition(outerOr);
        boolean result4 = mixed4.check(context4);
        System.out.println("    age=15, hasGuardian=false, country=USA, isVIP=true");
        System.out.println("    Result: " + result4 + " (expected: true - isVIP is true)");

        // Test Case 5: All conditions false
        System.out.println("\n  Test Case 5: (age > 18 AND country == USA) OR (score >= 90)");
        Context context5 = new Context();
        context5.put("age", 15);
        context5.put("country", "Canada");
        context5.put("score", 70);

        java.util.List<Condition> andPart5 = java.util.Arrays.asList(
                new GreaterThanCondition("age", 18),
                new EqualsCondition("country", "USA")
        );

        java.util.List<Condition> orPart5 = java.util.Arrays.asList(
                new AndCondition(andPart5),
                new GreaterThanOrEqualCondition("score", 90)
        );

        Condition mixed5 = new OrCondition(orPart5);
        boolean result5 = mixed5.check(context5);
        System.out.println("    age=15, country=Canada, score=70");
        System.out.println("    Result: " + result5 + " (expected: false - all conditions fail)");

        System.out.println();
    }

    // Test 15: Phase 5 End-to-End (Requirement #18)
    static void testPhase5EndToEnd() {
        System.out.println("Test 15: Phase 5 End-to-End (Requirement #18)");

        // Test Case 1: if (age > 18 AND country == "USA"), print "Eligible"
        System.out.println("  Test Case 1: age = 25, country = USA");
        Context context1 = new Context();
        context1.put("age", 25);
        context1.put("country", "USA");

        RuleEngine engine1 = new RuleEngine();

        java.util.List<Condition> eligibleConditions = java.util.Arrays.asList(
                new GreaterThanCondition("age", 18),
                new EqualsCondition("country", "USA")
        );

        Rule eligibleRule = new SimpleRule(
                new AndCondition(eligibleConditions),
                new LogAction("Eligible")
        );

        engine1.addRule(eligibleRule);
        System.out.print("  ✓ Output: ");
        engine1.executeRules(context1);
        System.out.println("  ✓ Expected: Eligible");

        // Test Case 2: Should NOT print (age > 18 but country != USA)
        System.out.println("\n  Test Case 2: age = 25, country = Canada");
        Context context2 = new Context();
        context2.put("age", 25);
        context2.put("country", "Canada");

        RuleEngine engine2 = new RuleEngine();
        engine2.addRule(eligibleRule);

        System.out.print("  ✓ Output: ");
        engine2.executeRules(context2);
        System.out.println("  ✓ Expected: (nothing - condition false)");

        // Test Case 3: Complex - OR with AND
        System.out.println("\n  Test Case 3: (age < 18 OR hasGuardian == true) AND country == USA");
        Context context3 = new Context();
        context3.put("age", 15);
        context3.put("hasGuardian", true);
        context3.put("country", "USA");

        RuleEngine engine3 = new RuleEngine();

        // Inner OR: age < 18 OR hasGuardian == true
        java.util.List<Condition> orConditions = java.util.Arrays.asList(
                new LessThanCondition("age", 18),
                new EqualsCondition("hasGuardian", true)
        );

        // Outer AND: (OR result) AND country == USA
        java.util.List<Condition> andConditions = java.util.Arrays.asList(
                new OrCondition(orConditions),
                new EqualsCondition("country", "USA")
        );

        Rule complexRule = new SimpleRule(
                new AndCondition(andConditions),
                new LogAction("Minor with guardian in USA - Eligible")
        );

        engine3.addRule(complexRule);
        System.out.print("  ✓ Output: ");
        engine3.executeRules(context3);
        System.out.println("  ✓ Expected: Minor with guardian in USA - Eligible");
    }
}


