package action;

import model.Context;
import java.util.logging.Logger;
import java.util.logging.Level;

public class UpdateAction implements Action {
    private static final Logger LOGGER = Logger.getLogger(UpdateAction.class.getName());
    private String field;
    private Object value;

    public UpdateAction(String field, Object value) {
        if (field == null || field.trim().isEmpty()) {
            throw new IllegalArgumentException("Field name cannot be null or empty");
        }
        this.field = field;
        this.value = value;
    }

    public void perform(Context context) {
        if (context == null) {
            LOGGER.severe("Context is null in UpdateAction for field: " + field);
            throw new IllegalArgumentException("Context cannot be null");
        }

        try {
            Object oldValue = context.get(field);
            context.put(field, value);
            LOGGER.fine("UpdateAction: " + field + " updated from " + oldValue + " to " + value);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error executing UpdateAction for field: " + field, e);
            throw new RuntimeException("Failed to execute UpdateAction for field: " + field, e);
        }
    }
}

