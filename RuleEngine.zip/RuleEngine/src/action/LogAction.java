package action;

import model.Context;
import java.util.logging.Logger;
import java.util.logging.Level;

public class LogAction implements Action {
    private static final Logger LOGGER = Logger.getLogger(LogAction.class.getName());
    private String message;

    public LogAction(String message) {
        if (message == null) {
            throw new IllegalArgumentException("Log message cannot be null");
        }
        this.message = message;
    }

    public void perform(Context context) {
        if (context == null) {
            LOGGER.warning("Context is null in LogAction. Message: " + message);
            // Still print the message even if context is null
        }

        try {
            System.out.println(message);
            LOGGER.fine("LogAction executed: " + message);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error executing LogAction: " + message, e);
            throw new RuntimeException("Failed to execute LogAction", e);
        }
    }
}

