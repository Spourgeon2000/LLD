package action;

import model.Context;

public interface Action {
    void perform(Context context);
}

