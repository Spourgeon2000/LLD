package rule;

import action.Action;
import condition.Condition;
import model.Context;

public class SimpleRule implements Rule {
    Condition condition;
    Action action;
    
    public SimpleRule(Condition condition, Action action) {
        this.condition = condition;
        this.action = action;
    }
    
    public boolean evaluate(Context context) {
        return condition.check(context);
    }

    public void execute(Context context) {
        action.perform(context);
    }
}

