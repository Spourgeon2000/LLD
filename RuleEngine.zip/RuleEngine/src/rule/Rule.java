package rule;

import model.Context;

public interface Rule {
    boolean evaluate(Context context);

    void execute(Context context);
}

