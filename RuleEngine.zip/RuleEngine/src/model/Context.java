package model;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class Context {
    private static final Logger LOGGER = Logger.getLogger(Context.class.getName());
    private Map<String, Object> data = new HashMap<>();

    public Map<String, Object> getData() {
        return new HashMap<>(data); // Return copy to prevent external modification
    }

    public void setData(Map<String, Object> data) {
        if (data == null) {
            LOGGER.warning("Attempted to set null data in Context. Ignoring.");
            return;
        }
        this.data = new HashMap<>(data); // Create defensive copy
    }

    public void put(String key, Object value) {
        if (key == null || key.trim().isEmpty()) {
            throw new IllegalArgumentException("Key cannot be null or empty");
        }
        data.put(key, value);
        LOGGER.fine("Context: put(" + key + ", " + value + ")");
    }

    public Object get(String key) {
        if (key == null) {
            LOGGER.warning("Attempted to get value with null key");
            return null;
        }
        return data.get(key);
    }

    public boolean contains(String key) {
        if (key == null) {
            return false;
        }
        return data.containsKey(key);
    }
}

