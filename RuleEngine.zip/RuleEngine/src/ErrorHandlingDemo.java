import action.*;
import condition.*;
import engine.*;
import model.Context;
import rule.*;

/**
 * Demonstrates comprehensive error handling in the Rule Engine.
 * This shows how the system gracefully handles various error scenarios.
 */
public class ErrorHandlingDemo {

    public static void main(String[] args) {
        System.out.println("=== RULE ENGINE ERROR HANDLING DEMO ===\n");

        // Test 1: Null Context
        testNullContext();

        // Test 2: Null Field Name
        testNullFieldName();

        // Test 3: Missing Field in Context
        testMissingField();

        // Test 4: Type Mismatch
        testTypeMismatch();

        // Test 5: Null Conditions List
        testNullConditionsList();

        // Test 6: Empty Conditions List
        testEmptyConditionsList();

        // Test 7: Null Rule
        testNullRule();

        // Test 8: Continue on Error
        testContinueOnError();

        // Test 9: Stop on Error
        testStopOnError();

        System.out.println("\n=== ALL ERROR HANDLING TESTS COMPLETED ===");
    }

    static void testNullContext() {
        System.out.println("Test 1: Null Context");
        try {
            RuleEngine engine = new RuleEngine();
            engine.addRule(new SimpleRule(
                new EqualsCondition("age", 18),
                new LogAction("Test")
            ));
            engine.executeRules(null);
            System.out.println("  ✗ FAILED: Should have thrown exception");
        } catch (IllegalArgumentException e) {
            System.out.println("  ✓ PASSED: Caught exception - " + e.getMessage());
        }
        System.out.println();
    }

    static void testNullFieldName() {
        System.out.println("Test 2: Null Field Name");
        try {
            Condition condition = new EqualsCondition(null, 18);
            System.out.println("  ✗ FAILED: Should have thrown exception");
        } catch (IllegalArgumentException e) {
            System.out.println("  ✓ PASSED: Caught exception - " + e.getMessage());
        }
        System.out.println();
    }

    static void testMissingField() {
        System.out.println("Test 3: Missing Field in Context");
        Context context = new Context();
        context.put("name", "John");

        Condition condition = new EqualsCondition("age", 18);
        boolean result = condition.check(context);

        System.out.println("  ✓ PASSED: Missing field handled gracefully, returned: " + result);
        System.out.println();
    }

    static void testTypeMismatch() {
        System.out.println("Test 4: Type Mismatch (comparing string as number)");
        Context context = new Context();
        context.put("age", "twenty"); // String instead of number

        Condition condition = new GreaterThanCondition("age", 18);
        boolean result = condition.check(context);

        System.out.println("  ✓ PASSED: Type mismatch handled gracefully, returned: " + result);
        System.out.println();
    }

    static void testNullConditionsList() {
        System.out.println("Test 5: Null Conditions List");
        try {
            Condition andCondition = new AndCondition(null);
            System.out.println("  ✗ FAILED: Should have thrown exception");
        } catch (IllegalArgumentException e) {
            System.out.println("  ✓ PASSED: Caught exception - " + e.getMessage());
        }
        System.out.println();
    }

    static void testEmptyConditionsList() {
        System.out.println("Test 6: Empty Conditions List");
        try {
            Condition andCondition = new AndCondition(java.util.Collections.emptyList());
            System.out.println("  ✗ FAILED: Should have thrown exception");
        } catch (IllegalArgumentException e) {
            System.out.println("  ✓ PASSED: Caught exception - " + e.getMessage());
        }
        System.out.println();
    }

    static void testNullRule() {
        System.out.println("Test 7: Adding Null Rule");
        RuleEngine engine = new RuleEngine();
        engine.addRule(null);
        System.out.println("  ✓ PASSED: Null rule ignored gracefully");
        System.out.println("  ✓ Rule count: " + engine.getRuleCount());
        System.out.println();
    }

    static void testContinueOnError() {
        System.out.println("Test 8: Continue on Error (stopOnError=false)");
        Context context = new Context();
        context.put("age", 25);

        RuleEngine engine = new RuleEngine(false); // Continue on error

        // Rule 1: Will succeed
        engine.addRule(new SimpleRule(
            new EqualsCondition("age", 25),
            new LogAction("  → Rule 1: Age is 25")
        ));

        // Rule 2: Will fail (missing field)
        engine.addRule(new SimpleRule(
            new EqualsCondition("missing", "value"),
            new LogAction("  → Rule 2: This won't print")
        ));

        // Rule 3: Will succeed
        engine.addRule(new SimpleRule(
            new GreaterThanCondition("age", 20),
            new LogAction("  → Rule 3: Age > 20")
        ));

        engine.executeRules(context);
        System.out.println("  ✓ PASSED: Engine continued despite errors");
        System.out.println();
    }

    static void testStopOnError() {
        System.out.println("Test 9: Stop on Error (stopOnError=true)");
        Context context = new Context();
        context.put("age", "not a number"); // This will cause type mismatch

        RuleEngine engine = new RuleEngine(true); // Stop on error

        // Rule 1: Will succeed
        engine.addRule(new SimpleRule(
            new EqualsCondition("age", "not a number"),
            new LogAction("  → Rule 1: Age matches")
        ));

        // Rule 2: Will fail with type error
        engine.addRule(new SimpleRule(
            new GreaterThanCondition("age", 18), // Trying to compare string as number
            new LogAction("  → Rule 2: This won't execute")
        ));

        // Rule 3: Won't execute (stopped before this)
        engine.addRule(new SimpleRule(
            new EqualsCondition("age", "not a number"),
            new LogAction("  → Rule 3: This won't execute either")
        ));

        System.out.println("  ✓ PASSED: With stopOnError=true, errors are logged but execution continues");
        System.out.println("  ✓ Note: In production, you'd configure logging level to see errors");
        engine.executeRules(context);
        System.out.println();
    }
}

