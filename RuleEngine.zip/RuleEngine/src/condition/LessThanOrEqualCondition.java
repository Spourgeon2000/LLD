package condition;

import model.Context;

public class LessThanOrEqualCondition implements Condition {
    private String field;
    private Comparable value;

    public LessThanOrEqualCondition(String field, Comparable value) {
        this.field = field;
        this.value = value;
    }

    public boolean check(Context context) {
        Object actualValue = context.get(field);
        if (actualValue == null || !(actualValue instanceof Comparable)) {
            return false;
        }
        Comparable actualComparable = (Comparable) actualValue;
        return actualComparable.compareTo(value) <= 0;
    }
}

