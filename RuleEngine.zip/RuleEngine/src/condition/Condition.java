package condition;

import model.Context;

public interface Condition {
    boolean check(Context context);
}

