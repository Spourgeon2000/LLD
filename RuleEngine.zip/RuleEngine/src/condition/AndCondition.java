package condition;

import model.Context;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;

public class AndCondition implements Condition {
    private static final Logger LOGGER = Logger.getLogger(AndCondition.class.getName());
    private List<Condition> conditions;

    public AndCondition(List<Condition> conditions) {
        if (conditions == null) {
            throw new IllegalArgumentException("Conditions list cannot be null");
        }
        if (conditions.isEmpty()) {
            throw new IllegalArgumentException("Conditions list cannot be empty");
        }
        // Check for null conditions in the list
        for (int i = 0; i < conditions.size(); i++) {
            if (conditions.get(i) == null) {
                throw new IllegalArgumentException("Condition at index " + i + " is null");
            }
        }
        this.conditions = conditions;
    }

    public boolean check(Context context) {
        if (context == null) {
            LOGGER.warning("Context is null in AndCondition");
            return false;
        }

        try {
            LOGGER.fine("Evaluating AndCondition with " + conditions.size() + " conditions");

            for (int i = 0; i < conditions.size(); i++) {
                Condition condition = conditions.get(i);
                try {
                    boolean result = condition.check(context);
                    LOGGER.fine("AndCondition[" + i + "]: " + result);

                    if (!result) {
                        LOGGER.fine("AndCondition failed at condition " + i);
                        return false;
                    }
                } catch (Exception e) {
                    LOGGER.log(Level.SEVERE, "Error evaluating condition " + i + " in AndCondition", e);
                    return false; // If any condition throws exception, AND fails
                }
            }

            LOGGER.fine("AndCondition: all conditions passed");
            return true;

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error in AndCondition", e);
            return false;
        }
    }
}

