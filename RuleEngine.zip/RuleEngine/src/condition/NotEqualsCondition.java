package condition;

import model.Context;

public class NotEqualsCondition implements Condition {
    private String field;
    private Object value;

    public NotEqualsCondition(String field, Object value) {
        this.field = field;
        this.value = value;
    }

    public boolean check(Context context) {
        Object actualValue = context.get(field);
        if (actualValue == null) {
            return false;
        }
        return !actualValue.equals(value);
    }
}

