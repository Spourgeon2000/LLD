package condition;

import model.Context;
import java.util.logging.Logger;
import java.util.logging.Level;

public class EqualsCondition implements Condition {
    private static final Logger LOGGER = Logger.getLogger(EqualsCondition.class.getName());
    private String field;
    private Object value;

    public EqualsCondition(String field, Object value) {
        if (field == null || field.trim().isEmpty()) {
            throw new IllegalArgumentException("Field name cannot be null or empty");
        }
        this.field = field;
        this.value = value;
    }

    public boolean check(Context context) {
        if (context == null) {
            LOGGER.warning("Context is null in EqualsCondition for field: " + field);
            return false;
        }

        try {
            Object actualValue = context.get(field);
            if (actualValue == null) {
                LOGGER.fine("Field '" + field + "' not found or is null in context");
                return false;
            }

            boolean result = actualValue.equals(value);
            LOGGER.fine("EqualsCondition: " + field + " == " + value + " => " + result);
            return result;

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error checking EqualsCondition for field: " + field, e);
            return false;
        }
    }
}

