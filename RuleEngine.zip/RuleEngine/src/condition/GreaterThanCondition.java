package condition;

import model.Context;
import java.util.logging.Logger;
import java.util.logging.Level;

public class GreaterThanCondition implements Condition {
    private static final Logger LOGGER = Logger.getLogger(GreaterThanCondition.class.getName());
    private String field;
    private Comparable value;

    public GreaterThanCondition(String field, Comparable value) {
        if (field == null || field.trim().isEmpty()) {
            throw new IllegalArgumentException("Field name cannot be null or empty");
        }
        if (value == null) {
            throw new IllegalArgumentException("Comparison value cannot be null");
        }
        this.field = field;
        this.value = value;
    }

    public boolean check(Context context) {
        if (context == null) {
            LOGGER.warning("Context is null in GreaterThanCondition for field: " + field);
            return false;
        }

        try {
            Object actualValue = context.get(field);

            if (actualValue == null) {
                LOGGER.fine("Field '" + field + "' not found or is null in context");
                return false;
            }

            if (!(actualValue instanceof Comparable)) {
                LOGGER.warning("Field '" + field + "' value is not Comparable: " + actualValue.getClass().getName());
                return false;
            }

            Comparable actualComparable = (Comparable) actualValue;
            boolean result = actualComparable.compareTo(value) > 0;
            LOGGER.fine("GreaterThanCondition: " + field + " > " + value + " => " + result);
            return result;

        } catch (ClassCastException e) {
            LOGGER.log(Level.WARNING, "Type mismatch comparing field '" + field + "': " + e.getMessage(), e);
            return false;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error checking GreaterThanCondition for field: " + field, e);
            return false;
        }
    }
}

