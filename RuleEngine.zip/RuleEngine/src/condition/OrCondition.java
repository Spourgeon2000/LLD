package condition;

import model.Context;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;

public class OrCondition implements Condition {
    private static final Logger LOGGER = Logger.getLogger(OrCondition.class.getName());
    private List<Condition> conditions;

    public OrCondition(List<Condition> conditions) {
        if (conditions == null) {
            throw new IllegalArgumentException("Conditions list cannot be null");
        }
        if (conditions.isEmpty()) {
            throw new IllegalArgumentException("Conditions list cannot be empty");
        }
        // Check for null conditions in the list
        for (int i = 0; i < conditions.size(); i++) {
            if (conditions.get(i) == null) {
                throw new IllegalArgumentException("Condition at index " + i + " is null");
            }
        }
        this.conditions = conditions;
    }

    public boolean check(Context context) {
        if (context == null) {
            LOGGER.warning("Context is null in OrCondition");
            return false;
        }

        try {
            LOGGER.fine("Evaluating OrCondition with " + conditions.size() + " conditions");

            int errorCount = 0;
            for (int i = 0; i < conditions.size(); i++) {
                Condition condition = conditions.get(i);
                try {
                    boolean result = condition.check(context);
                    LOGGER.fine("OrCondition[" + i + "]: " + result);

                    if (result) {
                        LOGGER.fine("OrCondition succeeded at condition " + i);
                        return true;
                    }
                } catch (Exception e) {
                    errorCount++;
                    LOGGER.log(Level.WARNING, "Error evaluating condition " + i + " in OrCondition", e);
                    // Continue checking other conditions
                }
            }

            if (errorCount == conditions.size()) {
                LOGGER.severe("All conditions in OrCondition threw exceptions");
                return false;
            }

            LOGGER.fine("OrCondition: all conditions failed");
            return false;

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error in OrCondition", e);
            return false;
        }
    }
}

