package engine;

import rule.Rule;

/**
 * Exception thrown when a rule execution fails.
 * Contains information about which rule failed and why.
 */
public class RuleExecutionException extends RuntimeException {
    private final Rule failedRule;
    private final int ruleIndex;

    public RuleExecutionException(String message, Throwable cause, Rule failedRule, int ruleIndex) {
        super(message, cause);
        this.failedRule = failedRule;
        this.ruleIndex = ruleIndex;
    }

    public Rule getFailedRule() {
        return failedRule;
    }

    public int getRuleIndex() {
        return ruleIndex;
    }

    @Override
    public String toString() {
        return "RuleExecutionException{" +
                "message='" + getMessage() + '\'' +
                ", ruleIndex=" + ruleIndex +
                ", failedRule=" + (failedRule != null ? failedRule.getClass().getSimpleName() : "null") +
                '}';
    }
}

