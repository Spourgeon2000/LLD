package engine;

import model.Context;
import rule.Rule;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.logging.Level;

public class RuleEngine {
    private static final Logger LOGGER = Logger.getLogger(RuleEngine.class.getName());
    private List<Rule> rules = new ArrayList<>();
    private boolean stopOnError = false; // Continue executing rules even if one fails

    public RuleEngine() {
    }

    public RuleEngine(boolean stopOnError) {
        this.stopOnError = stopOnError;
    }

    public void addRule(Rule rule) {
        if (rule == null) {
            LOGGER.warning("Attempted to add null rule to RuleEngine. Ignoring.");
            return;
        }
        rules.add(rule);
        LOGGER.fine("Rule added: " + rule.getClass().getSimpleName());
    }

    public void executeRules(Context context) {
        if (context == null) {
            LOGGER.severe("Cannot execute rules with null context");
            throw new IllegalArgumentException("Context cannot be null");
        }

        if (rules.isEmpty()) {
            LOGGER.info("No rules to execute");
            return;
        }

        LOGGER.info("Executing " + rules.size() + " rule(s)");
        int successCount = 0;
        int failureCount = 0;

        for (int i = 0; i < rules.size(); i++) {
            Rule rule = rules.get(i);
            try {
                LOGGER.fine("Evaluating rule " + (i + 1) + ": " + rule.getClass().getSimpleName());

                boolean shouldExecute = rule.evaluate(context);

                if (shouldExecute) {
                    LOGGER.fine("Rule " + (i + 1) + " condition met. Executing action...");
                    rule.execute(context);
                    successCount++;
                    LOGGER.fine("Rule " + (i + 1) + " executed successfully");
                } else {
                    LOGGER.fine("Rule " + (i + 1) + " condition not met. Skipping.");
                }

            } catch (Exception e) {
                failureCount++;
                LOGGER.log(Level.SEVERE,
                    "Error executing rule " + (i + 1) + " (" + rule.getClass().getSimpleName() + "): " + e.getMessage(),
                    e);

                if (stopOnError) {
                    LOGGER.severe("Stopping rule execution due to error (stopOnError=true)");
                    throw new RuleExecutionException(
                        "Rule execution failed at rule " + (i + 1) + ": " + e.getMessage(),
                        e,
                        rule,
                        i
                    );
                } else {
                    LOGGER.warning("Continuing to next rule despite error (stopOnError=false)");
                }
            }
        }

        LOGGER.info("Rule execution completed. Success: " + successCount + ", Failures: " + failureCount);
    }

    public int getRuleCount() {
        return rules.size();
    }

    public void clearRules() {
        rules.clear();
        LOGGER.info("All rules cleared");
    }

    public boolean isStopOnError() {
        return stopOnError;
    }

    public void setStopOnError(boolean stopOnError) {
        this.stopOnError = stopOnError;
    }
}

