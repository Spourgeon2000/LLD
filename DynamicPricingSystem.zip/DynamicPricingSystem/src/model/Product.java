package model;

/**
 * Domain model representing a Product in the system.
 * Follows Single Responsibility Principle - only manages product data.
 */
public class Product {
    private final String id;
    private final String name;
    private final double basePrice;
    private double currentPrice;
    private int inventory;
    private int viewCount;
    private int purchaseCount;

    public Product(String id, String name, double basePrice, int inventory) {
        if (basePrice <= 0) {
            throw new IllegalArgumentException("Base price must be positive");
        }
        if (inventory < 0) {
            throw new IllegalArgumentException("Inventory cannot be negative");
        }
        
        this.id = id;
        this.name = name;
        this.basePrice = basePrice;
        this.currentPrice = basePrice;
        this.inventory = inventory;
        this.viewCount = 0;
        this.purchaseCount = 0;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public double getCurrentPrice() {
        return currentPrice;
    }

    public int getInventory() {
        return inventory;
    }

    public int getViewCount() {
        return viewCount;
    }

    public int getPurchaseCount() {
        return purchaseCount;
    }

    // Business methods
    public void incrementViews() {
        this.viewCount++;
    }

    public void incrementPurchases(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Purchase quantity must be positive");
        }
        if (quantity > inventory) {
            throw new IllegalStateException("Insufficient inventory. Available: " + inventory);
        }
        this.purchaseCount += quantity;
        this.inventory -= quantity;
    }

    public void setCurrentPrice(double price) {
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be negative");
        }
        this.currentPrice = price;
    }

    @Override
    public String toString() {
        return String.format("Product{id='%s', name='%s', basePrice=%.2f, currentPrice=%.2f, inventory=%d}",
                id, name, basePrice, currentPrice, inventory);
    }
}

