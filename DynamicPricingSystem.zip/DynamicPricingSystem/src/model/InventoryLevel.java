package model;

/**
 * Enum representing inventory levels for products.
 */
public enum InventoryLevel {
    LOW(1.2, "Low stock"),
    MEDIUM(1.1, "Medium stock"),
    HIGH(1.0, "High stock");

    private final double multiplier;
    private final String description;

    InventoryLevel(double multiplier, String description) {
        this.multiplier = multiplier;
        this.description = description;
    }

    public double getMultiplier() {
        return multiplier;
    }

    public String getDescription() {
        return description;
    }

    public static InventoryLevel fromInventory(int inventory) {
        if (inventory < 20) {
            return LOW;
        } else if (inventory <= 50) {
            return MEDIUM;
        } else {
            return HIGH;
        }
    }
}

