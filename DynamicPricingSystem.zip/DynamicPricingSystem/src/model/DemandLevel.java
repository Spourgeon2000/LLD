package model;

/**
 * Enum representing demand levels for products.
 */
public enum DemandLevel {
    LOW(1.0, "Low demand"),
    MEDIUM(1.2, "Medium demand"),
    HIGH(1.5, "High demand");

    private final double multiplier;
    private final String description;

    DemandLevel(double multiplier, String description) {
        this.multiplier = multiplier;
        this.description = description;
    }

    public double getMultiplier() {
        return multiplier;
    }

    public String getDescription() {
        return description;
    }

    public static DemandLevel fromScore(int demandScore) {
        if (demandScore < 50) {
            return LOW;
        } else if (demandScore <= 150) {
            return MEDIUM;
        } else {
            return HIGH;
        }
    }
}

