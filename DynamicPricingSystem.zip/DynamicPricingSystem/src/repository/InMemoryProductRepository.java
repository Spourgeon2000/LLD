package repository;

import model.Product;

import java.util.*;

/**
 * In-memory implementation of ProductRepository.
 * Follows Single Responsibility Principle - only handles data storage.
 */
public class InMemoryProductRepository implements ProductRepository {
    private final Map<String, Product> products;

    public InMemoryProductRepository() {
        this.products = new HashMap<>();
    }

    @Override
    public void save(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null");
        }
        products.put(product.getId(), product);
    }

    @Override
    public Optional<Product> findById(String id) {
        return Optional.ofNullable(products.get(id));
    }

    @Override
    public Collection<Product> findAll() {
        return new ArrayList<>(products.values());
    }

    @Override
    public boolean exists(String id) {
        return products.containsKey(id);
    }

    @Override
    public void delete(String id) {
        products.remove(id);
    }
}

