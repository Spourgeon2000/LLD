package repository;

import model.Product;

import java.util.Collection;
import java.util.Optional;

/**
 * Repository Pattern: Interface for product data access.
 * Follows:
 * - Interface Segregation: Only methods needed for product storage
 * - Dependency Inversion: Service layer depends on this abstraction
 */
public interface ProductRepository {
    /**
     * Add a product to the repository.
     */
    void save(Product product);
    
    /**
     * Find a product by its ID.
     */
    Optional<Product> findById(String id);
    
    /**
     * Get all products.
     */
    Collection<Product> findAll();
    
    /**
     * Check if a product exists.
     */
    boolean exists(String id);
    
    /**
     * Remove a product.
     */
    void delete(String id);
}

