package engine;

import model.DemandLevel;
import model.InventoryLevel;
import model.Product;
import strategy.DemandBasedPricingStrategy;
import strategy.InventoryBasedPricingStrategy;
import strategy.PricingStrategy;

import java.util.List;

/**
 * Value object that represents a detailed pricing breakdown.
 * Shows how each factor contributes to the final price.
 */
public class PricingBreakdown {
    private final Product product;
    private final double basePrice;
    private final double combinedMultiplier;
    private final double calculatedPrice;
    private final double finalPrice;
    private final DemandLevel demandLevel;
    private final InventoryLevel inventoryLevel;
    private final int demandScore;

    public PricingBreakdown(Product product, List<PricingStrategy> strategies, 
                           double minMultiplier, double maxMultiplier) {
        this.product = product;
        this.basePrice = product.getBasePrice();
        
        // Calculate combined multiplier
        double multiplier = 1.0;
        DemandLevel demand = null;
        InventoryLevel inventory = null;
        int score = 0;
        
        for (PricingStrategy strategy : strategies) {
            multiplier *= strategy.calculateMultiplier(product);
            
            // Extract specific strategy information
            if (strategy instanceof DemandBasedPricingStrategy) {
                DemandBasedPricingStrategy demandStrategy = (DemandBasedPricingStrategy) strategy;
                demand = demandStrategy.getDemandLevel(product);
                score = demandStrategy.getDemandScore(product);
            } else if (strategy instanceof InventoryBasedPricingStrategy) {
                InventoryBasedPricingStrategy inventoryStrategy = (InventoryBasedPricingStrategy) strategy;
                inventory = inventoryStrategy.getInventoryLevel(product);
            }
        }
        
        this.combinedMultiplier = multiplier;
        this.calculatedPrice = basePrice * multiplier;
        
        // Apply constraints
        double minPrice = basePrice * minMultiplier;
        double maxPrice = basePrice * maxMultiplier;
        this.finalPrice = Math.max(minPrice, Math.min(calculatedPrice, maxPrice));
        
        this.demandLevel = demand;
        this.inventoryLevel = inventory;
        this.demandScore = score;
    }

    public void display() {
        System.out.println("\n" + "=".repeat(60));
        System.out.printf("Pricing Breakdown: %s\n", product.getName());
        System.out.println("=".repeat(60));
        System.out.printf("Base Price:        $%.2f\n", basePrice);
        
        if (demandLevel != null) {
            System.out.printf("Demand Level:      %s (score: %d) → %.1fx\n", 
                demandLevel.name(), demandScore, demandLevel.getMultiplier());
        }
        
        if (inventoryLevel != null) {
            System.out.printf("Inventory Level:   %s (%d units) → %.1fx\n", 
                inventoryLevel.name(), product.getInventory(), inventoryLevel.getMultiplier());
        }
        
        System.out.printf("Combined Multiplier: %.2fx\n", combinedMultiplier);
        System.out.printf("Calculated Price:  $%.2f\n", calculatedPrice);
        System.out.printf("Final Price:       $%.2f", finalPrice);
        
        if (finalPrice != calculatedPrice) {
            System.out.printf(" (capped at %.0fx base price)", finalPrice / basePrice);
        }
        System.out.println("\n" + "=".repeat(60));
    }

    // Getters
    public double getFinalPrice() {
        return finalPrice;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public DemandLevel getDemandLevel() {
        return demandLevel;
    }

    public InventoryLevel getInventoryLevel() {
        return inventoryLevel;
    }
}

