package engine;

import model.Product;
import strategy.PricingStrategy;

import java.util.ArrayList;
import java.util.List;

/**
 * Pricing Engine that uses Strategy Pattern to calculate dynamic prices.
 * Follows:
 * - Single Responsibility: Only calculates prices
 * - Open/Closed: Can add new strategies without modifying this class
 * - Dependency Inversion: Depends on PricingStrategy abstraction, not concrete implementations
 */
public class PricingEngine {
    private final List<PricingStrategy> strategies;
    private final double minPriceMultiplier;
    private final double maxPriceMultiplier;

    public PricingEngine(List<PricingStrategy> strategies) {
        this(strategies, 1.0, 2.0);
    }

    public PricingEngine(List<PricingStrategy> strategies, double minMultiplier, double maxMultiplier) {
        if (strategies == null || strategies.isEmpty()) {
            throw new IllegalArgumentException("At least one pricing strategy is required");
        }
        this.strategies = new ArrayList<>(strategies);
        this.minPriceMultiplier = minMultiplier;
        this.maxPriceMultiplier = maxMultiplier;
    }

    /**
     * Calculate the dynamic price for a product using all configured strategies.
     * Combines all strategy multipliers and applies constraints.
     */
    public double calculatePrice(Product product) {
        double basePrice = product.getBasePrice();
        double combinedMultiplier = 1.0;

        // Apply all strategies
        for (PricingStrategy strategy : strategies) {
            combinedMultiplier *= strategy.calculateMultiplier(product);
        }

        // Calculate price
        double calculatedPrice = basePrice * combinedMultiplier;

        // Apply constraints: price must be between min and max multipliers of base price
        double minPrice = basePrice * minPriceMultiplier;
        double maxPrice = basePrice * maxPriceMultiplier;

        return Math.max(minPrice, Math.min(calculatedPrice, maxPrice));
    }

    /**
     * Get detailed pricing breakdown showing how each strategy affects the price.
     */
    public PricingBreakdown getPricingBreakdown(Product product) {
        return new PricingBreakdown(product, strategies, minPriceMultiplier, maxPriceMultiplier);
    }

    public List<PricingStrategy> getStrategies() {
        return new ArrayList<>(strategies);
    }
}

