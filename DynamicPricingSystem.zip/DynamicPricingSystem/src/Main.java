import engine.PricingEngine;
import model.Product;
import repository.InMemoryProductRepository;
import repository.ProductRepository;
import service.PricingService;
import strategy.DemandBasedPricingStrategy;
import strategy.InventoryBasedPricingStrategy;
import strategy.PricingStrategy;

import java.util.Arrays;
import java.util.List;

/**
 * Main application demonstrating the Dynamic Pricing System.
 *
 * Design Patterns Used:
 * 1. Strategy Pattern - Different pricing strategies (Demand, Inventory)
 * 2. Repository Pattern - Data access abstraction
 * 3. Dependency Injection - Constructor injection for loose coupling
 *
 * SOLID Principles Applied:
 * 1. Single Responsibility - Each class has one reason to change
 * 2. Open/Closed - Open for extension (new strategies), closed for modification
 * 3. Liskov Substitution - Can substitute any PricingStrategy implementation
 * 4. Interface Segregation - Small, focused interfaces
 * 5. Dependency Inversion - Depend on abstractions, not concrete classes
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════════════════════════╗");
        System.out.println("║        DYNAMIC PRICING SYSTEM - DEMONSTRATION             ║");
        System.out.println("╚════════════════════════════════════════════════════════════╝");

        // Setup: Create dependencies using Dependency Injection
        PricingService pricingService = createPricingService();

        // Phase 1: Add Products
        System.out.println("\n📦 PHASE 1: Adding Products to System");
        System.out.println("─".repeat(60));
        addInitialProducts(pricingService);

        // Phase 2: Display Initial State
        System.out.println("\n💰 PHASE 2: Initial Product Prices");
        System.out.println("─".repeat(60));
        displayAllProducts(pricingService);

        // Phase 3: Simulate User Activity
        System.out.println("\n🎯 PHASE 3: Simulating User Activity");
        System.out.println("─".repeat(60));
        simulateUserActivity(pricingService);

        // Phase 4: Display Updated Prices
        System.out.println("\n💰 PHASE 4: Updated Product Prices");
        System.out.println("─".repeat(60));
        displayAllProducts(pricingService);

        // Phase 5: Detailed Pricing Breakdown
        System.out.println("\n📊 PHASE 5: Detailed Pricing Breakdown");
        displayDetailedBreakdowns(pricingService);

        // Summary
        System.out.println("\n✅ DEMONSTRATION COMPLETE!");
        System.out.println("─".repeat(60));
        System.out.println("Design Patterns Demonstrated:");
        System.out.println("  ✓ Strategy Pattern (Pricing Strategies)");
        System.out.println("  ✓ Repository Pattern (Data Access)");
        System.out.println("  ✓ Dependency Injection (Loose Coupling)");
        System.out.println("\nSOLID Principles Applied:");
        System.out.println("  ✓ Single Responsibility Principle");
        System.out.println("  ✓ Open/Closed Principle");
        System.out.println("  ✓ Liskov Substitution Principle");
        System.out.println("  ✓ Interface Segregation Principle");
        System.out.println("  ✓ Dependency Inversion Principle");
    }

    /**
     * Factory method to create PricingService with all dependencies.
     * Demonstrates Dependency Injection pattern.
     */
    private static PricingService createPricingService() {
        // Create repository
        ProductRepository repository = new InMemoryProductRepository();

        // Create pricing strategies
        List<PricingStrategy> strategies = Arrays.asList(
            new DemandBasedPricingStrategy(),
            new InventoryBasedPricingStrategy()
        );

        // Create pricing engine with strategies
        PricingEngine pricingEngine = new PricingEngine(strategies);

        // Create and return service with injected dependencies
        return new PricingService(repository, pricingEngine);
    }

    /**
     * Add initial products with different characteristics.
     */
    private static void addInitialProducts(PricingService service) {
        service.addProduct("P001", "iPhone 15 Pro", 999.0, 45);
        System.out.println("✓ Added: iPhone 15 Pro (Base: $999, Inventory: 45)");

        service.addProduct("P002", "Samsung Galaxy S24", 899.0, 15);
        System.out.println("✓ Added: Samsung Galaxy S24 (Base: $899, Inventory: 15)");

        service.addProduct("P003", "Google Pixel 8", 699.0, 80);
        System.out.println("✓ Added: Google Pixel 8 (Base: $699, Inventory: 80)");

        service.addProduct("P004", "OnePlus 12", 799.0, 25);
        System.out.println("✓ Added: OnePlus 12 (Base: $799, Inventory: 25)");
    }

    /**
     * Display all products with their current prices.
     */
    private static void displayAllProducts(PricingService service) {
        for (Product product : service.getAllProducts()) {
            System.out.printf("%-20s | Base: $%7.2f | Current: $%7.2f | Stock: %3d | Views: %3d | Purchases: %3d\n",
                product.getName(),
                product.getBasePrice(),
                product.getCurrentPrice(),
                product.getInventory(),
                product.getViewCount(),
                product.getPurchaseCount()
            );
        }
    }

    /**
     * Simulate realistic user activity.
     */
    private static void simulateUserActivity(PricingService service) {
        // iPhone: High demand, medium stock -> high price
        System.out.println("\n📱 iPhone 15 Pro - Simulating HIGH demand...");
        for (int i = 0; i < 100; i++) {
            service.recordView("P001");
        }
        for (int i = 0; i < 20; i++) {
            service.recordPurchase("P001", 1);
        }
        System.out.println("   ✓ 100 views, 20 purchases (Inventory: 45 → 25)");

        // Samsung: Medium demand, low stock -> high price
        System.out.println("\n📱 Samsung Galaxy S24 - Simulating MEDIUM demand...");
        for (int i = 0; i < 30; i++) {
            service.recordView("P002");
        }
        for (int i = 0; i < 5; i++) {
            service.recordPurchase("P002", 1);
        }
        System.out.println("   ✓ 30 views, 5 purchases (Inventory: 15 → 10)");

        // Google Pixel: Low demand, high stock -> base price
        System.out.println("\n📱 Google Pixel 8 - Simulating LOW demand...");
        for (int i = 0; i < 10; i++) {
            service.recordView("P003");
        }
        System.out.println("   ✓ 10 views, 0 purchases (Inventory: 80)");

        // OnePlus: Medium demand, medium stock -> moderate price
        System.out.println("\n📱 OnePlus 12 - Simulating MEDIUM demand...");
        for (int i = 0; i < 60; i++) {
            service.recordView("P004");
        }
        for (int i = 0; i < 3; i++) {
            service.recordPurchase("P004", 1);
        }
        System.out.println("   ✓ 60 views, 3 purchases (Inventory: 25 → 22)");
    }

    /**
     * Display detailed pricing breakdown for each product.
     */
    private static void displayDetailedBreakdowns(PricingService service) {
        service.displayPricingBreakdown("P001");
        service.displayPricingBreakdown("P002");
        service.displayPricingBreakdown("P003");
        service.displayPricingBreakdown("P004");
    }
}