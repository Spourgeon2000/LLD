package service;

import engine.PricingBreakdown;
import engine.PricingEngine;
import model.Product;
import repository.ProductRepository;

import java.util.Collection;

/**
 * Service layer for managing products and pricing.
 * Follows:
 * - Single Responsibility: Orchestrates pricing operations
 * - Dependency Inversion: Depends on abstractions (ProductRepository, PricingEngine)
 * - Open/Closed: Can extend functionality without modifying existing code
 */
public class PricingService {
    private final ProductRepository productRepository;
    private final PricingEngine pricingEngine;

    /**
     * Constructor injection for dependencies.
     * Follows Dependency Inversion Principle.
     */
    public PricingService(ProductRepository productRepository, PricingEngine pricingEngine) {
        if (productRepository == null || pricingEngine == null) {
            throw new IllegalArgumentException("Dependencies cannot be null");
        }
        this.productRepository = productRepository;
        this.pricingEngine = pricingEngine;
    }

    /**
     * Add a new product to the system.
     */
    public void addProduct(String id, String name, double basePrice, int inventory) {
        if (productRepository.exists(id)) {
            throw new IllegalArgumentException("Product with ID " + id + " already exists");
        }
        
        Product product = new Product(id, name, basePrice, inventory);
        productRepository.save(product);
        updatePrice(id);
    }

    /**
     * Record a view for a product and update its price.
     */
    public void recordView(String id) {
        Product product = getProductOrThrow(id);
        product.incrementViews();
        updatePrice(id);
    }

    /**
     * Record a purchase for a product, update inventory, and recalculate price.
     */
    public void recordPurchase(String id, int quantity) {
        Product product = getProductOrThrow(id);
        product.incrementPurchases(quantity);
        updatePrice(id);
    }

    /**
     * Update the price of a product based on current pricing strategies.
     */
    public void updatePrice(String id) {
        Product product = getProductOrThrow(id);
        double newPrice = pricingEngine.calculatePrice(product);
        product.setCurrentPrice(newPrice);
    }

    /**
     * Get the current price of a product.
     */
    public double getPrice(String id) {
        Product product = getProductOrThrow(id);
        return product.getCurrentPrice();
    }

    /**
     * Get a product by ID.
     */
    public Product getProduct(String id) {
        return getProductOrThrow(id);
    }

    /**
     * Get all products.
     */
    public Collection<Product> getAllProducts() {
        return productRepository.findAll();
    }

    /**
     * Display detailed pricing breakdown for a product.
     */
    public void displayPricingBreakdown(String id) {
        Product product = getProductOrThrow(id);
        PricingBreakdown breakdown = pricingEngine.getPricingBreakdown(product);
        breakdown.display();
    }

    /**
     * Update all product prices.
     */
    public void updateAllPrices() {
        for (Product product : productRepository.findAll()) {
            updatePrice(product.getId());
        }
    }

    /**
     * Helper method to get product or throw exception.
     */
    private Product getProductOrThrow(String id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + id));
    }
}

