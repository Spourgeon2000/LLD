package strategy;

import model.Product;

/**
 * Strategy Pattern: Interface for different pricing strategies.
 * Follows Open/Closed Principle - open for extension, closed for modification.
 */
public interface PricingStrategy {
    /**
     * Calculate the price multiplier for a product.
     * @param product The product to calculate multiplier for
     * @return The multiplier to apply to the base price
     */
    double calculateMultiplier(Product product);
    
    /**
     * Get the name of this pricing strategy.
     * @return Strategy name
     */
    String getStrategyName();
}

