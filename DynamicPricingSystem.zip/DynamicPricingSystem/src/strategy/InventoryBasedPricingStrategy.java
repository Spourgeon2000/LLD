package strategy;

import model.InventoryLevel;
import model.Product;

/**
 * Concrete Strategy: Calculates pricing based on inventory levels.
 * Follows Single Responsibility Principle - only handles inventory-based pricing.
 */
public class InventoryBasedPricingStrategy implements PricingStrategy {
    
    @Override
    public double calculateMultiplier(Product product) {
        InventoryLevel inventoryLevel = InventoryLevel.fromInventory(product.getInventory());
        return inventoryLevel.getMultiplier();
    }
    
    @Override
    public String getStrategyName() {
        return "Inventory-Based Pricing";
    }
    
    public InventoryLevel getInventoryLevel(Product product) {
        return InventoryLevel.fromInventory(product.getInventory());
    }
}

