package strategy;

import model.DemandLevel;
import model.Product;

/**
 * Concrete Strategy: Calculates pricing based on demand (views and purchases).
 * Follows Single Responsibility Principle - only handles demand-based pricing.
 */
public class DemandBasedPricingStrategy implements PricingStrategy {
    
    @Override
    public double calculateMultiplier(Product product) {
        int demandScore = calculateDemandScore(product);
        DemandLevel demandLevel = DemandLevel.fromScore(demandScore);
        return demandLevel.getMultiplier();
    }
    
    @Override
    public String getStrategyName() {
        return "Demand-Based Pricing";
    }
    
    /**
     * Calculate demand score based on views and purchases.
     * Purchases are weighted more heavily (10x) than views.
     */
    private int calculateDemandScore(Product product) {
        return product.getViewCount() + (product.getPurchaseCount() * 10);
    }
    
    public DemandLevel getDemandLevel(Product product) {
        int demandScore = calculateDemandScore(product);
        return DemandLevel.fromScore(demandScore);
    }
    
    public int getDemandScore(Product product) {
        return calculateDemandScore(product);
    }
}

