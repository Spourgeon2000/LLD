# Dynamic Pricing System - Design Documentation

## Overview
This is a production-ready Dynamic Pricing System implemented in Java, demonstrating best practices in software design including SOLID principles and design patterns.

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Main Application                      │
│                  (Dependency Injection)                  │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│                  PricingService                          │
│              (Business Logic Layer)                      │
└──────────┬──────────────────────────┬───────────────────┘
           │                          │
           ▼                          ▼
┌──────────────────────┐   ┌──────────────────────────────┐
│  ProductRepository   │   │     PricingEngine            │
│  (Data Access)       │   │  (Strategy Composition)      │
└──────────────────────┘   └──────────┬───────────────────┘
                                      │
                    ┌─────────────────┴─────────────────┐
                    ▼                                   ▼
         ┌──────────────────────┐        ┌──────────────────────┐
         │ DemandBasedPricing   │        │ InventoryBasedPricing│
         │     Strategy         │        │      Strategy        │
         └──────────────────────┘        └──────────────────────┘
```

## Design Patterns

### 1. Strategy Pattern
**Location**: `strategy` package

**Purpose**: Encapsulate different pricing algorithms and make them interchangeable.

**Implementation**:
- `PricingStrategy` - Interface defining the contract
- `DemandBasedPricingStrategy` - Calculates price based on views/purchases
- `InventoryBasedPricingStrategy` - Calculates price based on stock levels

**Benefits**:
- Easy to add new pricing strategies without modifying existing code
- Each strategy is independently testable
- Strategies can be combined or swapped at runtime

**Example**:
```java
List<PricingStrategy> strategies = Arrays.asList(
    new DemandBasedPricingStrategy(),
    new InventoryBasedPricingStrategy()
);
PricingEngine engine = new PricingEngine(strategies);
```

### 2. Repository Pattern
**Location**: `repository` package

**Purpose**: Abstract data access logic and provide a collection-like interface.

**Implementation**:
- `ProductRepository` - Interface defining data operations
- `InMemoryProductRepository` - Concrete implementation using HashMap

**Benefits**:
- Decouples business logic from data storage
- Easy to swap implementations (e.g., database, file system)
- Simplifies testing with mock repositories

**Example**:
```java
ProductRepository repo = new InMemoryProductRepository();
repo.save(product);
Optional<Product> found = repo.findById("P001");
```

### 3. Dependency Injection
**Location**: `Main.java`, `PricingService.java`

**Purpose**: Achieve loose coupling by injecting dependencies through constructors.

**Implementation**:
- Constructor injection in `PricingService`
- Factory method in `Main` to wire dependencies

**Benefits**:
- Loose coupling between components
- Easy to test with mock dependencies
- Clear dependency graph

**Example**:
```java
public PricingService(ProductRepository repository, PricingEngine engine) {
    this.productRepository = repository;
    this.pricingEngine = engine;
}
```

## SOLID Principles

### 1. Single Responsibility Principle (SRP)
**Each class has one reason to change.**

- `Product` - Only manages product data
- `DemandBasedPricingStrategy` - Only calculates demand-based pricing
- `InventoryBasedPricingStrategy` - Only calculates inventory-based pricing
- `ProductRepository` - Only handles data storage
- `PricingEngine` - Only orchestrates pricing calculation
- `PricingService` - Only coordinates business operations

### 2. Open/Closed Principle (OCP)
**Open for extension, closed for modification.**

**Example**: Adding a new pricing strategy
```java
// Add new strategy without modifying existing code
public class TimeBasedPricingStrategy implements PricingStrategy {
    @Override
    public double calculateMultiplier(Product product) {
        // Peak hours pricing logic
        return isPeakHour() ? 1.3 : 1.0;
    }
}

// Use it
strategies.add(new TimeBasedPricingStrategy());
```

### 3. Liskov Substitution Principle (LSP)
**Subtypes must be substitutable for their base types.**

- Any `PricingStrategy` implementation can be used interchangeably
- Any `ProductRepository` implementation can replace another
- No unexpected behavior when substituting implementations

### 4. Interface Segregation Principle (ISP)
**Clients should not depend on interfaces they don't use.**

- `PricingStrategy` - Small, focused interface (2 methods)
- `ProductRepository` - Only essential CRUD operations
- No "fat" interfaces with unused methods

### 5. Dependency Inversion Principle (DIP)
**Depend on abstractions, not concretions.**

**High-level modules** (PricingService) depend on **abstractions** (PricingStrategy, ProductRepository)

```java
// Good: Depends on abstraction
public class PricingService {
    private final ProductRepository repository;  // Interface
    private final PricingEngine engine;          // Concrete, but uses abstractions
}

// Not: Depends on concrete class
// private final InMemoryProductRepository repository;  ❌
```

## Class Responsibilities

### Domain Layer (`model` package)
- `Product` - Product entity with business rules
- `DemandLevel` - Enum for demand categorization
- `InventoryLevel` - Enum for inventory categorization

### Strategy Layer (`strategy` package)
- `PricingStrategy` - Strategy interface
- `DemandBasedPricingStrategy` - Demand pricing implementation
- `InventoryBasedPricingStrategy` - Inventory pricing implementation

### Engine Layer (`engine` package)
- `PricingEngine` - Orchestrates pricing strategies
- `PricingBreakdown` - Value object for pricing details

### Repository Layer (`repository` package)
- `ProductRepository` - Data access interface
- `InMemoryProductRepository` - In-memory implementation

### Service Layer (`service` package)
- `PricingService` - Business logic orchestration

## Key Features

1. **Dynamic Pricing**: Prices adjust based on demand and inventory
2. **Extensible**: Easy to add new pricing factors
3. **Testable**: All components are independently testable
4. **Type-Safe**: Uses enums for levels, avoiding magic strings
5. **Immutable Where Possible**: Product ID, name, basePrice are final
6. **Validation**: Input validation at boundaries
7. **Error Handling**: Meaningful exceptions with clear messages

## How to Extend

### Adding a New Pricing Strategy

1. Create new strategy class:
```java
public class CompetitorBasedPricingStrategy implements PricingStrategy {
    @Override
    public double calculateMultiplier(Product product) {
        // Your logic here
        return 1.0;
    }
    
    @Override
    public String getStrategyName() {
        return "Competitor-Based Pricing";
    }
}
```

2. Add to strategy list in Main:
```java
strategies.add(new CompetitorBasedPricingStrategy());
```

### Adding a New Repository Implementation

```java
public class DatabaseProductRepository implements ProductRepository {
    // Implement using JDBC, JPA, etc.
}
```

## Testing Strategy

Each component can be tested independently:

- **Unit Tests**: Test each strategy, repository, engine separately
- **Integration Tests**: Test PricingService with real dependencies
- **Mock Tests**: Use mock repository and strategies for service tests

## Performance Considerations

- In-memory storage for fast access
- O(1) product lookup by ID
- Lazy price calculation (only when needed)
- No unnecessary object creation

## Future Enhancements

1. Add persistence (database integration)
2. Add caching for frequently accessed products
3. Add event-driven price updates
4. Add price history tracking
5. Add A/B testing framework
6. Add REST API layer
7. Add authentication/authorization

