# Dynamic Pricing System

A production-ready Dynamic Pricing System implemented in Java, demonstrating **SOLID principles** and **Design Patterns** for machine coding interviews.

## 🎯 Features

- **Dynamic Pricing**: Automatically adjusts prices based on demand and inventory
- **Extensible Architecture**: Easy to add new pricing strategies
- **SOLID Principles**: All five principles demonstrated
- **Design Patterns**: Strategy, Repository, Dependency Injection
- **Type-Safe**: Uses enums instead of magic strings/numbers
- **Well-Tested**: Each component is independently testable

## 🏗️ Architecture

```
Main (DI Container)
    ↓
PricingService (Business Logic)
    ├── ProductRepository (Data Access)
    │   └── InMemoryProductRepository
    └── PricingEngine (Strategy Orchestrator)
        ├── DemandBasedPricingStrategy
        └── InventoryBasedPricingStrategy
```

## 📦 Project Structure

```
src/
├── model/                      # Domain models
│   ├── Product.java           # Product entity
│   ├── DemandLevel.java       # Demand level enum
│   └── InventoryLevel.java    # Inventory level enum
├── strategy/                   # Strategy Pattern
│   ├── PricingStrategy.java   # Strategy interface
│   ├── DemandBasedPricingStrategy.java
│   └── InventoryBasedPricingStrategy.java
├── engine/                     # Pricing calculation
│   ├── PricingEngine.java     # Strategy orchestrator
│   └── PricingBreakdown.java  # Value object
├── repository/                 # Repository Pattern
│   ├── ProductRepository.java # Repository interface
│   └── InMemoryProductRepository.java
├── service/                    # Service layer
│   └── PricingService.java    # Business logic
└── Main.java                   # Application entry point
```

## 🚀 How to Run

### Compile
```bash
javac -d out src/model/*.java src/strategy/*.java src/engine/*.java src/repository/*.java src/service/*.java src/Main.java
```

### Run
```bash
java -cp out Main
```

## 💡 Design Patterns

### 1. Strategy Pattern
Different pricing algorithms are encapsulated as strategies:
- `DemandBasedPricingStrategy` - Prices based on views/purchases
- `InventoryBasedPricingStrategy` - Prices based on stock levels

**Benefits**: Easy to add new strategies without modifying existing code.

### 2. Repository Pattern
Data access is abstracted through `ProductRepository` interface:
- Decouples business logic from data storage
- Easy to swap implementations (in-memory, database, etc.)

### 3. Dependency Injection
Dependencies are injected through constructors:
- Loose coupling between components
- Easy to test with mock dependencies

## 🎓 SOLID Principles

### Single Responsibility Principle (SRP)
Each class has one reason to change:
- `Product` - Manages product data only
- `DemandBasedPricingStrategy` - Calculates demand pricing only
- `ProductRepository` - Handles data storage only

### Open/Closed Principle (OCP)
Open for extension, closed for modification:
```java
// Add new strategy without modifying existing code
public class TimeBasedPricingStrategy implements PricingStrategy {
    // Implementation
}
```

### Liskov Substitution Principle (LSP)
Any `PricingStrategy` implementation can be substituted:
```java
PricingStrategy strategy = new DemandBasedPricingStrategy();
// Can be replaced with any other strategy
strategy = new InventoryBasedPricingStrategy();
```

### Interface Segregation Principle (ISP)
Small, focused interfaces:
- `PricingStrategy` - Only 2 methods
- `ProductRepository` - Only essential CRUD operations

### Dependency Inversion Principle (DIP)
Depend on abstractions, not concretions:
```java
public class PricingService {
    private final ProductRepository repository;  // Interface, not concrete class
    private final PricingEngine engine;
}
```

## 📊 Pricing Logic

### Demand-Based Pricing
- **Demand Score** = views + (purchases × 10)
- **Low** (score < 50): 1.0x multiplier
- **Medium** (50-150): 1.2x multiplier
- **High** (> 150): 1.5x multiplier

### Inventory-Based Pricing
- **High Stock** (> 50 units): 1.0x multiplier
- **Medium Stock** (20-50 units): 1.1x multiplier
- **Low Stock** (< 20 units): 1.2x multiplier

### Final Price Calculation
```
final_price = base_price × demand_multiplier × inventory_multiplier
final_price = min(max(final_price, base_price), base_price × 2)
```

## 🧪 Example Output

```
iPhone 15 Pro - $1,648.35
  Base Price: $999.00
  Demand: HIGH (score: 300) → 1.5x
  Inventory: MEDIUM (25 units) → 1.1x
  Combined Multiplier: 1.65x
  Final Price: $1,648.35
```

## 🔧 How to Extend

### Adding a New Pricing Strategy

1. Create a new strategy class:
```java
public class CompetitorBasedPricingStrategy implements PricingStrategy {
    @Override
    public double calculateMultiplier(Product product) {
        // Your logic here
        return 1.0;
    }
    
    @Override
    public String getStrategyName() {
        return "Competitor-Based Pricing";
    }
}
```

2. Add it to the strategy list in `Main.java`:
```java
strategies.add(new CompetitorBasedPricingStrategy());
```

### Adding a Database Repository

```java
public class DatabaseProductRepository implements ProductRepository {
    // Implement using JDBC, JPA, etc.
    @Override
    public void save(Product product) {
        // Database save logic
    }
    // ... other methods
}
```

## 📝 Key Takeaways for Interviews

1. **Separation of Concerns**: Each layer has a clear responsibility
2. **Testability**: All components can be tested independently
3. **Extensibility**: New features can be added without breaking existing code
4. **Type Safety**: Enums prevent invalid states
5. **Clean Code**: Meaningful names, small methods, clear structure

## 📚 Further Reading

- See `DESIGN.md` for detailed design documentation
- See `requirements` for phase-wise implementation guide

## 👨‍💻 Author

Created as a demonstration of SOLID principles and design patterns for machine coding interviews.

## 📄 License

Free to use for learning and interview preparation.

