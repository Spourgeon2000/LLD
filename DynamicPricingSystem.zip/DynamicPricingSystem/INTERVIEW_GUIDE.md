# Interview Guide - Dynamic Pricing System

## 🎯 What to Say in an Interview

### When Asked About Design Patterns

**"I've implemented three key design patterns in this system:"**

1. **Strategy Pattern** - "I used the Strategy pattern to encapsulate different pricing algorithms. This allows us to add new pricing strategies without modifying existing code. For example, we have DemandBasedPricingStrategy and InventoryBasedPricingStrategy, both implementing the PricingStrategy interface."

2. **Repository Pattern** - "I abstracted data access using the Repository pattern. This decouples the business logic from data storage, making it easy to swap implementations - from in-memory to database - without changing the service layer."

3. **Dependency Injection** - "I used constructor injection to achieve loose coupling. The PricingService depends on abstractions (interfaces) rather than concrete implementations, making the code more testable and maintainable."

### When Asked About SOLID Principles

**"All five SOLID principles are demonstrated:"**

1. **Single Responsibility (SRP)** - "Each class has one reason to change. Product manages data, strategies calculate prices, repository handles storage - each has a single, well-defined responsibility."

2. **Open/Closed (OCP)** - "The system is open for extension but closed for modification. I can add new pricing strategies by implementing the PricingStrategy interface without touching existing code."

3. **Liskov Substitution (LSP)** - "Any PricingStrategy implementation can be substituted for another without breaking the system. The PricingEngine works with any strategy that implements the interface."

4. **Interface Segregation (ISP)** - "I kept interfaces small and focused. PricingStrategy has only 2 methods, ProductRepository has only essential CRUD operations - no fat interfaces."

5. **Dependency Inversion (DIP)** - "High-level modules depend on abstractions. PricingService depends on ProductRepository interface, not the concrete InMemoryProductRepository class."

## 🏗️ Architecture Explanation

**"The architecture follows a layered approach:"**

```
Presentation Layer (Main)
    ↓
Service Layer (PricingService) - Business logic orchestration
    ↓
Domain Layer (Product, Enums) - Business entities
    ↓
Strategy Layer (Pricing Strategies) - Pricing algorithms
    ↓
Repository Layer (Data Access) - Storage abstraction
```

## 💡 Key Design Decisions

### 1. Why Strategy Pattern?
"I chose Strategy pattern because pricing logic can vary and evolve. Today we have demand and inventory-based pricing, tomorrow we might add competitor-based or time-based pricing. Strategy pattern makes this extension trivial."

### 2. Why Enums for Levels?
"I used enums (DemandLevel, InventoryLevel) instead of strings or magic numbers for type safety. This prevents invalid states and makes the code self-documenting."

### 3. Why Immutable Fields?
"Product ID, name, and basePrice are final because they shouldn't change after creation. This prevents bugs and makes the code more predictable."

### 4. Why Optional in Repository?
"I used Optional<Product> for findById() to explicitly handle the case when a product doesn't exist, avoiding null pointer exceptions."

## 🧪 How to Extend (Interview Questions)

### Q: "How would you add time-based pricing (peak hours)?"

**Answer:**
```java
public class TimeBasedPricingStrategy implements PricingStrategy {
    @Override
    public double calculateMultiplier(Product product) {
        LocalTime now = LocalTime.now();
        boolean isPeakHour = now.isAfter(LocalTime.of(9, 0)) 
                          && now.isBefore(LocalTime.of(17, 0));
        return isPeakHour ? 1.3 : 1.0;
    }
    
    @Override
    public String getStrategyName() {
        return "Time-Based Pricing";
    }
}

// Add to Main.java
strategies.add(new TimeBasedPricingStrategy());
```

"No existing code needs to change - that's the power of the Open/Closed Principle."

### Q: "How would you add database persistence?"

**Answer:**
```java
public class DatabaseProductRepository implements ProductRepository {
    private final Connection connection;
    
    @Override
    public void save(Product product) {
        // JDBC or JPA code here
    }
    
    @Override
    public Optional<Product> findById(String id) {
        // Database query here
    }
    // ... other methods
}

// In Main.java, just change one line:
ProductRepository repository = new DatabaseProductRepository(connection);
```

"The service layer doesn't need to change because it depends on the interface, not the implementation."

### Q: "How would you add caching?"

**Answer:**
```java
public class CachedProductRepository implements ProductRepository {
    private final ProductRepository delegate;
    private final Map<String, Product> cache;
    
    public CachedProductRepository(ProductRepository delegate) {
        this.delegate = delegate;
        this.cache = new HashMap<>();
    }
    
    @Override
    public Optional<Product> findById(String id) {
        if (cache.containsKey(id)) {
            return Optional.of(cache.get(id));
        }
        Optional<Product> product = delegate.findById(id);
        product.ifPresent(p -> cache.put(id, p));
        return product;
    }
    // ... other methods
}
```

"This is the Decorator pattern - we wrap the existing repository with caching behavior."

## 🎓 Testing Strategy

**"The design makes testing easy:"**

### Unit Testing Strategies
```java
// Test strategy in isolation
@Test
public void testDemandBasedPricing() {
    Product product = new Product("P1", "Test", 100.0, 50);
    product.incrementViews(); // 1 view
    
    DemandBasedPricingStrategy strategy = new DemandBasedPricingStrategy();
    double multiplier = strategy.calculateMultiplier(product);
    
    assertEquals(1.0, multiplier); // LOW demand
}

// Test service with mock dependencies
@Test
public void testPricingService() {
    ProductRepository mockRepo = mock(ProductRepository.class);
    PricingEngine mockEngine = mock(PricingEngine.class);
    
    PricingService service = new PricingService(mockRepo, mockEngine);
    // Test service logic
}
```

## 📊 Complexity Analysis

**"Let me explain the time and space complexity:"**

- **Add Product**: O(1) - HashMap insertion
- **Get Product**: O(1) - HashMap lookup
- **Calculate Price**: O(n) where n = number of strategies (typically 2-3)
- **Record View/Purchase**: O(1) + O(n) for price recalculation
- **Space**: O(m) where m = number of products

## 🚀 Production Readiness

**"To make this production-ready, I would add:"**

1. **Logging** - Add SLF4J for debugging and monitoring
2. **Validation** - More comprehensive input validation
3. **Error Handling** - Custom exceptions with meaningful messages
4. **Concurrency** - Thread-safe operations for concurrent access
5. **Persistence** - Database integration with transactions
6. **Monitoring** - Metrics for price changes, performance
7. **Configuration** - Externalize thresholds and multipliers
8. **API Layer** - REST endpoints for external access

## 💬 Common Interview Questions

### Q: "Why not use inheritance instead of composition?"
**A:** "Composition over inheritance is a best practice. With composition (Strategy pattern), I can change pricing behavior at runtime and combine multiple strategies. Inheritance would create a rigid hierarchy."

### Q: "What if we need to support multiple currencies?"
**A:** "I would add a Currency field to Product and a CurrencyConverter service. The pricing logic remains the same, we just convert at display time."

### Q: "How do you handle concurrent price updates?"
**A:** "I would use synchronized methods or ReadWriteLock for thread safety. For distributed systems, I'd use optimistic locking with version numbers."

### Q: "What about price history tracking?"
**A:** "I would implement the Observer pattern - when price changes, notify a PriceHistoryListener that records the change to a separate PriceHistory table."

## 🎯 Key Talking Points

1. **Separation of Concerns** - Each layer has clear boundaries
2. **Testability** - All components can be tested independently
3. **Extensibility** - New features don't break existing code
4. **Type Safety** - Enums prevent invalid states
5. **Clean Code** - Self-documenting, readable, maintainable

## ⏱️ Time Management (90 minutes)

- **0-20 min**: Core classes (Product, Repository, Service)
- **20-40 min**: Strategy pattern implementation
- **40-60 min**: Pricing engine and integration
- **60-75 min**: Main demo and testing
- **75-90 min**: Polish, error handling, documentation

## ✅ Checklist Before Submitting

- [ ] Code compiles without errors
- [ ] All SOLID principles demonstrated
- [ ] At least 2 design patterns used
- [ ] Clean, readable code with meaningful names
- [ ] Basic error handling (null checks, validation)
- [ ] Working demo with sample data
- [ ] Comments explaining key design decisions
- [ ] No hardcoded values (use constants/enums)

Good luck with your interview! 🚀

