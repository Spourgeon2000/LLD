package data;

public class WordData {
    String wordId;
    String word;

    public String getParentWord() {
        return parentWord;
    }

    public void setParentWord(String parentWord) {
        this.parentWord = parentWord;
    }

    String parentWord;
    Integer frequency;

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public Integer getFrequency() {
        return frequency;
    }

    public void setFrequency(Integer frequency) {
        this.frequency = frequency;
    }

    public String getWordId() {
        return wordId;
    }

    public void setWordId(String wordId) {
        this.wordId = wordId;
    }
}
