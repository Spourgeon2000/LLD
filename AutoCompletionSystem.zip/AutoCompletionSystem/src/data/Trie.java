package data;

import java.util.HashMap;
import java.util.Map;

public class Trie {
    private String word;
    private boolean isWordEnd;
    private Map<Character, Trie> children;

    public Trie() {
        this.word = "";
        this.isWordEnd = false;
        this.children = new HashMap<>();
    }

    public Trie(String word) {
        this.word = word;
        this.isWordEnd = false;
        this.children = new HashMap<>();
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public boolean isWordEnd() {
        return isWordEnd;
    }

    public void setWordEnd(boolean wordEnd) {
        isWordEnd = wordEnd;
    }

    public Map<Character, Trie> getChildren() {
        return children;
    }

    public void setChildren(Map<Character, Trie> children) {
        this.children = children;
    }
}
