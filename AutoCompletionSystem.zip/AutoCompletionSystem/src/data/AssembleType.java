package data;

public enum AssembleType {
    SORT_BY_FREQUENCY
}
