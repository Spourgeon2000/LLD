package factory;

import data.AssembleType;
import service.WordsService;
import strategy.SortByCountStrategy;
import strategy.WordAssembleStratgy;

public class WordAssembleFactory {

    private static WordAssembleFactory instance = null;

    public static WordAssembleFactory getInstance() {
        if (instance == null) {
            instance = new WordAssembleFactory();
        }
        return instance;
    }

    public WordAssembleStratgy getWordAssempleStrategy(AssembleType assembleType) {
        if(assembleType == AssembleType.SORT_BY_FREQUENCY) {
            return  new SortByCountStrategy();
        }
        return null;
    }
}
