package repo;

import data.WordData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class WordRepo {
    private static WordRepo instance = null;

    public static WordRepo getInstance() {
        if (instance == null) {
            instance = new WordRepo();
        }
        return instance;
    }

    Map<String, WordData> wordIdToWordDataMap = new HashMap<String, WordData>();
    Map<String, WordData> wordToWordDataMap = new HashMap<String, WordData>();

    public WordData addWord(String word) {
        WordData wordData = wordToWordDataMap.getOrDefault(word, new WordData());
        if (wordToWordDataMap.containsKey(word)) {
            wordData.setFrequency(wordData.getFrequency() + 1);
            wordIdToWordDataMap.put(wordData.getWordId(), wordData);
            wordToWordDataMap.put(wordData.getWord(), wordData);
            return wordToWordDataMap.get(word);
        }
        wordData.setWord(word);
        wordData.setWordId(UUID.randomUUID().toString());
        wordData.setFrequency(1);  // Changed from 0 to 1
        wordData.setParentWord(word);  // Set parentWord
        wordIdToWordDataMap.put(wordData.getWordId(), wordData);
        wordToWordDataMap.put(wordData.getWord(), wordData);
        return wordData;
    }


    public List<WordData> getWordDataWithWords(List<String> words) {
        List<WordData> wordDataList = new ArrayList<WordData>();
       for(String word : words) {
           WordData wd = wordToWordDataMap.get(word);
           if (wd != null) {
               wordDataList.add(wd);
           }
       }
       return  wordDataList;
    }

    public void incrementWordFrequency(String word) {
        WordData wordData = wordToWordDataMap.get(word);
        if (wordData != null) {
            wordData.setFrequency(wordData.getFrequency() + 1);
        }
    }

    public List<WordData> getAllWords() {
        return wordIdToWordDataMap.values().stream().toList();
    }


}
