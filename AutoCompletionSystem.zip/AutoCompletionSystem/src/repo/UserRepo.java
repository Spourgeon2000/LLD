package repo;

import data.User;

import java.util.*;
import java.util.stream.Collectors;

public class UserRepo {
    private static UserRepo instance = null;
    private Map<String, User> userMap;
    private Map<String, Integer> userSearchCountMap;
    public static UserRepo getInstance() {
        if (instance == null) {
            instance = new UserRepo();
        }
        return instance;
    }
    private UserRepo() {
        this.userMap = new HashMap<>();
        this.userSearchCountMap = new HashMap<>();
    }

    public void addUser(User user) {
        userMap.put(user.getUserId(), user);
        userSearchCountMap.putIfAbsent(user.getUserId(), 0);
    }

    public User getUser(String userId) {
        return userMap.get(userId);
    }

    public void incrementSearchCount(String userId) {
        userSearchCountMap.put(userId, userSearchCountMap.getOrDefault(userId, 0) + 1);
    }

    public Integer getUserSearchCount(String userId) {
        return userSearchCountMap.getOrDefault(userId, 0);
    }

    public List<Map.Entry<String, Integer>> getTopUsers(Integer count) {
        return userSearchCountMap.entrySet().stream()
                .sorted((e1, e2) -> e2.getValue().compareTo(e1.getValue()))
                .limit(count)
                .collect(Collectors.toList());
    }

    public Map<String, Integer> getAllUserSearchCounts() {
        return new HashMap<>(userSearchCountMap);
    }
}
