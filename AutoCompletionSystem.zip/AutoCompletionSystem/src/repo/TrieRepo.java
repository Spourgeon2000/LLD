package repo;

import data.Trie;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TrieRepo {
    private static TrieRepo instance = null;

    public static TrieRepo getInstance() {
        if (instance == null) {
            instance = new TrieRepo();
        }
        return instance;
    }

    Trie root = new Trie("/");

    public void insert(String word) {
        Trie current = root;
        for (Character ch : word.toCharArray()) {
            if (!current.getChildren().containsKey(ch)) {
                current.getChildren().put(ch, new Trie());
            }
            current = current.getChildren().get(ch);
        }
        current.setWordEnd(true);
    }

    public List<String> getAllWordsFromNode(Trie node, String prefix) {
        List<String> result = new ArrayList<>();
        if (node == null) return result;

        getAllWordsHelper(node, prefix, result);
        return result;
    }

    private void getAllWordsHelper(Trie node, String currentWord, List<String> result) {
        // If this node marks end of a word, add it
        if (node.isWordEnd()) {
            result.add(currentWord);
        }

        // Continue traversing children
        for (Map.Entry<Character, Trie> entry : node.getChildren().entrySet()) {
            getAllWordsHelper(entry.getValue(), currentWord + entry.getKey(), result);
        }
    }

    public Trie search(String word) {
        Trie current = root;
        for (Character ch : word.toCharArray()) {
            current = current.getChildren().get(ch);
            if (current == null) {
                return null;
            }
        }
        return current;
    }
}
