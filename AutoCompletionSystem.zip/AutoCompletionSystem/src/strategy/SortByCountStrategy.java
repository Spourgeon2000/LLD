package strategy;

import data.WordData;

import java.util.List;

public class SortByCountStrategy implements WordAssembleStratgy {

    public List<WordData> getAllignedWords(List<WordData> words, Integer limit) {
        return words.stream().sorted(((o1, o2) -> {
            return o2.getFrequency().compareTo(o1.getFrequency());
        })).limit(limit).toList();
    }
}
