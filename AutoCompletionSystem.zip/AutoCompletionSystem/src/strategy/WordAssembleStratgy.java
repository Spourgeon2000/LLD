package strategy;

import data.WordData;

import java.util.List;

public interface WordAssembleStratgy {
    public List<WordData> getAllignedWords(List<WordData> words, Integer limit);
}
