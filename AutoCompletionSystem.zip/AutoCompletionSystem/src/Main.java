import data.AssembleType;
import data.User;
import repo.UserRepo;
import service.SearchService;
import service.WordsService;

import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Autocomplete System Test ===\n");

        // Initialize services
        WordsService wordsService = WordsService.getInstance();
        SearchService searchService = SearchService.getInstance();
        UserRepo userRepo = UserRepo.getInstance();

        // Create test users
        User user1 = new User();
        user1.setUserId("user1");
        user1.setName("Alice");
        user1.setEmail("alice@example.com");
        userRepo.addUser(user1);

        User user2 = new User();
        user2.setUserId("user2");
        user2.setName("Bob");
        user2.setEmail("bob@example.com");
        userRepo.addUser(user2);

        System.out.println("✓ Users created: Alice, Bob\n");

        // Test 1: Add words to the system
        System.out.println("--- Test 1: Adding Words ---");
        wordsService.addWord("car");
        wordsService.addWord("cat");
        wordsService.addWord("card");
        wordsService.addWord("care");
        wordsService.addWord("careful");
        wordsService.addWord("apple");
        wordsService.addWord("application");
        wordsService.addWord("apply");
        wordsService.addWord("dog");
        wordsService.addWord("door");
        System.out.println("✓ Added 10 words to dictionary\n");

        // Test 2: Search with prefix "ca"
        System.out.println("--- Test 2: Search prefix 'ca' ---");
        List<String> results = searchService.giveTopWords("ca", AssembleType.SORT_BY_FREQUENCY, 10, "user1");
        System.out.println("Results for 'ca': " + results);
        System.out.println("Expected: [car, cat, card, care, careful]\n");

        // Test 3: Search with prefix "app"
        System.out.println("--- Test 3: Search prefix 'app' ---");
        results = searchService.giveTopWords("app", AssembleType.SORT_BY_FREQUENCY, 10, "user2");
        System.out.println("Results for 'app': " + results);
        System.out.println("Expected: [apple, application, apply]\n");

        // Test 4: Search with limit
        System.out.println("--- Test 4: Search with limit 2 ---");
        results = searchService.giveTopWords("ca", AssembleType.SORT_BY_FREQUENCY, 2, "user1");
        System.out.println("Results for 'ca' (limit 2): " + results);
        System.out.println("Expected: Only 2 results\n");

        // Test 5: Case-insensitive search
        System.out.println("--- Test 5: Case-insensitive search ---");
        results = searchService.giveTopWords("CA", AssembleType.SORT_BY_FREQUENCY, 10, "user1");
        System.out.println("Results for 'CA': " + results);
        System.out.println("Expected: Same as 'ca'\n");

        // Test 6: Empty prefix
        System.out.println("--- Test 6: Empty prefix ---");
        results = searchService.giveTopWords("", AssembleType.SORT_BY_FREQUENCY, 5, "user2");
        System.out.println("Results for empty prefix (top 5): " + results);
        System.out.println("Expected: Top 5 most searched words\n");

        // Test 7: No matches
        System.out.println("--- Test 7: No matches ---");
        results = searchService.giveTopWords("xyz", AssembleType.SORT_BY_FREQUENCY, 10, "user1");
        System.out.println("Results for 'xyz': " + results);
        System.out.println("Expected: []\n");

        // Test 8: Invalid limit (should use default 10)
        System.out.println("--- Test 8: Invalid limit ---");
        results = searchService.giveTopWords("ca", AssembleType.SORT_BY_FREQUENCY, -5, "user2");
        System.out.println("Results for 'ca' (limit -5): " + results);
        System.out.println("Expected: Uses default limit 10\n");

        // Test 9: User analytics
        System.out.println("--- Test 9: User Analytics ---");
        System.out.println("User1 search count: " + userRepo.getUserSearchCount("user1"));
        System.out.println("User2 search count: " + userRepo.getUserSearchCount("user2"));
        System.out.println("Expected: user1=5, user2=4\n");

        // Test 10: Top users
        System.out.println("--- Test 10: Top Users ---");
        List<Map.Entry<String, Integer>> topUsers = userRepo.getTopUsers(2);
        System.out.println("Top 2 users:");
        for (Map.Entry<String, Integer> entry : topUsers) {
            System.out.println("  " + entry.getKey() + ": " + entry.getValue() + " searches");
        }
        System.out.println();

        // Test 11: Multiple searches to test frequency tracking
        System.out.println("--- Test 11: Frequency Tracking ---");
        System.out.println("Searching 'car' multiple times...");
        wordsService.addWord("car");
        wordsService.addWord("car");
        wordsService.addWord("car");
        wordsService.addWord("cat");
        wordsService.addWord("cat");
        results = searchService.giveTopWords("ca", AssembleType.SORT_BY_FREQUENCY, 3, "user1");
        System.out.println("Results for 'ca' after adding 'car' 3x and 'cat' 2x: " + results);
        System.out.println("Expected: 'car' should appear before 'cat' (higher frequency)\n");

        System.out.println("=== All Tests Complete ===");
    }
}