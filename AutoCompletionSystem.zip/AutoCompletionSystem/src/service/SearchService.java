package service;

import data.AssembleType;
import data.Trie;
import data.WordData;
import factory.WordAssembleFactory;
import repo.TrieRepo;
import repo.UserRepo;
import strategy.WordAssembleStratgy;

import java.util.List;

public class SearchService {
    private static SearchService instance = null;

    public static SearchService getInstance() {
        if (instance == null) {
            instance = new SearchService();
        }
        return instance;
    }

    TrieRepo trieRepo = TrieRepo.getInstance();
    WordsService wordsService = WordsService.getInstance();
    WordAssembleFactory wordAssembleFactory = WordAssembleFactory.getInstance();
    UserRepo userRepo = UserRepo.getInstance();

    public List<String> giveTopWords(String word, AssembleType assembleType, Integer limit, String userId) {
        if (limit == null || limit <= 0 || limit > 50) {
            limit = 10;
        }

        // Edge case: Empty prefix
        if (word == null || word.isEmpty()) {
            List<WordData> allWords = wordsService.getAllWords();
            WordAssembleStratgy strategy = wordAssembleFactory.getWordAssempleStrategy(assembleType);
            userRepo.incrementSearchCount(userId);
            return strategy.getAllignedWords(allWords, limit).stream().map(WordData::getWord).toList();
        }
        word = word.toLowerCase().trim();
        Trie trie = trieRepo.search(word);
        if (trie == null) {
            userRepo.incrementSearchCount(userId);
            return List.of();
        }
        wordsService.incrementWordFrequency(word);
        List<String> words = trieRepo.getAllWordsFromNode(trie, word);
        List<WordData> wordDataList = wordsService.getWordDataWithWords(words);
        WordAssembleStratgy wordAssembleStratgy = wordAssembleFactory.getWordAssempleStrategy(assembleType);
        userRepo.incrementSearchCount(userId);
        return wordAssembleStratgy.getAllignedWords(wordDataList, limit).stream().map(WordData::getWord).toList();
    }

}
