package service;

import data.WordData;
import repo.TrieRepo;
import repo.WordRepo;

import java.util.List;

public class WordsService {
    private static WordsService instance = null;

    public static WordsService getInstance() {
        if (instance == null) {
            instance = new WordsService();
        }
        return instance;
    }

    private WordRepo wordRepo = WordRepo.getInstance();
    private TrieRepo trieRepo = TrieRepo.getInstance();

    public WordData addWord(String word) {
        word = word.toLowerCase().trim();
        trieRepo.insert(word);

        WordData wordData = wordRepo.addWord(word);
        return wordData;
    }

    public List<WordData> getWordDataWithWords(List<String> words) {
        return wordRepo.getWordDataWithWords(words);
    }

    public void incrementWordFrequency(String word) {
        wordRepo.incrementWordFrequency(word);
    }

    public List<WordData> getAllWords() {
        return  wordRepo.getAllWords();
    }
}
