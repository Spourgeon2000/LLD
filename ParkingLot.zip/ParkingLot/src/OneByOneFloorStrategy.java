import data.Floor;

import java.util.List;

public class OneByOneFloorStrategy implements  FloorSelectionStrategy {
    FloorDb floorDb = FloorDb.getInstance();

    public Floor selectFloor(String parkingLotId) {
        List<Floor> floors = floorDb.getFloorsForParkingLotId(parkingLotId);
        Floor requiredFloor = null;
        for (Floor floor : floors) {
            if (floor.getTotalAvailableSlots() != 0) {
                requiredFloor = floor;
                break;
            }
        }
        return requiredFloor;
    }
}
