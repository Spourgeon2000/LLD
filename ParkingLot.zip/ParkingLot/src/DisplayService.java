import data.Slot;

import java.util.Map;

public class DisplayService {
    SlotDb slotDb = SlotDb.getInstance();

    public void display() {
        Map<Integer, Slot> slotMap = slotDb.getSlotMap();
        for (Slot slot : slotMap.values()) {
            if (slot.isAvailable()) {
                System.out.println("Floor " + slot.getFloorNumber() + ", Slot " + slot.getSlotNumber() + ", Available");
            } else {
                System.out.println("Floor " + slot.getFloorNumber() + ", Slot is Occupied by" + slot.getVehicleLicensePlateNumber());
            }
        }
    }
}
