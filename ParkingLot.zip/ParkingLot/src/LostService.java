import data.Ticket;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class LostService {
    FineStrategy fineStrategy;
    TicketDb ticketDb = TicketDb.getInstance();

    public Long getLostTicketFine(String vehicleLicenseNumber) {
        Ticket ticket = ticketDb.getLatestTicketForLicenseNumber(vehicleLicenseNumber);
        if (ticket.isValid) {
            long daysBetween = ChronoUnit.DAYS.between(ticket.getDueTime(), LocalDateTime.now());
            return fineStrategy.calculateFine(ticket.getDueTime(), LocalDateTime.now()) + daysBetween * 50;
        }
        return 0L;
    }
}
