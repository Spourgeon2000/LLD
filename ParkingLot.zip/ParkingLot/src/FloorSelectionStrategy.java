import data.Floor;

public interface FloorSelectionStrategy {

   Floor selectFloor(String parkingLotId);
}
