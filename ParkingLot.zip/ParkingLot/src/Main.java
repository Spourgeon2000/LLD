//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
//        we need to park a vehicle based on free slots in the floor , for floor also we will use some stragergy (less cars in the floor like that kind of strategy , we will have deafault one and also we can choose what we like )
//        to get floor
//        we need to unpark a vehicle
//        we need to support multiple vehicle types for parking
//        need to park on a floor based on availability (nearest to entrance or nearest to exit like that)
//        once the vehicle is unparked user need to return the ticket and fine will be applied if he takes more time to take vehicle from the parking lot from
//        the due date (it is a date we give to user while giving the ticket , we ask him for what time you need to park here)which is present in ticket which he will show us while taking vehicle
//        we need to find a parking vehicle where it is , we can give that in the ticket
//        while getting the ticket he need to pay by using some payment gateway like UPI or CASH or CARD like that (we will have certain amount to pay at the time of parking based on day and time (sunday we will charge 5dollars and in normal days 3dollars like that) and if he takes more time to take vehicle we will charge extra that will be payed when he took the vehicle)
//        slot gets assigning based on some strategy like nearest to entrance or nearest to exit like that
//        when is parking lot is full we will tell user and he will go away from there
//        we will have license plate number in the ticket so we can give user based on that
//        we have ticket details in our db , so fake ticket will not work
//        Two customers want the last available slot - we will have some locking
//        based on the slot type (BIG or SMALL or MEDIUM) we will park the vehicle
//        re entry with same ticket is not allowed as we can park only one vehicle per ticket
//
//        lost ticket extra fine (we have license plate number in the ticket from that we can know vehicle and we will
//        add charge for lost ticket plus actual parking fee, from the license), this is extra feature
//        we will have one display board to show the parking status for vehicles , we will show how many slots are available for each type of vehicle in each floor

    }
}