import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

public class NormalFineStrategy implements FineStrategy {
    public Long calculateFine(LocalDateTime expiryTime, LocalDateTime currentTime) {
        long daysBetween = ChronoUnit.DAYS.between(expiryTime, currentTime);
        if (daysBetween > 0) {
            return daysBetween * 10;
        }
        return 0L;
    }
}
