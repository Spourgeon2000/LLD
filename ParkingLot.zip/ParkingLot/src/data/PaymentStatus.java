package data;

public enum PaymentStatus {
    ONGOING,
    FAILED,
    SUCCESS
}
