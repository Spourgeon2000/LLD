package data;

public enum SlotType {
    SMALL,
    MEDIUM,
    LARGE
}
