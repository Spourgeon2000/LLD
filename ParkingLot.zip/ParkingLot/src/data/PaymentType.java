package data;

public enum PaymentType {
    CASH,
    UPI,
    CARD
}
