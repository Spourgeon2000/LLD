package data;

public enum VehicleType {
    BIKE,
    CAR,
    TRUCK
}
