package data;

import java.util.List;
import java.util.Map;

public class Floor {
    public Integer floorId;
    public Integer floorNumber;
    public String parkingLotId;
    public int totalSlots;
    public int totalAvailableSlots;
    public Map<SlotType, Integer> totalSlotsByType;
    public Map<SlotType, Integer> availableSlotsByType;

    public Integer getFloorId() {
        return floorId;
    }

    public Integer getFloorNumber() {
        return floorNumber;
    }

    public void setFloorNumber(Integer floorNumber) {
        this.floorNumber = floorNumber;
    }

    public void setFloorId(Integer floorId) {
        this.floorId = floorId;
    }

    public String getParkingLotId() {
        return parkingLotId;
    }

    public void setParkingLotId(String parkingLotId) {
        this.parkingLotId = parkingLotId;
    }

    public int getTotalSlots() {
        return totalSlots;
    }

    public void setTotalSlots(int totalSlots) {
        this.totalSlots = totalSlots;
    }

    public int getTotalAvailableSlots() {
        return totalAvailableSlots;
    }

    public void setTotalAvailableSlots(int totalAvailableSlots) {
        this.totalAvailableSlots = totalAvailableSlots;
    }

    public Map<SlotType, Integer> getTotalSlotsByType() {
        return totalSlotsByType;
    }

    public void setTotalSlotsByType(Map<SlotType, Integer> totalSlotsByType) {
        this.totalSlotsByType = totalSlotsByType;
    }

    public Map<SlotType, Integer> getAvailableSlotsByType() {
        return availableSlotsByType;
    }

    public void setAvailableSlotsByType(Map<SlotType, Integer> availableSlotsByType) {
        this.availableSlotsByType = availableSlotsByType;
    }
}
