import data.Slot;
import data.SlotType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class SlotDb {

    private static SlotDb instance = null;

    private SlotDb() {

    }

    public static SlotDb getInstance() {
        if (instance == null) {
            instance = new SlotDb();
        }
        return instance;
    }

    public static Map<Integer, Slot> slotMap = new HashMap<>();

    public Map<Integer, List<Slot>> getFloorIdToSlotsMap() {
        return floorIdToSlotsMap;
    }

    public Map<Integer, Slot> getSlotMap() {
        return slotMap;
    }

    public static Map<Integer, List<Slot>> floorIdToSlotsMap = new HashMap<>();

    public Slot addSlot(String parkingLotId, Integer floorId, Integer floorNumber, Integer slotNumber, SlotType slotType) {
        Slot slot = new Slot();
        slot.setSlotId(IdGenerator.getId());
        slot.setFloorId(floorId);
        slot.setFloorNumber(floorNumber);
        slot.setSlotNumber(slotNumber);
        slot.setSlotType(slotType);
        slot.setParkingLotId(parkingLotId);
        slot.setAvailable(true);
        slotMap.put(slot.getSlotId(), slot);
        List<Slot> slots = floorIdToSlotsMap.getOrDefault(floorId, new ArrayList<>());
        floorIdToSlotsMap.put(slot.getFloorId(), slots);
        return slot;
    }

    public Slot getFloor(Integer slotId) {
        return slotMap.get(slotId);
    }

    public List<Slot> getSlotsForFloorId(Integer floorId) {
        return floorIdToSlotsMap.get(floorId);
    }

    public Slot updateAvailableSlot(Integer slotId, boolean isAvailable) {
        if (!slotMap.containsKey(slotId)) {
            return null;
        }
        Slot slot = slotMap.get(slotId);
        slot.setAvailable(isAvailable);
        slotMap.put(slot.getSlotId(), slot);
        List<Slot> slots = floorIdToSlotsMap.getOrDefault(slot.getFloorId(), new ArrayList<>());
        List<Slot> updatedSlots = new ArrayList<>();
        for (Slot slot1 : slots) {
            if (Objects.equals(slot1.getSlotId(), slot.getSlotId())) {
                slot1.setAvailable(isAvailable);
            }
            updatedSlots.add(slot1);
        }
        floorIdToSlotsMap.put(slot.getFloorId(), updatedSlots);
        return slot;
    }

}
