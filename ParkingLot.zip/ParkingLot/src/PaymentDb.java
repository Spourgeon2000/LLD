import data.Payment;
import data.PaymentStatus;
import data.PaymentType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PaymentDb {

    private static PaymentDb instance = null;

    private PaymentDb() {
    }

    public static PaymentDb getInstance() {
        if (instance == null) {
            instance = new PaymentDb();
        }
        return instance;
    }

    public static Map<String, Payment> paymentMap = new HashMap<>();

    public Payment addPayment(String ticketId, PaymentType paymentType, Long amount,
                              PaymentStatus paymentStatus) {
        Payment payment = new Payment();
        payment.setPaymentId(UUID.randomUUID().toString());
        payment.setTicketId(ticketId);
        payment.setPaymentType(paymentType);
        payment.setAmount(amount);
        payment.setCreatedTime(System.currentTimeMillis());
        payment.setPaymentStatus(paymentStatus);
        paymentMap.put(payment.getPaymentId(), payment);
        return payment;
    }
}
