import data.Floor;
import data.Slot;
import data.SlotType;
import data.Ticket;
import data.User;
import data.Vehicle;
import data.VehicleType;

import java.time.LocalDateTime;

import static data.VehicleType.BIKE;
import static data.VehicleType.CAR;
import static data.VehicleType.TRUCK;

public class ParkingService {
    FloorSelectionStrategy floorSelectionStrategy;
    SlotSelectionStrategy slotSelectionStrategy;
    SlotDb slotDb = SlotDb.getInstance();
    FloorDb floorDb = FloorDb.getInstance();
    TicketDb ticketDb = TicketDb.getInstance();
    FineStrategy fineStrategy;

    private static ParkingService instance = null;

    private ParkingService() {

    }

    public static ParkingService getInstance() {
        if (instance == null) {
            instance = new ParkingService();
        }
        return instance;
    }

    public Ticket parkVehicle(Vehicle vehicle, String parkingLotId, User user, LocalDateTime startTime, LocalDateTime dueTime) {
        Floor floor = floorSelectionStrategy.selectFloor(parkingLotId);
        Slot slot = slotSelectionStrategy.selectSlot(floor.getFloorId(), getSlotTypeByVehicleType(vehicle.getVehicleType()));
        if (slot == null) {
            System.out.println("Sorry, parking lot is full , please go away ");
            return null;
        }
        synchronized (slot) {
            if(!slot.isAvailable){return null;}
            slotDb.updateAvailableSlot(slot.getSlotId(), false);
            floorDb.updateAvailableSlots(slot.getSlotType(), floor.getFloorId(), false);
            return ticketDb.addTicket(vehicle.getLicensePlateNumber(), floor.getFloorId(), slot.getSlotId(), parkingLotId,
                    user, startTime, dueTime);
        }
    }

    public Long unParkVehicle(String ticketId) {
        Ticket ticket = ticketDb.getTicket(ticketId);
        if (ticket == null) {
            System.out.println("Invalid ticket");
            return 0L;
        }
        if(!ticket.isValid){
            System.out.println("Re-entry of same ticket is not allowed");
            return 0L;
        }
        Slot slot = SlotDb.slotMap.get(ticket.getSlotId());
        slotDb.updateAvailableSlot(ticket.getSlotId(), false);
        floorDb.updateAvailableSlots(slot.getSlotType(), ticket.getFloorId(), false);
        ticketDb.makeTicketInvalid(ticketId);
        return fineStrategy.calculateFine(ticket.getDueTime(), LocalDateTime.now());
    }

    public SlotType getSlotTypeByVehicleType(VehicleType vehicleType) {
        if (vehicleType == BIKE) {
            return SlotType.SMALL;
        }
        if (vehicleType == CAR) {
            return SlotType.MEDIUM;
        }
        if (vehicleType == TRUCK) {
            return SlotType.LARGE;
        }
        return null;
    }
}
