import data.Payment;
import data.PaymentStatus;
import data.PaymentType;

import static data.PaymentStatus.FAILED;
import static data.PaymentStatus.ONGOING;
import static data.PaymentStatus.SUCCESS;

public class UPIPaymentStrategy implements  PaymentStrategy {
    PaymentDb paymentDb = PaymentDb.getInstance();

    public Payment pay(Long amount, String ticketId) {
        PaymentStatus status = ONGOING;
        try {
            status = SUCCESS;
        } catch (Exception e) {
            //if something happen , suppose upi is failed
            status = FAILED;
        }
        return paymentDb.addPayment(ticketId, PaymentType.UPI, amount, status);

    }
}
