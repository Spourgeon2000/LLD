import data.Slot;
import data.SlotType;

import java.util.List;

public class NearestSlotToEntranceStrategy implements SlotSelectionStrategy {
    SlotDb slotDb = SlotDb.getInstance();

    public Slot selectSlot(Integer floorId, SlotType slotType) {
        //assuming we fill slots in order ,
        List<Slot> slots = slotDb.getSlotsForFloorId(floorId);
        for (Slot slot : slots) {
            if (slot.isAvailable() && slot.getSlotType().equals(slotType)) {
                return slot;
            }
        }
        return null;
    }
}
