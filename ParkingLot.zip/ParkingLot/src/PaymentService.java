import data.Payment;

public class PaymentService {

    PaymentStrategy paymentStrategy;

    private static PaymentService instance = null;

    private PaymentService() {
    }

    public static PaymentService getInstance() {
        if (instance == null) {
            instance = new PaymentService();
        }
        return instance;
    }

    public Payment pay(Long amount, String ticketId) {
        return paymentStrategy.pay(amount, ticketId);
    }

}
