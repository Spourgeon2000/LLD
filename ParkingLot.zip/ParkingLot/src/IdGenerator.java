public class IdGenerator {
    public static int id = 1;
    public static int getId(){
        return id++;
    }
}
