import java.time.LocalDateTime;

public interface FineStrategy {
    Long calculateFine(LocalDateTime expiryTime, LocalDateTime currentTime);
}
