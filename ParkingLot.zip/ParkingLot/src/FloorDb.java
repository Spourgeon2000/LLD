import data.Floor;
import data.SlotType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FloorDb {

    private static FloorDb instance = null;
    private FloorDb(){

    }
    public static FloorDb getInstance() {
        if (instance == null) {
            instance = new FloorDb();
        }
        return instance;
    }

    public static Map<Integer, Floor> floorMap = new HashMap<>();

    public Map<String, List<Floor>> getParkingLotIdToFloors() {
        return parkingLotIdToFloors;
    }

    public void setParkingLotIdToFloors(Map<String, List<Floor>> parkingLotIdToFloors) {
        this.parkingLotIdToFloors = parkingLotIdToFloors;
    }

    public Map<String, List<Floor>> parkingLotIdToFloors;

    public Floor addFloor(String parkingLotId,int totalSlots,Map<SlotType, Integer> totalSlotsByType,Map<SlotType, Integer> availableSlotsByType,Integer floorNumber){
        Floor floor = new Floor();
        floor.setFloorId(IdGenerator.getId());
        floor.setFloorNumber(floorNumber);
        floor.setParkingLotId(parkingLotId);
        floor.setTotalSlots(totalSlots);
        floor.setTotalAvailableSlots(totalSlots);
        floor.setTotalSlotsByType(totalSlotsByType);
        floor.setAvailableSlotsByType(availableSlotsByType);
        floorMap.put(floor.getFloorId(),floor);
        List<Floor> floors = parkingLotIdToFloors.getOrDefault(parkingLotId,new ArrayList<>());
        parkingLotIdToFloors.put(floor.getParkingLotId(),floors);
        return floor;
    }

    public Floor getFloor(Integer floorId) {
        return floorMap.get(floorId);
    }
    public List<Floor> getFloorsForParkingLotId(String parkingLotId) {
        return parkingLotIdToFloors.get(parkingLotId);
    }

    public Floor updateAvailableSlots(SlotType slotType, Integer floorId, boolean isAvailable) {
        Floor floor = floorMap.get(floorId);
        Map<SlotType, Integer> availableSlotsByType = floor.getAvailableSlotsByType();
        Integer totalAvailableSlots = floor.getTotalAvailableSlots();
        Integer availableSlots = availableSlotsByType.get(slotType);
        if (isAvailable) {
            availableSlots++;
            totalAvailableSlots++;
        } else {
            availableSlots--;
            totalAvailableSlots--;
        }
        availableSlotsByType.put(slotType, availableSlots);
        floor.setAvailableSlotsByType(availableSlotsByType);
        floor.setTotalAvailableSlots(totalAvailableSlots);
        floorMap.put(floor.getFloorId(), floor);
        return floor;
    }


}
