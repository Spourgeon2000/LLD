import data.Floor;

import java.util.List;

public class MoreAvailableSlotStrategy implements FloorSelectionStrategy{
   FloorDb floorDb = FloorDb.getInstance();
   public Floor selectFloor(String parkingLotId) {
       List<Floor> floors = floorDb.getFloorsForParkingLotId(parkingLotId);
       int mostAvailable = 0;
       Floor requiredFloor = null;
       for (Floor floor : floors) {
           if(floor.getTotalAvailableSlots() > mostAvailable){
               mostAvailable = floor.getTotalAvailableSlots();
               requiredFloor = floor;
           }
       }
        return requiredFloor;
    }
}
