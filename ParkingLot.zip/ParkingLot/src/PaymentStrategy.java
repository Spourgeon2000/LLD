import data.Payment;

public interface PaymentStrategy {
    Payment pay(Long amount, String ticketId);
}
