import data.Floor;
import data.Slot;
import data.SlotType;

public interface SlotSelectionStrategy {
    Slot selectSlot(Integer floorId, SlotType slotType);
}
