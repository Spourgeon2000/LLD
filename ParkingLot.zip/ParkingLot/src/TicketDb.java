import data.Ticket;
import data.User;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class TicketDb {

    private static TicketDb instance = null;

    private TicketDb() {

    }

    public static TicketDb getInstance() {
        if (instance == null) {
            instance = new TicketDb();
        }
        return instance;
    }

    public static Map<String, Ticket> ticketMap = new HashMap<>();
    public static Map<String, List<Ticket>> licenseNumberToTicketMap = new HashMap<>();

    public Ticket addTicket(String vehicleLicenseNumber, Integer floorId, Integer slotId,
                            String parkingLotId, User user, LocalDateTime startTime, LocalDateTime dueTime) {
        Ticket ticket = new Ticket();
        ticket.setTicketId(UUID.randomUUID().toString());
        ticket.setVehicleLicenseNumber(vehicleLicenseNumber);
        ticket.setSlotId(slotId);
        ticket.setFloorId(floorId);
        ticket.setParkingLotId(parkingLotId);
        ticket.setValid(true);
        ticket.setUser(user);
        ticket.setCreatedTime(startTime);
        ticket.setDueTime(dueTime);
        ticketMap.put(ticket.getTicketId(), ticket);
        List<Ticket> tickets = licenseNumberToTicketMap.getOrDefault(vehicleLicenseNumber, new ArrayList<>());
        tickets.add(ticket);
        licenseNumberToTicketMap.put(ticket.getVehicleLicenseNumber(), tickets);
        return ticket;
    }

    public Ticket getTicket(String ticketId) {
        return ticketMap.get(ticketId);
    }

    public void makeTicketInvalid(String ticketId) {
        Ticket ticket = ticketMap.get(ticketId);
        ticket.setValid(false);
        ticketMap.put(ticket.getTicketId(), ticket);
    }

    public Ticket getLatestTicketForLicenseNumber(String licenseNumber) {
        List<Ticket> tickets = licenseNumberToTicketMap.getOrDefault(licenseNumber,new ArrayList<>());
        return tickets.get(tickets.size()-1);
    }
}
